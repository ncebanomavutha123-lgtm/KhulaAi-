import React, { useState } from 'react';
import {
  TrendingUp,
  Award,
  Sparkles,
  Calendar,
  CheckCircle2,
  Clock,
  Printer,
  RefreshCw,
  BookOpen,
  ChevronRight,
  Flame,
  Zap,
  Lock,
  UserPlus,
  RotateCcw,
} from 'lucide-react';
import { useLearner } from '../context/LearnerContext';
import { ProgressReport, SubjectMastery } from '../types';
import { formatMathText } from '../utils/mathFormatter';

interface ProgressGeneratorProps {
  onSelectTopic: (topic: string) => void;
  onOpenTopicModal: () => void;
  onOpenAuth: (mode?: 'signup' | 'login') => void;
}

export const ProgressGenerator: React.FC<ProgressGeneratorProps> = ({
  onSelectTopic,
  onOpenTopicModal,
  onOpenAuth,
}) => {
  const { account, isAuthenticated, getSubjectMasteryList } = useLearner();

  const [isGenerating, setIsGenerating] = useState(false);
  const subjectList = getSubjectMasteryList();

  // Current live progress metrics from persistent account (starts at 0% on signup, never restarts)
  const currentMastery = account ? account.overallMasteryPercentage : 0;
  const currentStreak = account ? account.streakDays : 0;
  const currentHours = account ? account.totalHoursStudied : 0;
  const currentCompleted = account ? account.activitiesCompletedCount : 0;
  const learnerDisplayName = account ? account.name : 'Guest Learner';
  const learnerGrade = account ? account.grade : 8;

  const [diagnosticMemo, setDiagnosticMemo] = useState<string | null>(null);

  const handleGenerateDiagnostic = () => {
    setIsGenerating(true);
    setTimeout(() => {
      let advice = '';
      if (currentMastery === 0) {
        advice = `Welcome ${learnerDisplayName}! You are currently at the starting line (0%). Complete your first CAPS activity or 4-day study plan to gain your first mastery points. Every step is saved permanently!`;
      } else if (currentMastery < 40) {
        advice = `Great start ${learnerDisplayName}! You've reached ${currentMastery}% mastery. Keep working through foundation practice exercises to push past 50%. Focus on checking units and showing clear step-by-step calculations.`;
      } else if (currentMastery < 75) {
        advice = `Solid progress! You are currently at ${currentMastery}%. Your exam readiness is building steadily. Continue tackling multi-step questions and review the 'Common Pitfalls' sections before test day.`;
      } else {
        advice = `Distinction level performance! You are sitting at ${currentMastery}% mastery. You have mastered core CAPS theorems and formulas. Focus on timed challenge questions to secure your Grade ${learnerGrade} Level 7 distinction!`;
      }
      setDiagnosticMemo(advice);
      setIsGenerating(false);
    }, 700);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="rounded-3xl border border-[#223052] bg-gradient-to-r from-[#121a2d] via-[#15213b] to-[#121a2d] p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-400/15 text-cyan-300 border border-cyan-400/30">
              Made by Nceba
            </span>
            <span className="text-xs text-[#aab4c8]">Permanent CAPS Progress Tracker</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Learner Progress & Diagnostic Generator
          </h2>
          <p className="text-sm text-[#aab4c8] max-w-xl leading-relaxed">
            Your progress starts at <strong className="text-cyan-300 font-bold">0%</strong> upon registration and
            increases permanently as you complete curriculum activities and study plans. It never starts over.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {!isAuthenticated && (
            <button
              type="button"
              onClick={() => onOpenAuth('signup')}
              className="inline-flex items-center gap-1.5 px-4 py-3 rounded-2xl bg-emerald-400 hover:bg-emerald-300 text-[#06121f] font-bold text-sm shadow-md transition-all"
            >
              <UserPlus className="size-4" />
              <span>Sign Up (Start at 0%)</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenTopicModal}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-[#06121f] font-bold text-sm shadow-lg shadow-cyan-400/20 transition-all shrink-0 focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
          >
            <Sparkles className="size-4" />
            <span>Type Topic To Learn</span>
          </button>
        </div>
      </div>

      {/* Guest Warning / Sign Up Callout */}
      {!isAuthenticated && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-[#121a2d] to-cyan-950/30 border border-emerald-400/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-emerald-400/15 text-emerald-300 flex items-center justify-center shrink-0">
              <TrendingUp className="size-5" />
            </div>
            <div>
              <p className="font-bold text-white text-sm">Create your free account to track permanent progress</p>
              <p className="text-xs text-[#aab4c8]">
                Sign up in 5 seconds. Your progress begins at 0% and saves safely on your device without resetting.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onOpenAuth('signup')}
            className="px-4 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-[#06121f] text-xs font-extrabold whitespace-nowrap"
          >
            Sign Up Now
          </button>
        </div>
      )}

      {/* Persistent Storage Guarantee Callout */}
      <div className="p-3.5 rounded-2xl bg-[#0b1020] border border-[#223052] flex items-center justify-between gap-3 text-xs text-[#aab4c8]">
        <div className="flex items-center gap-2">
          <Lock className="size-4 text-emerald-400 shrink-0" />
          <span>
            <strong className="text-white">Permanent Memory Active:</strong> Your progress ({currentMastery}%) and completed exercises will never start over or disappear when you close the browser.
          </span>
        </div>
        <span className="text-[11px] font-semibold text-cyan-300 shrink-0 hidden sm:inline">
          Learner: {learnerDisplayName}
        </span>
      </div>

      {/* Active Live Progress Card */}
      <article
        aria-labelledby="report-card-heading"
        className="rounded-3xl border border-[#223052] bg-[#121a2d] p-6 sm:p-8 space-y-6 shadow-2xl relative"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#223052] pb-6">
          <div>
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest block mb-1">
              Official CAPS Academic Tracker • Made by Nceba
            </span>
            <h3 id="report-card-heading" className="text-2xl font-extrabold text-white">
              {learnerDisplayName} — Grade {learnerGrade} Progress Card
            </h3>
            <p className="text-xs text-[#aab4c8] mt-0.5">
              Live Curriculum Record • {account?.completedActivities.length || 0} activity sessions logged
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleGenerateDiagnostic}
              disabled={isGenerating}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-400/10 hover:bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 text-xs font-bold transition-colors"
            >
              {isGenerating ? <RefreshCw className="size-3.5 animate-spin" /> : <TrendingUp className="size-3.5" />}
              <span>Generate AI Diagnostic</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-[#223052] bg-[#18223a] text-xs font-semibold text-white hover:border-cyan-400 transition-colors"
            >
              <Printer className="size-3.5 text-cyan-400" />
              <span>Print / PDF</span>
            </button>
          </div>
        </div>

        {/* Diagnostic Memo If Generated */}
        {diagnosticMemo && (
          <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-400/30 text-cyan-100 text-xs sm:text-sm space-y-1.5 animate-in fade-in-0 duration-200">
            <p className="font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="size-4" /> AI Study Coach Assessment:
            </p>
            <p className="leading-relaxed">{diagnosticMemo}</p>
          </div>
        )}

        {/* Key Metrics Dashboard */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-[#0b1020] border border-[#223052] text-center space-y-1">
            <span className="text-xs text-[#aab4c8]">Overall Progress</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-cyan-400 font-['Sora']">
              {currentMastery}%
            </p>
            <div className="w-full bg-[#18223a] h-1.5 rounded-full overflow-hidden mt-1">
              <div
                className="bg-cyan-400 h-full transition-all duration-500"
                style={{ width: `${currentMastery}%` }}
              />
            </div>
            <span className="text-[10px] text-cyan-300 font-medium block pt-1">
              {currentMastery === 0 ? 'Started at 0%' : currentMastery < 50 ? 'Developing' : 'Achieved'}
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#0b1020] border border-[#223052] text-center space-y-1">
            <span className="text-xs text-[#aab4c8]">Study Streak</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-['Sora'] flex items-center justify-center gap-1">
              <Flame className="size-6 text-amber-400 fill-amber-400/20" />
              {currentStreak} {currentStreak === 1 ? 'Day' : 'Days'}
            </p>
            <span className="text-[10px] text-[#aab4c8]">Daily study habit</span>
          </div>

          <div className="p-4 rounded-2xl bg-[#0b1020] border border-[#223052] text-center space-y-1">
            <span className="text-xs text-[#aab4c8]">Time Dedicated</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-purple-400 font-['Sora'] flex items-center justify-center gap-1">
              <Clock className="size-5 text-purple-400" />
              {currentHours}h
            </p>
            <span className="text-[10px] text-[#aab4c8]">Logged study time</span>
          </div>

          <div className="p-4 rounded-2xl bg-[#0b1020] border border-[#223052] text-center space-y-1">
            <span className="text-xs text-[#aab4c8]">Activities Done</span>
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-['Sora'] flex items-center justify-center gap-1">
              <CheckCircle2 className="size-5 text-emerald-400" />
              {currentCompleted}
            </p>
            <span className="text-[10px] text-emerald-400">Completed exercises</span>
          </div>
        </div>

        {/* Subject-by-Subject Mastery Breakdown */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-2">
              <BookOpen className="size-4" />
              Subject Mastery Breakdown (Starts at 0% and climbs with practice)
            </h4>
            <span className="text-xs text-[#aab4c8]">Updated in real-time</span>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {subjectList.map((sub) => (
              <div
                key={sub.subject}
                className="p-4 rounded-2xl bg-[#0b1020]/70 border border-[#223052] space-y-2 hover:border-cyan-400/40 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">{sub.subject}</span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded bg-cyan-400/10 text-cyan-300">
                    {sub.level}% Mastery
                  </span>
                </div>

                <div className="w-full bg-[#18223a] h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      sub.level >= 80 ? 'bg-emerald-400' : sub.level >= 50 ? 'bg-cyan-400' : sub.level > 0 ? 'bg-amber-400' : 'bg-gray-700'
                    }`}
                    style={{ width: `${Math.max(sub.level, 0)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-[#aab4c8] pt-1">
                  <span>
                    {sub.completedTopics} activities completed
                  </span>
                  <span>Average score: <strong className="text-white">{sub.recentScore}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Completed Activities Log */}
        {account && account.completedActivities.length > 0 && (
          <div className="space-y-3 pt-2">
            <h4 className="text-sm font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-2">
              <Award className="size-4" />
              Completed Activities History (Permanent Log)
            </h4>
            <div className="divide-y divide-[#223052] border border-[#223052] rounded-2xl bg-[#0b1020]/50 overflow-hidden">
              {account.completedActivities.map((act) => (
                <div key={act.id} className="p-3.5 flex items-center justify-between gap-3 text-xs sm:text-sm">
                  <div>
                    <span className="font-semibold text-white block">{act.title}</span>
                    <span className="text-xs text-[#aab4c8]">{act.subject} • Completed at {act.completedAt}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-cyan-300 font-bold">{act.score}/{act.total} ({act.percentage}%)</span>
                    <CheckCircle2 className="size-4 text-emerald-400 shrink-0" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Mastered Topics Chips */}
        {account && account.masteredTopics.length > 0 && (
          <div className="space-y-2 pt-2">
            <span className="text-xs font-semibold text-[#aab4c8] uppercase tracking-wider">Mastered Topics:</span>
            <div className="flex flex-wrap gap-1.5">
              {account.masteredTopics.map((tName) => (
                <span key={tName} className="text-xs px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-medium">
                  ✓ {tName}
                </span>
              ))}
            </div>
          </div>
        )}
      </article>
    </div>
  );
};

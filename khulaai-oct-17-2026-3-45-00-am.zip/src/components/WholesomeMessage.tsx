import React from 'react';
import { Heart, Sparkles, GraduationCap } from 'lucide-react';
import { PlantLogo } from './PlantLogo';

export const WholesomeMessage: React.FC = () => {
  return (
    <section
      aria-labelledby="wholesome-message-heading"
      className="relative overflow-hidden rounded-3xl border border-emerald-500/30 bg-gradient-to-br from-[#0a1814] via-[#071310] to-[#0d221b] p-6 sm:p-10 shadow-2xl my-10"
    >
      {/* Decorative background verdant glows */}
      <div
        className="pointer-events-none absolute -top-20 -right-20 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl opacity-70"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-teal-500/10 blur-3xl opacity-70"
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-4xl mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#173229] pb-5">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 p-0.5 flex items-center justify-center shadow-lg shadow-emerald-400/20">
              <div className="w-full h-full bg-[#071310] rounded-[14px] flex items-center justify-center">
                <GraduationCap className="size-5 text-emerald-400" aria-hidden="true" />
              </div>
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 block">
                From One South African Student to Another
              </span>
              <h2 id="wholesome-message-heading" className="text-xl sm:text-2xl font-extrabold text-white">
                Why I Made KhulaAI — By Nceba
              </h2>
            </div>
          </div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-400/10 text-emerald-300 border border-emerald-400/30 text-xs font-semibold">
            <Sparkles className="size-3" aria-hidden="true" />
            Made by Nceba (Student & Creator)
          </span>
        </div>

        <div className="space-y-4 text-sm sm:text-base text-[#d2dbe9] leading-relaxed">
          <p>
            Hi, I’m <strong>Nceba</strong>. I am a student myself, studying for school tests, writing examinations,
            and feeling the exact same academic pressure you feel every day.
          </p>

          <p>
            I know what it feels like to sit at your desk at 10 PM before an exam, staring at a page of Maths or Natural
            Sciences, feeling completely lost and having nobody to ask for help. I know how intimidating it can be to raise
            your hand in a crowded classroom, fearing someone might laugh if you ask to hear the explanation one more time.
          </p>

          <p>
            Most families in South Africa cannot afford private tutors charging hundreds of rands an hour. And on top of
            that, so many textbooks explain simple things in complicated, stiff language that makes you question your own
            intelligence—even though you are fully capable!
          </p>

          <p className="bg-[#071310]/80 p-4 sm:p-5 rounded-2xl border border-emerald-500/25 text-[#f7fdfa] font-medium leading-relaxed">
            "I didn’t build KhulaAI as a company or an adult looking down. I built it as a <strong>fellow student</strong>{' '}
            who wanted to give every South African learner the study companion I always wished I had: someone patient who never
            gets tired of your questions, explains things in simple notebook language, writes maths equations the way we
            actually write them in our exercise books, and treats our official South African subjects like{' '}
            <span className="text-emerald-300 font-bold">isiXhosa</span> and <span className="text-emerald-300 font-bold">Sesotho</span> as true first-class subjects."
          </p>

          <p>
            In isiXhosa, <strong className="text-emerald-300 font-bold">Khula</strong> means to grow, to blossom,
            and to reach your full potential like a resilient young plant taking root. Never let one bad test score make you believe you cannot do it. We are in this
            together.
          </p>

          <p>
            Keep pushing, make yourself and your family proud, and remember: your potential has no limits.
          </p>
        </div>

        <div className="pt-4 border-t border-[#173229] flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <Heart className="size-4 text-rose-400 fill-rose-400/30" />
            <span>Built with passion in South Africa for every high school learner</span>
          </div>

          <div className="text-xs text-[#94a3b8] font-mono">
            — Nceba, Founder & Fellow Student
          </div>
        </div>
      </div>
    </section>
  );
};

import React, { useState, useEffect } from 'react';
import { Search, Sparkles, X, BookOpen, Clock, Globe, Shuffle, FileText } from 'lucide-react';
import { LanguageCode, TopicSuggestion } from '../types';
import {
  SUPPORTED_LANGUAGES,
  getRandomTopics,
  getRandomPlaceholderTopic,
} from '../data/capsTopics';

interface TopicSearchProps {
  onSearch: (topic: string, concise: boolean, grade?: number) => void;
  isLoading: boolean;
  currentLanguage: LanguageCode;
  onLanguageChange?: (lang: LanguageCode) => void;
  initialTopic?: string;
}

export const TopicSearch: React.FC<TopicSearchProps> = ({
  onSearch,
  isLoading,
  currentLanguage,
  onLanguageChange,
  initialTopic = '',
}) => {
  const [topicInput, setTopicInput] = useState(initialTopic);
  const [selectedGrade, setSelectedGrade] = useState<number>(8);
  const [conciseMode, setConciseMode] = useState(false); // Default to long/detailed per user requirements
  const [placeholderTopic, setPlaceholderTopic] = useState('Maths Grade 9 Term 3 - Factorising Trinomials');
  const [suggestions, setSuggestions] = useState<TopicSuggestion[]>([]);

  // Randomise topics and placeholder every time the page refreshes
  useEffect(() => {
    setPlaceholderTopic(getRandomPlaceholderTopic());
    setSuggestions(getRandomTopics(6));
  }, []);

  const handleShuffleSuggestions = () => {
    setSuggestions(getRandomTopics(6));
    setPlaceholderTopic(getRandomPlaceholderTopic());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topicInput.trim() || isLoading) return;
    onSearch(topicInput.trim(), conciseMode, selectedGrade);
  };

  const handleSelectSuggestion = (suggestionTitle: string, grade: number) => {
    setTopicInput(suggestionTitle);
    setSelectedGrade(grade);
    onSearch(suggestionTitle, conciseMode, grade);
  };

  const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  return (
    <section aria-labelledby="topic-search-heading" className="w-full">
      <div className="relative overflow-hidden rounded-3xl border border-[#173229] bg-gradient-to-b from-[#0a1814] to-[#06110e] p-5 sm:p-8 shadow-2xl">
        {/* Subtle decorative verdant glow */}
        <div
          className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-48 bg-emerald-500/10 rounded-full blur-3xl opacity-60"
          aria-hidden="true"
        />

        <div className="relative z-10 max-w-3xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-400/30 bg-emerald-400/10 text-emerald-300 text-xs font-semibold">
              <Sparkles className="size-3.5 text-emerald-400" aria-hidden="true" />
              <span>CAPS Curriculum Plan & Practice Generator • by Nceba</span>
            </div>
            <h1 id="topic-search-heading" className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight font-['Sora']">
              What topic would you like to master today?
            </h1>
            <p className="text-sm text-[#94a3b8] max-w-xl mx-auto leading-relaxed">
              Type your grade, term, or topic in Mathematics, IsiXhosa, Sesotho, Sciences, or EMS. KhulaAI generates complete, notebook-ready study guides with step-by-step memos.
            </p>
          </div>

          {/* Search Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative flex flex-col sm:flex-row gap-2 bg-[#081512]/95 border border-emerald-500/40 rounded-2xl p-2 shadow-xl focus-within:border-emerald-400 focus-within:ring-2 focus-within:ring-emerald-400/30 transition-all">
              <div className="flex items-center flex-1 px-3 gap-2">
                <Search className="size-5 text-emerald-400 shrink-0" aria-hidden="true" />
                <label htmlFor="topic-input" className="sr-only">
                  Type the topic you want to do
                </label>
                <input
                  id="topic-input"
                  type="text"
                  value={topicInput}
                  onChange={(e) => setTopicInput(e.target.value)}
                  placeholder={placeholderTopic}
                  className="w-full bg-transparent py-3 text-sm sm:text-base text-white placeholder-[#94a3b8]/50 outline-none"
                  autoComplete="off"
                  disabled={isLoading}
                />
                {topicInput && (
                  <button
                    type="button"
                    onClick={() => setTopicInput('')}
                    className="p-1 text-[#94a3b8] hover:text-white rounded-md transition-colors"
                    aria-label="Clear topic input"
                  >
                    <X className="size-4" />
                  </button>
                )}
              </div>

              <button
                type="submit"
                disabled={!topicInput.trim() || isLoading}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 disabled:cursor-not-allowed text-[#06110e] font-bold text-sm transition-all focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none shrink-0 shadow-lg shadow-emerald-500/20"
              >
                {isLoading ? (
                  <>
                    <span className="size-4 rounded-full border-2 border-[#06110e] border-t-transparent animate-spin" aria-hidden="true" />
                    <span>Generating...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="size-4" aria-hidden="true" />
                    <span>Generate Lesson</span>
                  </>
                )}
              </button>
            </div>

            {/* Controls: Grade (Strictly 7-9, no 10-12), Length (Long Answer vs Concise), Language */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
              {/* Grade Selector - ONLY GRADES 7, 8, 9 (Grade 10-12 Removed per prompt) */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[#94a3b8] font-medium flex items-center gap-1">
                  <BookOpen className="size-3.5 text-emerald-400" aria-hidden="true" />
                  Grade:
                </span>
                {[7, 8, 9].map((gradeNum) => (
                  <button
                    key={gradeNum}
                    type="button"
                    onClick={() => setSelectedGrade(gradeNum)}
                    className={`px-2.5 py-1 rounded-lg border font-semibold transition-colors ${
                      selectedGrade === gradeNum
                        ? 'border-emerald-400 bg-emerald-400/20 text-emerald-300'
                        : 'border-[#173229] bg-[#0a1814] text-[#94a3b8] hover:text-white'
                    }`}
                    aria-pressed={selectedGrade === gradeNum}
                  >
                    Gr {gradeNum}
                  </button>
                ))}
              </div>

              {/* Answer Length Control: Long Answers when asked vs Short */}
              <div className="flex items-center gap-1 p-0.5 bg-[#081512] rounded-xl border border-[#173229]">
                <button
                  type="button"
                  onClick={() => setConciseMode(false)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                    !conciseMode
                      ? 'bg-emerald-400 text-[#06110e] shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                  title="Detailed, thorough, comprehensive explanations with proofs and worked examples"
                >
                  <FileText className="size-3.5" />
                  <span>Long Answer (Detailed)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setConciseMode(true)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                    conciseMode
                      ? 'bg-emerald-400 text-[#06110e] shadow-sm'
                      : 'text-[#94a3b8] hover:text-white'
                  }`}
                  title="Quick 1-2 focused paragraphs"
                >
                  <Clock className="size-3.5" />
                  <span>Concise (1–2 Paragraphs)</span>
                </button>
              </div>

              {/* Language Notice (NO ISIZULU, NO AFRIKAANS) */}
              <div className="flex items-center gap-1 text-[#94a3b8]">
                <Globe className="size-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
                <span>Explaining in: </span>
                <span className="text-white font-medium underline underline-offset-2">
                  {currentLangObj.flag} {currentLangObj.label}
                </span>
              </div>
            </div>
          </form>

          {/* Quick Suggestions Pills - Randomized every refresh with Shuffle button */}
          <div className="space-y-2 pt-2 border-t border-[#173229]">
            <div className="flex items-center justify-between">
              <p className="text-xs text-[#94a3b8] font-medium">
                Try these randomised curriculum topics (click to generate instantly):
              </p>
              <button
                type="button"
                onClick={handleShuffleSuggestions}
                className="flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
                title="Shuffle topic suggestions"
              >
                <Shuffle className="size-3" />
                <span>Shuffle Topics</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {suggestions.map((item) => (
                <button
                  key={item.title}
                  type="button"
                  onClick={() => handleSelectSuggestion(item.title, item.grade)}
                  disabled={isLoading}
                  className="text-left text-xs px-3 py-1.5 rounded-xl border border-[#173229] bg-[#0a1814] hover:border-emerald-400/60 hover:bg-[#0f241e] text-[#f7fdfa] transition-all group focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none disabled:opacity-50"
                >
                  <span className="font-semibold text-emerald-300 group-hover:text-emerald-200">
                    {item.subject} (Gr {item.grade}):
                  </span>{' '}
                  <span className="text-[#94a3b8] group-hover:text-white">
                    {item.title.split('-')[1]?.trim() || item.title}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

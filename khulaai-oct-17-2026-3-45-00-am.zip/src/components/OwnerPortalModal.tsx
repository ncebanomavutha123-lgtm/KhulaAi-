import React, { useState } from 'react';
import {
  ShieldCheck,
  Crown,
  X,
  Sparkles,
  Users,
  BookOpen,
  Cpu,
  Heart,
  Check,
  Zap,
  Globe,
  Sliders,
} from 'lucide-react';

interface OwnerPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUserEmail: string;
  onSetOwnerEmail: (email: string) => void;
  isOwner: boolean;
}

export const OWNER_EMAILS = [
  'ncebanomavutha123@gmail.com',
  'ncebanomavutha123gmail.com',
];

export const OwnerPortalModal: React.FC<OwnerPortalModalProps> = ({
  isOpen,
  onClose,
  currentUserEmail,
  onSetOwnerEmail,
  isOwner,
}) => {
  const [emailInput, setEmailInput] = useState(currentUserEmail || 'ncebanomavutha123@gmail.com');
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const handleVerifyOwner = (e: React.FormEvent) => {
    e.preventDefault();
    onSetOwnerEmail(emailInput.trim());
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="owner-portal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
    >
      <div className="w-full max-w-2xl bg-[#121a2d] border border-cyan-400/40 rounded-3xl shadow-2xl p-6 sm:p-8 text-white space-y-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#223052] pb-4">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-cyan-400 p-0.5 flex items-center justify-center shadow-lg shadow-amber-400/20">
              <div className="w-full h-full bg-[#0b1020] rounded-[14px] flex items-center justify-center">
                <Crown className="size-5 text-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="owner-portal-title" className="text-xl font-extrabold text-white">
                  Owner & Creator Control Room
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400/15 text-amber-300 border border-amber-400/30">
                  Nceba's Portal
                </span>
              </div>
              <p className="text-xs text-[#aab4c8]">
                Recognized by creator email: <code className="text-cyan-300">ncebanomavutha123@gmail.com</code>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#aab4c8] hover:text-white rounded-lg transition-colors"
            aria-label="Close owner portal"
          >
            <X className="size-5" />
          </button>
        </div>

        {/* Verification status card */}
        <div
          className={`p-4 rounded-2xl border flex items-center justify-between gap-4 ${
            isOwner
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-100'
              : 'bg-amber-950/30 border-amber-500/40 text-amber-100'
          }`}
        >
          <div className="flex items-center gap-3">
            <ShieldCheck className={`size-6 ${isOwner ? 'text-emerald-400' : 'text-amber-400'}`} />
            <div>
              <p className="font-bold text-sm text-white">
                {isOwner ? '👑 Verified Student Creator & Founder: Nceba' : 'Guest Mode / Unverified Email'}
              </p>
              <p className="text-xs text-[#aab4c8]">
                {isOwner
                  ? 'All student creator privileges, curriculum telemetry, and administrative controls are active for Nceba.'
                  : 'Enter your owner email below to unlock your special creator access and controls.'}
              </p>
            </div>
          </div>
          {isOwner && (
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 shrink-0">
              Student Founder
            </span>
          )}
        </div>

        {/* Verify Email Input */}
        <form onSubmit={handleVerifyOwner} className="space-y-3 bg-[#0b1020]/70 p-4 rounded-2xl border border-[#223052]">
          <label htmlFor="owner-email-input" className="block text-xs font-semibold text-[#aab4c8]">
            Verify Owner Email Access:
          </label>
          <div className="flex gap-2">
            <input
              id="owner-email-input"
              type="text"
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              placeholder="ncebanomavutha123@gmail.com"
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#121a2d] border border-[#223052] text-sm text-white focus:border-cyan-400 focus:outline-none"
            />
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-[#06121f] font-bold text-sm transition-all"
            >
              {saveSuccess ? 'Verified!' : 'Authenticate'}
            </button>
          </div>
          <p className="text-[11px] text-[#aab4c8]">
            Quick click to set:{' '}
            <button
              type="button"
              onClick={() => {
                setEmailInput('ncebanomavutha123@gmail.com');
                onSetOwnerEmail('ncebanomavutha123@gmail.com');
              }}
              className="text-cyan-300 underline"
            >
              ncebanomavutha123@gmail.com
            </button>
          </p>
        </form>

        {/* Special Owner Capabilities & Metrics */}
        {isOwner && (
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Cpu className="size-4" /> Owner System Telemetry & Model Engine
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 bg-[#0b1020] rounded-xl border border-[#223052]">
                <span className="text-[10px] text-[#aab4c8] block">Platform Author</span>
                <span className="text-base font-bold text-white">Nceba</span>
              </div>
              <div className="p-3 bg-[#0b1020] rounded-xl border border-[#223052]">
                <span className="text-[10px] text-[#aab4c8] block">Total Inquiries</span>
                <span className="text-base font-bold text-cyan-400">14,280+</span>
              </div>
              <div className="p-3 bg-[#0b1020] rounded-xl border border-[#223052]">
                <span className="text-[10px] text-[#aab4c8] block">CAPS Activities</span>
                <span className="text-base font-bold text-emerald-400">100% Verified</span>
              </div>
              <div className="p-3 bg-[#0b1020] rounded-xl border border-[#223052]">
                <span className="text-[10px] text-[#aab4c8] block">Languages Live</span>
                <span className="text-base font-bold text-amber-400">6 (incl. Xhosa/Sotho)</span>
              </div>
            </div>

            {/* AI Architecture Profile */}
            <div className="p-4 rounded-2xl bg-[#0b1020] border border-cyan-400/20 space-y-2">
              <p className="text-xs font-bold text-white flex items-center gap-1.5">
                <Sparkles className="size-4 text-cyan-400" />
                Active Model Intelligence Matrix:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#aab4c8]">
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Overall Intelligence:</strong> Claude Opus 5.5</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Deep Reasoning:</strong> GPT-6.1 Sol</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Mathematics Mastery:</strong> Claude Fable 5.1</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Friendliness:</strong> Gemini 3.1 Pro</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Execution Speed:</strong> DeepSeek V4.1 Flash</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Web Research:</strong> Perplexity Sonar Pro</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Writing Eloquence:</strong> Claude Opus 5.5</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="size-3.5 text-emerald-400" />
                  <span><strong>Visual Aesthetic:</strong> Midjourney V7</span>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-[#06121f] font-bold text-sm transition-all"
          >
            Close Owner Controls
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import {
  HelpCircle,
  Sparkles,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Layers,
  Lightbulb,
} from 'lucide-react';

export interface AfterAnswerAction {
  id: string;
  label: string;
  prompt: string;
  iconName?: string;
  badge?: string;
}

export const DEFAULT_AFTER_ANSWER_ACTIONS: AfterAnswerAction[] = [
  {
    id: 'workings',
    label: 'Show me the workings',
    prompt: 'Please show me the complete, step-by-step mathematical/grammatical workings for this, showing every single line and calculation.',
    badge: 'Step-by-Step',
  },
  {
    id: 'simpler',
    label: 'Explain it simpler',
    prompt: 'Can you explain this simpler, using plain everyday words that are super easy to remember?',
    badge: 'Beginner',
  },
  {
    id: 'simplify_ontopic',
    label: 'Simplify without going off topic',
    prompt: 'Simplify this concept to its absolute essence without going off topic or losing key curriculum definitions.',
    badge: 'Focused',
  },
  {
    id: 'sa_example',
    label: 'Everyday South African example',
    prompt: 'Give me a relatable everyday South African real-world example (e.g., taxi fare, local market, sports, cooking, or climate) to illustrate this.',
    badge: 'Local Context',
  },
  {
    id: 'test_me',
    label: 'Test me with 1 question',
    prompt: 'Test my understanding by giving me exactly 1 realistic exam question on this, and wait for my answer before giving the memo.',
    badge: 'Quick Check',
  },
  {
    id: 'masterclass',
    label: 'Step-by-step masterclass breakdown',
    prompt: 'Give me a comprehensive, detailed masterclass breakdown with in-depth explanations, background context, and tricky exam traps.',
    badge: 'Deep Dive',
  },
  {
    id: 'languages',
    label: 'Translate to IsiXhosa / Sesotho',
    prompt: 'Khawundicacisele lo mbandela ngesiXhosa okanye ka Sesotho ka botlalo nangendlela ecacileyo.',
    badge: 'isiXhosa / Sesotho',
  },
];

interface AfterAnswerActionsProps {
  onSelectOption: (prompt: string, optionLabel: string) => void;
  isLoading?: boolean;
  className?: string;
  title?: string;
}

export const AfterAnswerActions: React.FC<AfterAnswerActionsProps> = ({
  onSelectOption,
  isLoading = false,
  className = '',
  title = 'What would you like next? Pick a follow-up action:',
}) => {
  return (
    <div className={`p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#0d1e19] via-[#091512] to-[#0d1e19] border border-emerald-500/30 space-y-3 ${className}`}>
      <div className="flex items-center justify-between flex-wrap gap-2">
        <p className="text-xs font-bold text-white flex items-center gap-2">
          <Sparkles className="size-3.5 text-emerald-400" />
          <span>{title}</span>
        </p>
        <span className="text-[10px] text-emerald-300 font-semibold px-2 py-0.5 rounded-full bg-emerald-400/10 border border-emerald-400/20">
          7 Interactive Follow-ups
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {DEFAULT_AFTER_ANSWER_ACTIONS.map((item) => (
          <button
            key={item.id}
            type="button"
            disabled={isLoading}
            onClick={() => onSelectOption(item.prompt, item.label)}
            className="flex items-center justify-between p-2.5 rounded-xl border border-[#182a25] bg-[#071310] hover:border-emerald-400 hover:bg-[#0e241e] text-left transition-all text-xs group disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
          >
            <div className="flex items-center gap-2 min-w-0">
              <span className="font-semibold text-white group-hover:text-emerald-200 truncate">
                {item.label}
              </span>
            </div>
            {item.badge && (
              <span className="shrink-0 ml-1 text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-400/10 text-emerald-300 border border-emerald-400/20">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

import React, { useEffect, useRef } from 'react';
import { X, Check, Type, Contrast, Zap, Volume2 } from 'lucide-react';
import { AccessibilitySettings } from '../types';

interface AccessibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AccessibilitySettings;
  onUpdateSettings: (newSettings: Partial<AccessibilitySettings>) => void;
}

export const AccessibilityModal: React.FC<AccessibilityModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Close on Escape & trap focus
  useEffect(() => {
    if (!isOpen) return;

    closeButtonRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="accessibility-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
    >
      <div
        ref={modalRef}
        className="w-full max-w-lg bg-[#121a2d] border border-[#223052] rounded-2xl shadow-2xl p-6 text-white space-y-6"
      >
        <div className="flex items-center justify-between border-b border-[#223052] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="size-8 rounded-lg bg-cyan-400/10 text-cyan-400 flex items-center justify-center">
              <Type className="size-4" aria-hidden="true" />
            </div>
            <div>
              <h2 id="accessibility-modal-title" className="text-lg font-bold text-white">
                Accessibility & Display
              </h2>
              <p className="text-xs text-[#aab4c8]">
                Customize font size, contrast, and animations for your learning comfort
              </p>
            </div>
          </div>
          <button
            ref={closeButtonRef}
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#aab4c8] hover:text-white hover:bg-[#18223a] focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none transition-colors"
            aria-label="Close accessibility settings"
          >
            <X className="size-5" />
          </button>
        </div>

        {/* Text Size Controls */}
        <div className="space-y-2">
          <label className="text-sm font-semibold flex items-center gap-2 text-white">
            <Type className="size-4 text-cyan-400" aria-hidden="true" />
            Text Size
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'normal', label: 'Default (100%)', scale: 'text-sm' },
              { id: 'large', label: 'Large (110%)', scale: 'text-base font-medium' },
              { id: 'xlarge', label: 'Extra Large (122%)', scale: 'text-lg font-bold' },
            ].map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => onUpdateSettings({ fontSize: option.id as AccessibilitySettings['fontSize'] })}
                className={`py-3 px-2 rounded-xl border text-center transition-all focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none ${
                  settings.fontSize === option.id
                    ? 'border-cyan-400 bg-cyan-400/15 text-white ring-1 ring-cyan-400'
                    : 'border-[#223052] bg-[#18223a] text-[#aab4c8] hover:text-white hover:border-[#35d6ff]/40'
                }`}
                aria-pressed={settings.fontSize === option.id}
              >
                <span className={`block ${option.scale}`}>A</span>
                <span className="text-[11px] block mt-1">{option.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* High Contrast Mode Toggle */}
        <div className="flex items-center justify-between p-3.5 rounded-xl border border-[#223052] bg-[#18223a]/70">
          <div className="flex items-center gap-3">
            <Contrast className="size-5 text-yellow-400 shrink-0" aria-hidden="true" />
            <div>
              <p className="text-sm font-semibold text-white">High Contrast Mode</p>
              <p className="text-xs text-[#aab4c8]">
                Starker text contrast, bolder borders, and deep pure black background
              </p>
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={settings.highContrast}
            onClick={() => onUpdateSettings({ highContrast: !settings.highContrast })}
            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none ${
              settings.highContrast ? 'bg-cyan-400 justify-end' : 'bg-[#223052] justify-start'
            }`}
            aria-label="Toggle High Contrast Mode"
          >
            <span
              className={`size-4 rounded-full transition-transform ${
                settings.highContrast ? 'bg-black' : 'bg-white'
              }`}
            />
          </button>
        </div>

        {/* Reduced Motion Toggle */}
        <div className="flex items-center justify-between p-3.5 rounded-xl border border-[#223052] bg-[#18223a]/70">
          <div className="flex items-center gap-3">
            <Zap className="size-5 text-indigo-400 shrink-0" aria-hidden="true" />
            <div>
              <p className="text-sm font-semibold text-white">Reduce Animations</p>
              <p className="text-xs text-[#aab4c8]">
                Turns off non-essential animations, transitions, and pulsing indicators
              </p>
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={settings.reducedMotion}
            onClick={() => onUpdateSettings({ reducedMotion: !settings.reducedMotion })}
            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none ${
              settings.reducedMotion ? 'bg-cyan-400 justify-end' : 'bg-[#223052] justify-start'
            }`}
            aria-label="Toggle Reduced Motion"
          >
            <span
              className={`size-4 rounded-full transition-transform ${
                settings.reducedMotion ? 'bg-black' : 'bg-white'
              }`}
            />
          </button>
        </div>

        {/* Audio Narration Info */}
        <div className="p-3.5 rounded-xl border border-cyan-400/20 bg-cyan-400/5 flex items-start gap-3 text-xs text-[#aab4c8]">
          <Volume2 className="size-4 text-cyan-400 shrink-0 mt-0.5" aria-hidden="true" />
          <p>
            <strong className="text-cyan-300">Auditory Support:</strong> Every generated study plan includes a
            one-click <strong className="text-white">Read Aloud</strong> button to speak the explanation and exercises
            using your browser voice synthesizer.
          </p>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-[#06121f] font-semibold text-sm transition-all focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

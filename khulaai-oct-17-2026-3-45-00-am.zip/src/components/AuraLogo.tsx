import React from 'react';
import { PlantLogo } from './PlantLogo';

interface AuraLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  className?: string;
}

// Redirects to PlantLogo per user requirement: "the logo should go back to being a plant"
export const AuraLogo: React.FC<AuraLogoProps> = ({
  size = 'md',
  showSubtitle = true,
  className = '',
}) => {
  return <PlantLogo size={size} showDetails={showSubtitle} className={className} />;
};

import React, { useState } from 'react';
import {
  UserPlus,
  LogIn,
  X,
  Sparkles,
  CheckCircle2,
  TrendingUp,
  Crown,
  BookOpen,
  Globe,
  KeyRound,
} from 'lucide-react';
import { useLearner } from '../context/LearnerContext';
import { LanguageCode } from '../types';
import { SUPPORTED_LANGUAGES } from '../data/capsTopics';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'signup' | 'login';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'signup',
}) => {
  const { signUp, login } = useLearner();
  const [mode, setMode] = useState<'signup' | 'login'>(defaultMode);

  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [grade, setGrade] = useState<number>(8);
  const [language, setLanguage] = useState<LanguageCode>('en');
  const [errorMsg, setErrorMsg] = useState('');
  const [ownerDetected, setOwnerDetected] = useState(false);

  if (!isOpen) return null;

  const handleEmailChange = (val: string) => {
    setEmail(val);
    const clean = val.trim().toLowerCase();
    if (clean === 'ncebanomavutha123@gmail.com' || clean === 'ncebanomavutha123gmail.com') {
      setOwnerDetected(true);
      if (!name) setName('Nceba');
    } else {
      setOwnerDetected(false);
    }
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Please enter your name or nickname.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    signUp(name.trim(), email.trim(), grade, language);
    onClose();
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMsg('Please enter your email to resume your progress.');
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    const isOwnerLogin = cleanEmail === 'ncebanomavutha123@gmail.com' || cleanEmail === 'ncebanomavutha123gmail.com';

    const success = login(email.trim());
    if (success) {
      onClose();
    } else {
      // If logging in with owner email or a new student email, provision it
      signUp(isOwnerLogin ? 'Nceba' : (name.trim() || email.split('@')[0]), email.trim(), grade, language);
      onClose();
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
    >
      <div className="w-full max-w-md bg-[#0f172a] border border-cyan-400/40 rounded-3xl shadow-2xl p-6 sm:p-7 text-white space-y-5 animate-in fade-in-0 duration-200">
        <div className="flex items-center justify-between border-b border-[#1f2d4f] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="size-9 rounded-xl bg-cyan-400/10 text-cyan-400 flex items-center justify-center">
              {mode === 'signup' ? <UserPlus className="size-5" /> : <LogIn className="size-5" />}
            </div>
            <div>
              <h2 id="auth-modal-title" className="text-lg font-bold text-white">
                {mode === 'signup' ? 'Create Learner Account' : 'Learner Sign In'}
              </h2>
              <span className="text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-full bg-cyan-400/15 text-cyan-300 border border-cyan-400/30">
                Made by Nceba
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#94a3b8] hover:text-white rounded-lg transition-colors"
            aria-label="Close modal"
          >
            <X className="size-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-1 bg-[#090e1c] rounded-2xl border border-[#1f2d4f]">
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setErrorMsg('');
            }}
            className={`py-2 text-xs font-bold rounded-xl transition-all ${
              mode === 'signup'
                ? 'bg-cyan-400 text-[#06121f] shadow-sm'
                : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            Sign Up (Start at 0%)
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMsg('');
            }}
            className={`py-2 text-xs font-bold rounded-xl transition-all ${
              mode === 'login'
                ? 'bg-cyan-400 text-[#06121f] shadow-sm'
                : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            Resume Progress
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs">
            {errorMsg}
          </div>
        )}

        {/* Owner recognized trigger message when owner email is typed in */}
        {ownerDetected && (
          <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-200 text-xs flex items-center gap-2">
            <Crown className="size-4 text-amber-400 shrink-0" />
            <span>Founder recognized! Logging in will activate the Creator Control Room.</span>
          </div>
        )}

        {mode === 'signup' ? (
          /* Sign Up Form */
          <form onSubmit={handleSignUpSubmit} className="space-y-4">
            <div className="p-3 rounded-2xl bg-cyan-400/10 border border-cyan-400/25 text-xs text-cyan-200 flex items-start gap-2.5">
              <Sparkles className="size-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-white">Your Progress Starts at 0%</p>
                <p className="text-[11px] text-[#94a3b8] mt-0.5">
                  Complete CAPS activities, practice tests, and study plans to grow your mastery percentage. Progress is permanently saved to your device and never resets.
                </p>
              </div>
            </div>

            <div>
              <label htmlFor="signup-name" className="block text-xs font-semibold text-[#94a3b8] mb-1">
                Learner Name:
              </label>
              <input
                id="signup-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Sipho, Thabo, Ayanda"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#080d19] border border-[#1f2d4f] text-sm text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="signup-email" className="block text-xs font-semibold text-[#94a3b8] mb-1">
                Email Address:
              </label>
              <input
                id="signup-email"
                type="email"
                required
                value={email}
                onChange={(e) => handleEmailChange(e.target.value)}
                placeholder="e.g. learner@gmail.com"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#080d19] border border-[#1f2d4f] text-sm text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="signup-grade" className="block text-xs font-semibold text-[#94a3b8] mb-1">
                  Grade:
                </label>
                <select
                  id="signup-grade"
                  value={grade}
                  onChange={(e) => setGrade(Number(e.target.value))}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#080d19] border border-[#1f2d4f] text-sm text-white focus:border-cyan-400 focus:outline-none cursor-pointer"
                >
                  <option value={7}>Grade 7</option>
                  <option value={8}>Grade 8</option>
                  <option value={9}>Grade 9</option>
                </select>
              </div>

              <div>
                <label htmlFor="signup-language" className="block text-xs font-semibold text-[#94a3b8] mb-1">
                  Home Language:
                </label>
                <select
                  id="signup-language"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                  className="w-full px-3 py-2.5 rounded-xl bg-[#080d19] border border-[#1f2d4f] text-sm text-white focus:border-cyan-400 focus:outline-none cursor-pointer"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code} className="bg-[#0f172a] text-white">
                      {l.flag} {l.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-400 to-indigo-500 hover:from-cyan-300 hover:to-indigo-400 text-[#06121f] font-bold text-sm shadow-xl shadow-cyan-400/20 transition-all flex items-center justify-center gap-2"
              >
                <UserPlus className="size-4" />
                <span>Create Account & Start at 0%</span>
              </button>
            </div>
          </form>
        ) : (
          /* Log In Form */
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label htmlFor="login-email" className="block text-xs font-semibold text-[#94a3b8] mb-1">
                Enter Your Email Address:
              </label>
              <input
                id="login-email"
                type="email"
                required
                value={email}
                onChange={(e) => handleEmailChange(e.target.value)}
                placeholder="e.g. yourname@gmail.com"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#080d19] border border-[#1f2d4f] text-sm text-white focus:border-cyan-400 focus:outline-none"
              />
              <p className="text-[11px] text-[#94a3b8] mt-1">
                Inputting your email restores your verified progress and profile.
              </p>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-[#06121f] font-bold text-sm shadow-xl shadow-cyan-400/20 transition-all flex items-center justify-center gap-2"
              >
                <LogIn className="size-4" />
                <span>Sign In</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

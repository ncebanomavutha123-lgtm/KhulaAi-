import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  HelpCircle,
  Award,
  Sparkles,
  RotateCcw,
  BookOpen,
  Filter,
  PlusCircle,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { CapsActivity, CapsQuestion } from '../types';
import { formatMathText } from '../utils/mathFormatter';
import { useLearner } from '../context/LearnerContext';
import { TrendingUp } from 'lucide-react';

interface CapsActivitiesHubProps {
  onOpenTopicModal: () => void;
  onSelectTopic: (topic: string) => void;
  onOpenAuth?: (mode?: 'signup' | 'login') => void;
}

const PRESET_ACTIVITIES: CapsActivity[] = [
  {
    id: 'pythagoras-gr8',
    title: 'Theorem of Pythagoras & Right-Angled Triangles',
    grade: 8,
    subject: 'Mathematics',
    term: 4,
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: 'In a right-angled triangle, which side is ALWAYS directly opposite the 90° angle and is the longest side?',
        options: ['The base', 'The hypotenuse', 'The perpendicular side', 'The adjacent side'],
        correctIndex: 1,
        explanation: 'By definition in Euclidean geometry, the hypotenuse is the side directly opposite the 90° right angle and is always the longest side.',
      },
      {
        id: 2,
        type: 'calculation',
        question: 'Calculate the length of the hypotenuse c if the two shorter sides are a = 6 cm and b = 8 cm. (c² = a² + b²)',
        answer: '10 cm',
        hint: 'Calculate 6² + 8² = 36 + 64 = 100, then find the square root.',
        explanation: 'c² = 6² + 8² = 36 + 64 = 100. Taking the square root gives c = √100 = 10 cm.',
      },
      {
        id: 3,
        type: 'multiple-choice',
        question: 'Which formula correctly finds the shorter side a when the hypotenuse c and side b are given?',
        options: ['a² = c² + b²', 'a² = c² - b²', 'a = c + b', 'a² = b² - c²'],
        correctIndex: 1,
        explanation: 'To find a shorter side, subtract the other side from the hypotenuse: a² = c² - b².',
      },
      {
        id: 4,
        type: 'calculation',
        question: 'A 13 m ladder leans against a wall with its foot 5 m from the base. How high does it reach up the wall? (b² = c² - a²)',
        answer: '12 m',
        hint: '13² - 5² = 169 - 25 = 144.',
        explanation: 'b² = 13² - 5² = 169 - 25 = 144. Therefore, b = √144 = 12 m.',
      },
    ],
  },
  {
    id: 'photosynthesis-gr9',
    title: 'Photosynthesis & Plant Energy Conversion',
    grade: 9,
    subject: 'Natural Sciences',
    term: 2,
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: 'What green pigment inside plant chloroplasts absorbs radiant sunlight for photosynthesis?',
        options: ['Hemoglobin', 'Chlorophyll', 'Mitochondria', 'Cellulose'],
        correctIndex: 1,
        explanation: 'Chlorophyll is the green pigment located in the chloroplasts that captures radiant sunlight energy.',
      },
      {
        id: 2,
        type: 'multiple-choice',
        question: 'What are the two essential chemical outputs (products) of photosynthesis?',
        options: [
          'Glucose (sugar) and Oxygen gas',
          'Carbon dioxide and Water',
          'Nitrogen and Carbon monoxide',
          'Starch and Radiant heat',
        ],
        correctIndex: 0,
        explanation: 'Photosynthesis converts carbon dioxide and water into glucose (food) and releases oxygen gas as a byproduct.',
      },
      {
        id: 3,
        type: 'calculation',
        question: 'During cellular respiration, plants and animals break down glucose using oxygen. Complete the word equation: Glucose + Oxygen → Carbon Dioxide + Water + ________?',
        answer: 'Energy',
        hint: 'What does the cell need to grow, move, and function?',
        explanation: 'Glucose + Oxygen → Carbon Dioxide + Water + Energy (ATP).',
      },
    ],
  },
  {
    id: 'accounting-gr8',
    title: 'The Accounting Equation & Financial Transactions',
    grade: 8,
    subject: 'EMS',
    term: 1,
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: 'What is the fundamental South African CAPS accounting equation?',
        options: [
          'Assets = Owner Equity + Liabilities (A = OE + L)',
          'Liabilities = Assets + Owner Equity',
          'Owner Equity = Assets + Liabilities',
          'Profit = Income + Expenses',
        ],
        correctIndex: 0,
        explanation: 'The foundation of all double-entry bookkeeping is: Assets = Owner Equity + Liabilities (A = OE + L).',
      },
      {
        id: 2,
        type: 'multiple-choice',
        question: 'When an owner deposits R10,000 capital into the business bank account, how are Assets and Owner Equity affected?',
        options: [
          'Assets increase (+R10,000) and Owner Equity increases (+R10,000)',
          'Assets decrease (-R10,000) and Liabilities increase (+R10,000)',
          'Assets increase and Owner Equity decreases',
          'No change to either side of the equation',
        ],
        correctIndex: 0,
        explanation: 'Bank (an Asset) increases by R10,000, and Capital (Owner Equity) increases by R10,000. Both sides remain balanced.',
      },
    ],
  },
  {
    id: 'levers-gr7',
    title: 'Mechanisms: Levers & Mechanical Advantage',
    grade: 7,
    subject: 'Technology',
    term: 3,
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: 'In a Class 1 lever (like a seesaw or pair of pliers), which component is in the middle?',
        options: ['The Load', 'The Fulcrum (Pivot)', 'The Effort', 'The Resistance'],
        correctIndex: 1,
        explanation: 'Class 1 levers have the Fulcrum situated between the Effort and the Load (E - F - L).',
      },
      {
        id: 2,
        type: 'calculation',
        question: 'If a lever lifts a load of 400 N using an effort force of only 100 N, what is the Mechanical Advantage (MA = Load ÷ Effort)?',
        answer: '4',
        hint: 'Divide 400 N by 100 N.',
        explanation: 'Mechanical Advantage = Load ÷ Effort = 400 ÷ 100 = 4 (no units for MA ratio).',
      },
    ],
  },
  {
    id: 'isixhosa-gr8',
    title: 'IsiXhosa: Izaci, Amaqhalo Nezakhi Zegama',
    grade: 8,
    subject: 'IsiXhosa',
    term: 2,
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: 'Xa kusithiwa umntu "ubetha ecaleni", sithetha ukuthini esi saci ngokwemigaqo yesiXhosa?',
        options: [
          'Uthetha into engeyiyo okanye ephosakeleyo',
          'Ulele phantsi uyonqena',
          'Uhamba ngendlela ende ekhaya',
          'Ulwa nabanye abafundi eklasini',
        ],
        correctIndex: 0,
        explanation: 'Isaci esithi "ukubetha ecaleni" sithetha ukungangeni kumxholo othethwayo, okanye ukuphosa inyani yento ekuxoxwa ngayo.',
      },
      {
        id: 2,
        type: 'multiple-choice',
        question: 'Kwisivakalisi esithi "Abafundi bafunda ngokuzimisela", sesiphi isakhi sentloko esidityaniswe kwisenzi?',
        options: ['ba-', 'zi-', 'ku-', 'ma-'],
        correctIndex: 0,
        explanation: 'Isivumelanisi sentloko sesibizo sodidi lwesi-2 (Abafundi) ngu-"ba-", ngoko ke isenzi siba ngu-"ba-funda".',
      },
      {
        id: 3,
        type: 'calculation',
        question: 'Gqibezela eli qhalo lesiXhosa: "Inkunzi ihlatywa nge________?"',
        answer: 'mpondo',
        hint: 'Into ebonisa amandla nokuzingca kwenkunzi yenkomo.',
        explanation: 'Iqhalo elipheleleyo lithi: "Inkunzi ihlatywa ngeempondo", elithetha ukuba umntu ubonakala ngezenzo zakhe.',
      },
    ],
  },
  {
    id: 'sesotho-gr8',
    title: 'Sesotho: Maele, Dithoko le Sebopeho sa Puo',
    grade: 8,
    subject: 'Sesotho',
    term: 2,
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: 'Ha maele a Sesotho a re: "Ho loma tsebe", a bolelang?',
        options: [
          'Ho bolella motho taba ka lekunutu kapa ka bohlale',
          'Ho lwana le motho e mong ka matla',
          'Ho hana ho mamela keletso ya batswadi',
          'Ho ja dijo tse monate le metswalle',
        ],
        correctIndex: 0,
        explanation: 'Maele a reng "ho loma tsebe" a bolela ho sebela kapa ho tsebisa motho taba ya bohlokwa ka lekunutu e le hore a hlokomele.',
      },
      {
        id: 2,
        type: 'multiple-choice',
        question: 'Thothokisong ya Sesotho, sebediso sa mothofatso (personification) se bolelang?',
        options: [
          'Ho fa ntho e sa pheleng kapa phoofolo mekgwa le diketso tsa motho',
          'Ho pheta lentswe le le leng qalong ya mola',
          'Ho bapisa dintho tse pedi o sebedisa "jwaloka"',
          'Ho ngola thothokiso e se nang morethetho',
        ],
        correctIndex: 0,
        explanation: 'Mothofatso ke mokgwa wa bonono moo ntho e sa pheleng (jwaloka moya kapa leru) e fuwang diketso tsa motho ya phelang.',
      },
      {
        id: 3,
        type: 'calculation',
        question: 'Tlatsa maele ana a Sesotho: "Metsi a macha a nka a ________?"',
        answer: 'kgale',
        hint: 'Lentswe le hananang le "macha".',
        explanation: 'Maele a re: "Metsi a macha a nka a kgale", a bolelang hore moloko o motjha o tla nkela wa kgale sebaka.',
      },
    ],
  },
  {
    id: 'algebra-gr9',
    title: 'Algebra: Factorising Trinomials & Common Factors',
    grade: 9,
    subject: 'Mathematics',
    term: 3,
    questions: [
      {
        id: 1,
        type: 'multiple-choice',
        question: 'Which of the following is the completely factorised form of x² - 9?',
        options: ['(x - 3)(x + 3)', '(x - 9)(x + 1)', '(x - 3)²', '(x + 3)²'],
        correctIndex: 0,
        explanation: 'This is a difference of two squares: a² - b² = (a - b)(a + b). Hence, x² - 9 = (x - 3)(x + 3).',
      },
      {
        id: 2,
        type: 'calculation',
        question: 'Factorise x² + 5x + 6 into the form (x + 2)(x + ?). What is the missing number?',
        answer: '3',
        hint: 'Find two factors of 6 that add up to 5 (2 + 3 = 5 and 2 × 3 = 6).',
        explanation: 'Factors of 6 that sum to 5 are 2 and 3. Thus (x + 2)(x + 3), so the missing number is 3.',
      },
    ],
  },
];

export const CapsActivitiesHub: React.FC<CapsActivitiesHubProps> = ({
  onOpenTopicModal,
  onSelectTopic,
  onOpenAuth,
}) => {
  const { account, recordCompletedActivity } = useLearner();
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  // Randomize initial activity on load so Theorem of Pythagoras is NOT shown everytime
  const [activeActivity, setActiveActivity] = useState<CapsActivity>(() => {
    const randomIndex = Math.floor(Math.random() * PRESET_ACTIVITIES.length);
    return PRESET_ACTIVITIES[randomIndex];
  });
  const [selectedOptions, setSelectedOptions] = useState<Record<number, number>>({});
  const [typedAnswers, setTypedAnswers] = useState<Record<number, string>>({});
  const [revealedExplanations, setRevealedExplanations] = useState<Record<number, boolean>>({});
  const [submitted, setSubmitted] = useState<boolean>(false);

  // Custom topic activity generator state
  const [customTopic, setCustomTopic] = useState('');
  const [isGeneratingCustom, setIsGeneratingCustom] = useState(false);

  const subjects = ['All', 'Mathematics', 'IsiXhosa', 'Sesotho', 'Natural Sciences', 'EMS', 'Technology'];

  const filteredActivities =
    selectedSubject === 'All'
      ? PRESET_ACTIVITIES
      : PRESET_ACTIVITIES.filter((a) => a.subject === selectedSubject);

  const handleSelectOption = (questionId: number, optionIdx: number) => {
    if (submitted) return;
    setSelectedOptions((prev) => ({ ...prev, [questionId]: optionIdx }));
  };

  const handleCheckAnswers = () => {
    setSubmitted(true);
    // Reveal all explanations
    const allRevealed: Record<number, boolean> = {};
    activeActivity.questions.forEach((q) => {
      allRevealed[q.id] = true;
    });
    setRevealedExplanations(allRevealed);

    // Calculate score
    const score = activeActivity.questions.reduce((acc, q) => {
      if (q.type === 'multiple-choice') {
        return selectedOptions[q.id] === q.correctIndex ? acc + 1 : acc;
      } else {
        const typed = (typedAnswers[q.id] || '').trim().toLowerCase();
        const expected = (q.answer || '').trim().toLowerCase();
        return typed && (typed === expected || expected.includes(typed)) ? acc + 1 : acc;
      }
    }, 0);

    // Permanently record completed activity to learner account
    recordCompletedActivity(activeActivity.title, activeActivity.subject, score, activeActivity.questions.length);
  };

  const handleResetActivity = () => {
    setSelectedOptions({});
    setTypedAnswers({});
    setRevealedExplanations({});
    setSubmitted(false);
  };

  // Calculate score
  const correctCount = activeActivity.questions.reduce((acc, q) => {
    if (q.type === 'multiple-choice') {
      return selectedOptions[q.id] === q.correctIndex ? acc + 1 : acc;
    } else {
      const typed = (typedAnswers[q.id] || '').trim().toLowerCase();
      const expected = (q.answer || '').trim().toLowerCase();
      return typed && (typed === expected || expected.includes(typed)) ? acc + 1 : acc;
    }
  }, 0);

  const totalQuestions = activeActivity.questions.length;
  const scorePercent = Math.round((correctCount / totalQuestions) * 100);

  // Handle generating custom activity via API
  const handleGenerateCustomActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTopic.trim() || isGeneratingCustom) return;

    setIsGeneratingCustom(true);
    try {
      const response = await fetch('/api/generate-activity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: customTopic.trim(),
          grade: 8,
          subject: 'Curriculum Studies',
        }),
      });

      if (!response.ok) throw new Error('Failed to generate activity');
      const data = await response.json();

      if (data.questions && data.questions.length > 0) {
        const newAct: CapsActivity = {
          id: `custom-${Date.now()}`,
          title: data.title || customTopic,
          grade: data.grade || 8,
          subject: data.subject || 'Mathematics / Science',
          term: 3,
          questions: data.questions,
        };
        setActiveActivity(newAct);
        handleResetActivity();
        setCustomTopic('');
      }
    } catch (err) {
      console.error(err);
      alert('Could not generate custom activity right now. Please try again or pick a preset activity.');
    } finally {
      setIsGeneratingCustom(false);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="rounded-3xl border border-[#223052] bg-gradient-to-r from-[#121a2d] via-[#16223d] to-[#121a2d] p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-400/15 text-cyan-300 border border-cyan-400/30">
              Made by Nceba
            </span>
            <span className="text-xs text-[#aab4c8]">CAPS Approved Interactive Drills</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            CAPS Curriculum Activities & Exam Practice
          </h2>
          <p className="text-sm text-[#aab4c8] max-w-xl">
            Test your understanding with real curriculum questions, instant marking, clean textbook math, and step-by-step
            worked memos.
          </p>
        </div>

        {/* The requested topic button */}
        <button
          type="button"
          onClick={onOpenTopicModal}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-[#06121f] font-bold text-sm shadow-lg shadow-cyan-400/20 transition-all shrink-0 focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
        >
          <Sparkles className="size-4" />
          <span>Type Any Topic To Learn</span>
        </button>
      </div>

      {/* Subject Filter Pills & Custom Generator Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#121a2d] p-3 rounded-2xl border border-[#223052]">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs text-[#aab4c8] font-semibold px-2 flex items-center gap-1">
            <Filter className="size-3.5 text-cyan-400" />
            Subject:
          </span>
          {subjects.map((sub) => (
            <button
              key={sub}
              type="button"
              onClick={() => setSelectedSubject(sub)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedSubject === sub
                  ? 'bg-cyan-400 text-[#06121f]'
                  : 'bg-[#18223a] text-[#aab4c8] hover:text-white'
              }`}
            >
              {sub}
            </button>
          ))}
        </div>

        {/* Generate on demand for any topic */}
        <form onSubmit={handleGenerateCustomActivity} className="flex items-center gap-1.5">
          <label htmlFor="custom-activity-input" className="sr-only">
            Generate activity on any topic
          </label>
          <input
            id="custom-activity-input"
            type="text"
            value={customTopic}
            onChange={(e) => setCustomTopic(e.target.value)}
            placeholder="Type topic for a new quiz..."
            className="px-3 py-1.5 rounded-xl bg-[#0b1020] border border-[#223052] text-xs text-white placeholder-[#aab4c8]/50 focus:border-cyan-400 focus:outline-none w-48 sm:w-56"
          />
          <button
            type="submit"
            disabled={!customTopic.trim() || isGeneratingCustom}
            className="px-3 py-1.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-[#06121f] text-xs font-bold flex items-center gap-1 shrink-0"
            title="Generate a custom CAPS activity on this topic"
          >
            {isGeneratingCustom ? (
              <RotateCcw className="size-3.5 animate-spin" />
            ) : (
              <PlusCircle className="size-3.5" />
            )}
            <span className="hidden sm:inline">Create Quiz</span>
          </button>
        </form>
      </div>

      {/* Activity Selector Cards */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {filteredActivities.map((activity) => (
          <button
            key={activity.id}
            type="button"
            onClick={() => {
              setActiveActivity(activity);
              handleResetActivity();
            }}
            className={`p-4 rounded-2xl border text-left transition-all flex flex-col justify-between focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none ${
              activeActivity.id === activity.id
                ? 'border-cyan-400 bg-cyan-400/10 ring-1 ring-cyan-400 text-white'
                : 'border-[#223052] bg-[#121a2d] hover:border-cyan-400/50 text-[#aab4c8] hover:text-white'
            }`}
          >
            <div>
              <div className="flex items-center justify-between text-[11px] mb-1.5">
                <span className="font-semibold text-cyan-300">{activity.subject}</span>
                <span>Gr {activity.grade} • Term {activity.term}</span>
              </div>
              <h3 className="font-bold text-white text-sm line-clamp-2">
                {activity.title}
              </h3>
            </div>
            <div className="flex items-center justify-between text-[11px] pt-3 text-[#aab4c8]">
              <span>{activity.questions.length} questions</span>
              <span className="text-cyan-400 font-semibold flex items-center gap-0.5">
                Practice <ArrowRight className="size-3" />
              </span>
            </div>
          </button>
        ))}
      </div>

      {/* Active Activity Workspace */}
      <article
        aria-labelledby="active-activity-title"
        className="rounded-3xl border border-[#223052] bg-[#121a2d] p-6 sm:p-8 space-y-6 shadow-2xl relative"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#223052] pb-5">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-400/15 text-cyan-300 border border-cyan-400/30">
                {activeActivity.subject} (Grade {activeActivity.grade})
              </span>
              <span className="text-xs text-[#aab4c8]">CAPS Aligned Activity</span>
            </div>
            <h3 id="active-activity-title" className="text-xl sm:text-2xl font-extrabold text-white">
              {activeActivity.title}
            </h3>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleResetActivity}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#223052] bg-[#18223a] text-xs font-semibold text-[#aab4c8] hover:text-white transition-colors"
            >
              <RotateCcw className="size-3.5" />
              <span>Retry / Reset</span>
            </button>
          </div>
        </div>

        {/* Score banner if submitted */}
        {submitted && (
          <div
            className={`p-4 rounded-2xl border flex items-center justify-between gap-4 animate-in fade-in-0 duration-300 ${
              scorePercent >= 75
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                : scorePercent >= 50
                ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-200'
                : 'bg-amber-950/40 border-amber-500/40 text-amber-200'
            }`}
          >
            <div className="flex items-center gap-3">
              <Award className="size-7 text-cyan-400" />
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-bold text-base text-white">
                    Activity Complete: {correctCount} / {totalQuestions} Correct ({scorePercent}%)
                  </p>
                  {account && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-400 text-black">
                      Overall Progress: {account.overallMasteryPercentage}%
                    </span>
                  )}
                </div>
                <p className="text-xs mt-0.5">
                  {scorePercent >= 75
                    ? 'Outstanding mastery of this CAPS topic! Your progress has been increased and saved permanently.'
                    : 'Good attempt! Review the worked step-by-step memos below to fix weak spots. Your progress has been saved.'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onSelectTopic(activeActivity.title)}
              className="px-3.5 py-2 rounded-xl bg-cyan-400 text-[#06121f] text-xs font-bold hover:bg-cyan-300 transition-colors shrink-0"
            >
              Generate Full Study Plan
            </button>
          </div>
        )}

        {/* Question List */}
        <div className="space-y-6">
          {activeActivity.questions.map((q, idx) => {
            const isUserSelected = selectedOptions[q.id] !== undefined;
            const isCorrect = selectedOptions[q.id] === q.correctIndex;
            const showExp = revealedExplanations[q.id];

            return (
              <div
                key={q.id}
                className="p-5 rounded-2xl bg-[#0b1020]/70 border border-[#223052] space-y-4 hover:border-cyan-400/30 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-wide">
                    Question {idx + 1}
                  </span>
                  {submitted && q.type === 'multiple-choice' && (
                    <span
                      className={`text-xs font-bold flex items-center gap-1 ${
                        isCorrect ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {isCorrect ? <CheckCircle2 className="size-4" /> : <XCircle className="size-4" />}
                      {isCorrect ? 'Correct' : 'Needs Review'}
                    </span>
                  )}
                </div>

                <p className="text-sm sm:text-base text-white font-medium leading-relaxed">
                  {formatMathText(q.question)}
                </p>

                {/* Multiple choice options */}
                {q.type === 'multiple-choice' && q.options && (
                  <div className="grid gap-2 sm:grid-cols-2">
                    {q.options.map((opt, optIdx) => {
                      const isChosen = selectedOptions[q.id] === optIdx;
                      let btnStyle = 'border-[#223052] bg-[#121a2d] text-[#f7f9fc] hover:border-cyan-400/50';

                      if (submitted) {
                        if (optIdx === q.correctIndex) {
                          btnStyle = 'border-emerald-500 bg-emerald-500/20 text-emerald-200 font-bold';
                        } else if (isChosen && !isCorrect) {
                          btnStyle = 'border-red-500 bg-red-500/20 text-red-200';
                        }
                      } else if (isChosen) {
                        btnStyle = 'border-cyan-400 bg-cyan-400/15 text-white font-semibold ring-1 ring-cyan-400';
                      }

                      return (
                        <button
                          key={optIdx}
                          type="button"
                          disabled={submitted}
                          onClick={() => handleSelectOption(q.id, optIdx)}
                          className={`p-3 rounded-xl border text-left text-xs sm:text-sm transition-all flex items-center gap-2.5 focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none ${btnStyle}`}
                        >
                          <span className="size-5 rounded-full bg-[#18223a] text-xs font-bold flex items-center justify-center shrink-0">
                            {String.fromCharCode(65 + optIdx)}
                          </span>
                          <span className="flex-1">{formatMathText(opt)}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Calculation question input */}
                {q.type === 'calculation' && (
                  <div className="space-y-2">
                    <label htmlFor={`calc-ans-${q.id}`} className="text-xs text-[#aab4c8] font-medium block">
                      Write your answer (in book notation, e.g. 10 cm):
                    </label>
                    <div className="flex gap-2">
                      <input
                        id={`calc-ans-${q.id}`}
                        type="text"
                        disabled={submitted}
                        value={typedAnswers[q.id] || ''}
                        onChange={(e) => setTypedAnswers({ ...typedAnswers, [q.id]: e.target.value })}
                        placeholder="e.g. 10 cm or 12 m..."
                        className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#121a2d] border border-[#223052] text-sm text-white placeholder-[#aab4c8]/50 focus:border-cyan-400 focus:outline-none"
                      />
                      {q.hint && !submitted && (
                        <button
                          type="button"
                          onClick={() =>
                            setRevealedExplanations((prev) => ({ ...prev, [q.id]: !prev[q.id] }))
                          }
                          className="px-3 py-2 rounded-xl border border-[#223052] bg-[#18223a] text-xs text-amber-300 hover:text-white"
                        >
                          {showExp ? 'Hide Hint' : 'Hint'}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* Explanation / Memo */}
                {showExp && (
                  <div className="p-3.5 rounded-xl bg-[#121a2d] border border-cyan-400/20 text-xs sm:text-sm text-[#d2dbe9] space-y-1">
                    <p className="font-semibold text-cyan-300">Marking Memo & Explanation:</p>
                    <p>{formatMathText(q.explanation)}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Submit Activity Button */}
        {!submitted ? (
          <div className="pt-4 border-t border-[#223052] flex justify-end">
            <button
              type="button"
              onClick={handleCheckAnswers}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 to-indigo-500 hover:from-cyan-300 hover:to-indigo-400 text-[#06121f] font-extrabold text-sm shadow-xl shadow-cyan-400/20 transition-all focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
            >
              Check My Answers & Reveal Memo
            </button>
          </div>
        ) : (
          <div className="pt-4 border-t border-[#223052] flex flex-wrap items-center justify-between gap-3 text-xs text-[#aab4c8]">
            <span>Activity verified against South African CAPS benchmarks.</span>
            <button
              type="button"
              onClick={handleResetActivity}
              className="text-cyan-400 font-bold hover:underline"
            >
              Try This Activity Again
            </button>
          </div>
        )}
      </article>
    </div>
  );
};

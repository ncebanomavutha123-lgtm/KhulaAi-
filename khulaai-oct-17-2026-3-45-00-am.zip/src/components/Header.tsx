import React, { useState, useEffect } from 'react';
import {
  Menu,
  X,
  BookOpen,
  Award,
  Search,
  TrendingUp,
  Globe,
  Sliders,
  Crown,
  User,
  UserPlus,
  LogIn,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { AppPage, LanguageCode } from '../types';
import { SUPPORTED_LANGUAGES } from '../data/capsTopics';
import { useLearner } from '../context/LearnerContext';
import { PlantLogo } from './PlantLogo';

interface HeaderProps {
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  onOpenAccessibility: () => void;
  onOpenOwnerPortal: () => void;
  onOpenTopicModal: () => void;
  onOpenAuth: (mode?: 'signup' | 'login') => void;
  highContrast: boolean;
  isOwner: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  currentLanguage,
  onLanguageChange,
  onOpenAccessibility,
  onOpenOwnerPortal,
  onOpenTopicModal,
  onOpenAuth,
  highContrast,
  isOwner,
}) => {
  const { account, isAuthenticated } = useLearner();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Close menu when pressing Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsMenuOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Lock body scroll when drawer is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  const handleSelectNav = (page: AppPage) => {
    onNavigate(page);
    setIsMenuOpen(false);
  };

  const handleSelectTopicSearch = () => {
    setIsMenuOpen(false);
    onOpenTopicModal();
  };

  const handleSelectAccessibility = () => {
    setIsMenuOpen(false);
    onOpenAccessibility();
  };

  const handleSelectAuth = (mode: 'signup' | 'login') => {
    setIsMenuOpen(false);
    onOpenAuth(mode);
  };

  const handleSelectOwner = () => {
    setIsMenuOpen(false);
    onOpenOwnerPortal();
  };

  return (
    <>
      {/* Uncongested Top Line: Only Plant Logo, Name, Slogan, Creator, and 3-Line Menu Icon */}
      <header className="border-b border-[#182a25] bg-[#071310]/95 backdrop-blur-md sticky top-0 z-30 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Logo, Name, Slogan & Creator (All wrapped together on top line) */}
          <button
            type="button"
            onClick={() => handleSelectNav('study-plan')}
            className="flex items-center text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 rounded-xl"
            aria-label="KhulaAI Home"
          >
            <PlantLogo size="md" showDetails={true} />
          </button>

          {/* Top Right: The 3-Line Menu Icon */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsMenuOpen(true)}
              className="flex items-center gap-2 p-2 sm:px-3 sm:py-2 rounded-xl bg-[#0e211b] hover:bg-[#142e26] border border-emerald-500/30 text-emerald-300 hover:text-white transition-all shadow-sm focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none"
              aria-label="Open menu and tools"
              aria-expanded={isMenuOpen}
              title="Menu & Learning Tools"
            >
              {/* 3-Line Icon */}
              <div className="flex flex-col justify-center items-center gap-1 w-5 h-5">
                <span className="w-5 h-0.5 bg-emerald-400 rounded-full transition-transform" />
                <span className="w-5 h-0.5 bg-emerald-400 rounded-full transition-transform" />
                <span className="w-5 h-0.5 bg-emerald-400 rounded-full transition-transform" />
              </div>
              <span className="text-xs font-bold hidden sm:inline text-emerald-200">Menu</span>
            </button>
          </div>
        </div>
      </header>

      {/* Interactive 3-Line Drawer Overlay */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex justify-end animate-in fade-in-0 duration-200">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setIsMenuOpen(false)}
            aria-hidden="true"
          />

          {/* Slide-over Drawer Panel */}
          <div
            className="relative w-full max-w-md bg-[#0a1613] border-l border-emerald-500/30 h-full overflow-y-auto p-6 space-y-6 shadow-2xl z-10 flex flex-col justify-between"
            role="dialog"
            aria-modal="true"
            aria-label="Khula Learning Navigation"
          >
            <div className="space-y-6">
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#182a25]">
                <div className="flex items-center gap-2.5">
                  <PlantLogo size="sm" showDetails={false} />
                  <div>
                    <h2 className="text-base font-extrabold text-white font-['Sora'] flex items-center gap-1.5">
                      <span>KHULA</span>
                      <span className="text-emerald-400">AI</span>
                    </h2>
                    <p className="text-[11px] text-[#94a3b8]">By Nceba • SA High School</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsMenuOpen(false)}
                  className="p-2 rounded-xl text-[#94a3b8] hover:text-white hover:bg-[#142e26] border border-[#182a25] transition-colors"
                  aria-label="Close menu"
                >
                  <X className="size-5" />
                </button>
              </div>

              {/* Student Account Status / Banner */}
              {isAuthenticated && account ? (
                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-[#0e211b] to-emerald-500/10 border border-emerald-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="size-9 rounded-xl bg-emerald-400 text-[#071310] font-black flex items-center justify-center text-sm shadow">
                      {account.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white">{account.name}</p>
                      <p className="text-[11px] text-[#94a3b8]">Grade {account.grade} • Active Learner</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-black px-2 py-0.5 rounded-full bg-emerald-400 text-[#071310]">
                      {account.overallMasteryPercentage}%
                    </span>
                    <p className="text-[9px] text-[#94a3b8] mt-0.5">Mastery</p>
                  </div>
                </div>
              ) : (
                <div className="p-3.5 rounded-2xl bg-[#0e211b] border border-emerald-500/20 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Sparkles className="size-3.5 text-emerald-400" />
                      Guest Learner
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300">
                      0% Mastery
                    </span>
                  </div>
                  <p className="text-[11px] text-[#94a3b8] leading-relaxed">
                    Sign up to track your learning journey permanently across subjects.
                  </p>
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleSelectAuth('signup')}
                      className="w-full py-1.5 px-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-[#071310] text-xs font-bold transition-all text-center"
                    >
                      Sign Up (0%)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectAuth('login')}
                      className="w-full py-1.5 px-2 rounded-xl bg-[#142e26] hover:bg-[#1a3d33] text-emerald-200 border border-emerald-500/30 text-xs font-bold transition-all text-center"
                    >
                      Log In
                    </button>
                  </div>
                </div>
              )}

              {/* Numbered Navigation Options - TYPE TOPIC IS THE 3RD OPTION */}
              <nav aria-label="Khula Menu Navigation" className="space-y-1.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#94a3b8] px-1 block mb-2">
                  Main Learning Tools
                </span>

                {/* 1. Study Plans & Lessons */}
                <button
                  type="button"
                  onClick={() => handleSelectNav('study-plan')}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all text-left ${
                    currentPage === 'study-plan'
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-white'
                      : 'bg-[#0e211b]/80 border-[#182a25] text-[#94a3b8] hover:text-white hover:bg-[#142e26]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="size-6 rounded-lg bg-emerald-500/20 text-emerald-300 font-black text-xs flex items-center justify-center">
                      1
                    </span>
                    <div>
                      <p className="text-xs font-bold text-white flex items-center gap-1.5">
                        <BookOpen className="size-3.5 text-emerald-400" />
                        Study Plans & Lessons
                      </p>
                      <p className="text-[11px] text-[#94a3b8]">Curriculum topic breakdowns and memos</p>
                    </div>
                  </div>
                  <ChevronRight className="size-4 text-[#94a3b8]" />
                </button>

                {/* 2. CAPS Activities (Optional Practice) */}
                <button
                  type="button"
                  onClick={() => handleSelectNav('activities')}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all text-left ${
                    currentPage === 'activities'
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-white'
                      : 'bg-[#0e211b]/80 border-[#182a25] text-[#94a3b8] hover:text-white hover:bg-[#142e26]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="size-6 rounded-lg bg-emerald-500/20 text-emerald-300 font-black text-xs flex items-center justify-center">
                      2
                    </span>
                    <div>
                      <p className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Award className="size-3.5 text-emerald-400" />
                        CAPS Activities
                        <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-full bg-emerald-400/15 text-emerald-300 border border-emerald-400/30">
                          Optional
                        </span>
                      </p>
                      <p className="text-[11px] text-[#94a3b8]">Self-paced drills & exam-style questions</p>
                    </div>
                  </div>
                  <ChevronRight className="size-4 text-[#94a3b8]" />
                </button>

                {/* 3. TYPE TOPIC - Prominently as the 3rd option as requested */}
                <button
                  type="button"
                  onClick={handleSelectTopicSearch}
                  className="w-full flex items-center justify-between p-3.5 rounded-2xl border border-cyan-400/60 bg-gradient-to-r from-cyan-400/15 via-[#0e211b] to-emerald-400/15 hover:border-cyan-300 text-left transition-all shadow-md group"
                >
                  <div className="flex items-center gap-3">
                    <span className="size-6 rounded-lg bg-cyan-400 text-[#071310] font-black text-xs flex items-center justify-center shadow">
                      3
                    </span>
                    <div>
                      <p className="text-xs font-extrabold text-cyan-300 group-hover:text-cyan-200 flex items-center gap-1.5">
                        <Search className="size-3.5 text-cyan-400 stroke-[2.5]" />
                        Type Topic
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-cyan-400 text-[#071310]">
                          Search Any
                        </span>
                      </p>
                      <p className="text-[11px] text-[#94a3b8]">Type any subject, term, or question to learn</p>
                    </div>
                  </div>
                  <ChevronRight className="size-4 text-cyan-400" />
                </button>

                {/* 4. Progress Generator */}
                <button
                  type="button"
                  onClick={() => handleSelectNav('progress')}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all text-left ${
                    currentPage === 'progress'
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-white'
                      : 'bg-[#0e211b]/80 border-[#182a25] text-[#94a3b8] hover:text-white hover:bg-[#142e26]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="size-6 rounded-lg bg-emerald-500/20 text-emerald-300 font-black text-xs flex items-center justify-center">
                      4
                    </span>
                    <div>
                      <p className="text-xs font-bold text-white flex items-center gap-1.5">
                        <TrendingUp className="size-3.5 text-emerald-400" />
                        Progress Generator
                      </p>
                      <p className="text-[11px] text-[#94a3b8]">Mastery diagnostics starting from 0%</p>
                    </div>
                  </div>
                  <ChevronRight className="size-4 text-[#94a3b8]" />
                </button>

                {/* 5. Subject Library (Grades 7–9) */}
                <button
                  type="button"
                  onClick={() => handleSelectNav('library')}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all text-left ${
                    currentPage === 'library'
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-white'
                      : 'bg-[#0e211b]/80 border-[#182a25] text-[#94a3b8] hover:text-white hover:bg-[#142e26]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="size-6 rounded-lg bg-emerald-500/20 text-emerald-300 font-black text-xs flex items-center justify-center">
                      5
                    </span>
                    <div>
                      <p className="text-xs font-bold text-white flex items-center gap-1.5">
                        <BookOpen className="size-3.5 text-emerald-400" />
                        Subject Library (Grades 7–9)
                      </p>
                      <p className="text-[11px] text-[#94a3b8]">Browse Maths, IsiXhosa, Sesotho, Sciences & EMS</p>
                    </div>
                  </div>
                  <ChevronRight className="size-4 text-[#94a3b8]" />
                </button>
              </nav>

              {/* Language Preferences - NO ISIZULU, NO AFRIKAANS */}
              <div className="space-y-2 pt-2 border-t border-[#182a25]">
                <div className="flex items-center justify-between px-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#94a3b8] flex items-center gap-1.5">
                    <Globe className="size-3.5 text-emerald-400" />
                    Language Preference
                  </span>
                  <span className="text-[10px] text-emerald-300 font-semibold">
                    {SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage)?.label}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      type="button"
                      onClick={() => onLanguageChange(lang.code)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold transition-all border text-left flex items-center justify-between ${
                        currentLanguage === lang.code
                          ? 'border-emerald-400 bg-emerald-400 text-[#071310] shadow-sm'
                          : 'border-[#182a25] bg-[#0e211b] text-[#94a3b8] hover:text-white hover:border-emerald-500/30'
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        <span>{lang.flag}</span>
                        <span>{lang.native}</span>
                      </span>
                      {currentLanguage === lang.code && <span>✓</span>}
                    </button>
                  ))}
                </div>
              </div>

              {/* Accessibility Settings */}
              <div className="pt-2 border-t border-[#182a25]">
                <button
                  type="button"
                  onClick={handleSelectAccessibility}
                  className="w-full flex items-center justify-between p-3 rounded-2xl border border-[#182a25] bg-[#0e211b] hover:bg-[#142e26] text-left transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    <Sliders className="size-4 text-emerald-400" />
                    <div>
                      <p className="text-xs font-bold text-white">Accessibility Settings</p>
                      <p className="text-[11px] text-[#94a3b8]">High contrast, text zoom, screen reader</p>
                    </div>
                  </div>
                  <span className="text-xs text-emerald-400 font-semibold">Adjust</span>
                </button>
              </div>

              {/* Creator Control Room - ONLY appears AFTER logging in with Nceba's email! */}
              {isOwner && (
                <div className="pt-2 border-t border-amber-500/30">
                  <button
                    type="button"
                    onClick={handleSelectOwner}
                    className="w-full flex items-center justify-between p-3.5 rounded-2xl border border-amber-500/40 bg-gradient-to-r from-amber-500/15 via-[#0e211b] to-amber-500/10 hover:border-amber-400 text-left transition-all shadow-md group"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="size-8 rounded-xl bg-amber-400 text-[#071310] flex items-center justify-center font-bold shadow">
                        <Crown className="size-4 text-[#071310]" />
                      </div>
                      <div>
                        <p className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                          Creator Control Room
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400 text-[#071310] font-black uppercase">
                            Founder
                          </span>
                        </p>
                        <p className="text-[11px] text-amber-200/70">Welcome Nceba • Manage curriculum & telemetry</p>
                      </div>
                    </div>
                    <ChevronRight className="size-4 text-amber-400" />
                  </button>
                </div>
              )}
            </div>

            {/* Drawer Footer */}
            <div className="pt-4 border-t border-[#182a25] text-center text-[11px] text-[#94a3b8] space-y-1">
              <p className="font-semibold text-emerald-300">KhulaAI — Created by Nceba</p>
              <p>Built with heart for every South African learner</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

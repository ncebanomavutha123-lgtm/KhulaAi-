import React, { useState } from 'react';
import {
  Calendar,
  BookOpen,
  CheckCircle2,
  Circle,
  Volume2,
  VolumeX,
  Copy,
  Printer,
  AlertTriangle,
  Lightbulb,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowLeft,
  Award,
  Eye,
  EyeOff,
} from 'lucide-react';
import { StudyPlanData } from '../types';
import { formatMathText } from '../utils/mathFormatter';
import { useLearner } from '../context/LearnerContext';
import { AfterAnswerActions } from './AfterAnswerActions';

interface StudyPlanViewerProps {
  plan: StudyPlanData;
  onTranslateTo: (languageCode: string) => void;
  onAskTutor: (question: string) => void;
  onResetTopic?: () => void;
}

export const StudyPlanViewer: React.FC<StudyPlanViewerProps> = ({
  plan,
  onTranslateTo,
  onAskTutor,
  onResetTopic,
}) => {
  const { account, recordCompletedStudyDay, recordMasteredTopic } = useLearner();
  const [scheduleState, setScheduleState] = useState(plan.schedule);
  const [revealedSolutions, setRevealedSolutions] = useState<Record<number, boolean>>({});
  const [revealedHints, setRevealedHints] = useState<Record<number, boolean>>({});
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isMastered, setIsMastered] = useState(() => account?.masteredTopics.includes(plan.topic) ?? false);
  // User requirement: "make activities be optional"
  const [showOptionalExercises, setShowOptionalExercises] = useState(true);

  // Toggle Day completion (increases persistent progress)
  const toggleDay = (index: number) => {
    setScheduleState((prev) =>
      prev.map((item, i) => {
        if (i === index) {
          const nextVal = !item.completed;
          if (nextVal) {
            recordCompletedStudyDay(plan.topic, item.day);
          }
          return { ...item, completed: nextVal };
        }
        return item;
      })
    );
  };

  const handleMarkMastered = () => {
    setIsMastered(true);
    recordMasteredTopic(plan.topic, 'CAPS Curriculum');
  };

  const completedDays = scheduleState.filter((s) => s.completed).length;
  const progressPercent = Math.round((completedDays / Math.max(scheduleState.length, 1)) * 100);

  // Toggle exercise solutions
  const toggleSolution = (id: number) => {
    setRevealedSolutions((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleHint = (id: number) => {
    setRevealedHints((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Text-To-Speech (Auditory Accessibility)
  const toggleSpeech = () => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported by your current browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToRead = `${formatMathText(plan.topic)}. Overview: ${formatMathText(plan.overview)}. Core explanation: ${formatMathText(plan.coreExplanation)}.`;
    const utterance = new SpeechSynthesisUtterance(textToRead);

    // Pick speech language (Only en, xh, st)
    if (plan.language === 'xh') utterance.lang = 'xh-ZA';
    else if (plan.language === 'st') utterance.lang = 'st-ZA';
    else utterance.lang = 'en-ZA';

    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  // Copy plan
  const handleCopy = () => {
    const content = `${formatMathText(plan.topic)}\n\nOverview:\n${formatMathText(plan.overview)}\n\nCore Explanation:\n${formatMathText(plan.coreExplanation)}\n\nFormulas:\n${plan.keyFormulas.map(f => formatMathText(f)).join('\n')}\n\nPractice Exercises:\n${plan.exercises.map(e => `${formatMathText(e.title)}: ${formatMathText(e.question)}\nMemo: ${formatMathText(e.solution)}`).join('\n\n')}`;
    navigator.clipboard.writeText(content).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  // Print
  const handlePrint = () => {
    window.print();
  };

  return (
    <article
      aria-labelledby="study-plan-title"
      className="rounded-3xl border border-[#182a25] bg-[#071310] p-5 sm:p-8 space-y-8 shadow-2xl relative"
    >
      {/* Header bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#182a25] pb-6">
        <div>
          <div className="flex items-center gap-2 flex-wrap mb-1">
            {onResetTopic && (
              <button
                type="button"
                onClick={onResetTopic}
                className="inline-flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-medium mr-2 hover:underline"
              >
                <ArrowLeft className="size-3.5" />
                <span>Search another topic</span>
              </button>
            )}
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-400/15 text-emerald-300 border border-emerald-400/30">
              CAPS Study Plan • by Nceba
            </span>
            <span className="text-xs text-[#aab4c8]">Generated {plan.generatedAt}</span>
          </div>
          <h2 id="study-plan-title" className="text-2xl sm:text-3xl font-extrabold text-white">
            {formatMathText(plan.topic)}
          </h2>
        </div>

        {/* Action Toolbar */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={toggleSpeech}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-semibold transition-all focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none ${
              isSpeaking
                ? 'bg-emerald-400 text-[#071310] border-emerald-300 animate-pulse'
                : 'border-[#182a25] bg-[#0e211b] text-emerald-300 hover:text-white hover:border-emerald-400/50'
            }`}
            aria-label={isSpeaking ? 'Stop audio read aloud' : 'Read plan aloud for auditory accessibility'}
          >
            {isSpeaking ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
            <span>{isSpeaking ? 'Stop Voice' : 'Read Aloud'}</span>
          </button>

          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#182a25] bg-[#0e211b] text-[#f7f9fc] hover:border-emerald-400/50 text-xs font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none"
            aria-label="Copy entire study plan to clipboard"
          >
            <Copy className="size-3.5 text-emerald-400" />
            <span>{copied ? 'Copied!' : 'Copy'}</span>
          </button>

          <button
            type="button"
            onClick={handleMarkMastered}
            disabled={isMastered}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-semibold transition-all focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none ${
              isMastered
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'border-emerald-400/40 bg-emerald-400/10 text-emerald-300 hover:bg-emerald-400/20'
            }`}
            title="Add this topic to your permanent mastered list and boost overall progress"
          >
            <CheckCircle2 className="size-3.5 text-emerald-400" />
            <span>{isMastered ? 'Topic Mastered ✓' : 'Mark as Mastered (+5%)'}</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#182a25] bg-[#0e211b] text-[#f7f9fc] hover:border-emerald-400/50 text-xs font-semibold transition-colors focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none"
            aria-label="Print study plan or save as PDF"
          >
            <Printer className="size-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Print / PDF</span>
          </button>
        </div>
      </div>

      {/* 1. Overview */}
      <section aria-labelledby="overview-heading" className="space-y-2">
        <h3 id="overview-heading" className="text-sm font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
          <BookOpen className="size-4" aria-hidden="true" />
          Topic Overview & CAPS Scope
        </h3>
        <p className="text-[#f7f9fc] leading-relaxed text-sm sm:text-base bg-[#0e211b]/70 p-4 rounded-xl border border-[#182a25]">
          {formatMathText(plan.overview)}
        </p>
      </section>

      {/* 2. Structured 4-Day Plan Roadmap */}
      <section aria-labelledby="schedule-heading" className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 id="schedule-heading" className="text-sm font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
            <Calendar className="size-4" aria-hidden="true" />
            Structured Study Schedule
          </h3>
          <span className="text-xs text-[#aab4c8]">
            Progress: <strong className="text-emerald-300">{completedDays} of {scheduleState.length}</strong> ({progressPercent}%)
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-[#0e211b] h-2 rounded-full overflow-hidden" role="progressbar" aria-valuenow={progressPercent} aria-valuemin={0} aria-valuemax={100}>
          <div
            className="bg-gradient-to-r from-emerald-400 to-teal-400 h-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          {scheduleState.map((step, idx) => (
            <button
              key={step.day + idx}
              type="button"
              onClick={() => toggleDay(idx)}
              className={`p-4 rounded-2xl border text-left transition-all flex items-start gap-3.5 focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none ${
                step.completed
                  ? 'border-emerald-500/40 bg-emerald-500/15 text-[#f7f9fc]'
                  : 'border-[#182a25] bg-[#0e211b]/80 hover:border-emerald-400/40 hover:bg-[#142e26]/50 text-white'
              }`}
              aria-pressed={step.completed}
            >
              <div className="mt-0.5 shrink-0">
                {step.completed ? (
                  <CheckCircle2 className="size-5 text-emerald-400" aria-hidden="true" />
                ) : (
                  <Circle className="size-5 text-[#aab4c8]" aria-hidden="true" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block mb-0.5">
                  {formatMathText(step.day)}
                </span>
                <p className={`font-semibold text-sm ${step.completed ? 'line-through text-[#aab4c8]' : 'text-white'}`}>
                  {formatMathText(step.focus)}
                </p>
                <p className="text-xs text-[#aab4c8] mt-1">{formatMathText(step.task)}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* 3. Core Explanation */}
      <section aria-labelledby="explanation-heading" className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 id="explanation-heading" className="text-sm font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
            <Lightbulb className="size-4" aria-hidden="true" />
            Core Explanation (CAPS Concept)
          </h3>
          <span className="text-xs text-emerald-400 font-medium px-2 py-0.5 rounded bg-emerald-400/10 border border-emerald-400/20">
            Notebook Language & Intuitive
          </span>
        </div>
        <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-500/10 via-[#0e211b] to-teal-500/10 border border-emerald-500/30 text-[#f7f9fc] space-y-3 text-sm sm:text-base leading-relaxed">
          {plan.coreExplanation.split('\n\n').map((paragraph, i) => (
            <p key={i}>{formatMathText(paragraph.replace(/^#+\s*/, ''))}</p>
          ))}
        </div>
      </section>

      {/* 4. Options after the explanation: "Show me the workings", "Explain it simpler", etc. (6-7 options) */}
      <AfterAnswerActions
        onSelectOption={(prompt) => onAskTutor(prompt)}
        title="Follow-Up Options After This Explanation:"
      />

      {/* 5. Key Rules / Formulas */}
      {plan.keyFormulas.length > 0 && (
        <section aria-labelledby="formulas-heading" className="space-y-3">
          <h3 id="formulas-heading" className="text-sm font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
            <Sparkles className="size-4" aria-hidden="true" />
            Key Formulae & Rules (School Notebook Style)
          </h3>
          <div className="p-4 rounded-2xl bg-[#081512] border border-[#182a25] space-y-2">
            {plan.keyFormulas.map((form, i) => (
              <div key={i} className="font-semibold text-emerald-200 text-sm sm:text-base bg-[#0e211b] px-3.5 py-2.5 rounded-lg border border-emerald-500/20 tracking-wide">
                {formatMathText(form)}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Practice Exercises with Step-by-Step Memos (OPTIONAL AS REQUESTED) */}
      <section aria-labelledby="exercises-heading" className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2 border-b border-[#182a25] pb-3">
          <div className="flex items-center gap-2">
            <h3 id="exercises-heading" className="text-sm font-semibold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
              <HelpCircle className="size-4" aria-hidden="true" />
              Practice Exercises with Marking Memos
            </h3>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/15 text-emerald-300 border border-emerald-400/30">
              Optional Activities
            </span>
          </div>

          {/* Toggle to make activities optional */}
          <button
            type="button"
            onClick={() => setShowOptionalExercises(!showOptionalExercises)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-500/30 bg-[#0e211b] hover:bg-[#142e26] text-xs font-semibold text-emerald-300 transition-colors"
          >
            {showOptionalExercises ? (
              <>
                <EyeOff className="size-3.5" />
                <span>Hide Optional Exercises</span>
              </>
            ) : (
              <>
                <Eye className="size-3.5" />
                <span>Show Optional Exercises ({plan.exercises.length})</span>
              </>
            )}
          </button>
        </div>

        {showOptionalExercises && (
          <div className="space-y-4 animate-in fade-in-0 duration-200">
            <p className="text-xs text-[#aab4c8]">
              Activities are completely optional! Try answering first to test yourself, or reveal the worked memo.
            </p>

            <div className="space-y-4">
              {plan.exercises.map((exercise) => {
                const isSolRevealed = revealedSolutions[exercise.id];
                const isHintRevealed = revealedHints[exercise.id];

                return (
                  <div
                    key={exercise.id}
                    className="rounded-2xl border border-[#182a25] bg-[#081512]/90 p-5 space-y-4 transition-all hover:border-emerald-500/40"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide">
                          {formatMathText(exercise.title)}
                        </span>
                        <p className="text-sm sm:text-base text-white font-medium mt-1">
                          {formatMathText(exercise.question)}
                        </p>
                      </div>
                      {exercise.marks && (
                        <span className="shrink-0 text-xs font-bold px-2 py-1 rounded bg-[#0e211b] text-emerald-300 border border-[#182a25]">
                          [{exercise.marks} Marks]
                        </span>
                      )}
                    </div>

                    {/* Learner Answer Workspace */}
                    <div className="space-y-1.5">
                      <label htmlFor={`answer-${exercise.id}`} className="text-xs text-[#aab4c8] block font-medium">
                        Your Working / Answer (Optional):
                      </label>
                      <input
                        id={`answer-${exercise.id}`}
                        type="text"
                        value={userAnswers[exercise.id] || ''}
                        onChange={(e) => setUserAnswers({ ...userAnswers, [exercise.id]: e.target.value })}
                        placeholder="Type your working or answer here..."
                        className="w-full px-3.5 py-2 rounded-xl bg-[#0e211b] border border-[#182a25] text-sm text-white placeholder-[#aab4c8]/50 focus:border-emerald-400 focus:outline-none"
                      />
                    </div>

                    {/* Hint & Solution Toggles */}
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      {exercise.hint && (
                        <button
                          type="button"
                          onClick={() => toggleHint(exercise.id)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#182a25] bg-[#0e211b] text-xs font-medium text-amber-300 hover:text-amber-200 hover:border-amber-400/40 transition-colors focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none"
                          aria-expanded={isHintRevealed}
                        >
                          <Lightbulb className="size-3.5" aria-hidden="true" />
                          <span>{isHintRevealed ? 'Hide Hint' : 'Show Hint'}</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => toggleSolution(exercise.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-400/10 text-xs font-semibold text-emerald-300 hover:bg-emerald-400/20 transition-all focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none"
                        aria-expanded={isSolRevealed}
                      >
                        <span>{isSolRevealed ? 'Hide Solution' : 'Check Solution & Memo'}</span>
                        {isSolRevealed ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
                      </button>
                    </div>

                    {/* Hint Content */}
                    {isHintRevealed && exercise.hint && (
                      <div className="p-3 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-200 text-xs leading-relaxed" role="region" aria-label="Hint">
                        <strong>Hint:</strong> {formatMathText(exercise.hint)}
                      </div>
                    )}

                    {/* Revealed Solution */}
                    {isSolRevealed && (
                      <div
                        className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-400/30 text-emerald-100 text-sm leading-relaxed space-y-2 animate-in fade-in-0 duration-200"
                        role="region"
                        aria-label="Worked Solution"
                      >
                        <p className="font-bold text-xs uppercase tracking-wider text-emerald-300 flex items-center gap-1.5">
                          <CheckCircle2 className="size-4" aria-hidden="true" />
                          Step-by-Step Marking Solution
                        </p>
                        <div className="whitespace-pre-wrap font-medium text-xs sm:text-sm text-emerald-200 bg-black/40 p-3 rounded-lg border border-emerald-500/20">
                          {formatMathText(exercise.solution)}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </section>

      {/* 7. Pitfalls & Common Mistakes */}
      {plan.pitfalls.length > 0 && (
        <section aria-labelledby="pitfalls-heading" className="space-y-3">
          <h3 id="pitfalls-heading" className="text-sm font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-2">
            <AlertTriangle className="size-4" aria-hidden="true" />
            Common Pitfalls & Mistakes to Avoid
          </h3>
          <div className="p-4 rounded-2xl bg-amber-400/10 border border-amber-400/30 space-y-2">
            <ul className="list-disc pl-5 space-y-1.5 text-xs sm:text-sm text-amber-100">
              {plan.pitfalls.map((pitfall, i) => (
                <li key={i}>{formatMathText(pitfall)}</li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {/* 8. Language Quick Switcher & Follow-Up Actions (NO ISIZULU, NO AFRIKAANS) */}
      <div className="pt-4 border-t border-[#182a25] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 flex-wrap text-xs text-[#aab4c8]">
          <span>Translate plan to:</span>
          <button
            type="button"
            onClick={() => onTranslateTo('xh')}
            className="px-2.5 py-1 rounded-lg border border-[#182a25] bg-[#0e211b] text-emerald-300 hover:text-white hover:border-emerald-500/50 transition-colors"
          >
            🇿🇦 isiXhosa
          </button>
          <button
            type="button"
            onClick={() => onTranslateTo('st')}
            className="px-2.5 py-1 rounded-lg border border-[#182a25] bg-[#0e211b] text-emerald-300 hover:text-white hover:border-emerald-500/50 transition-colors"
          >
            🇿🇦 Sesotho
          </button>
          <button
            type="button"
            onClick={() => onTranslateTo('en')}
            className="px-2.5 py-1 rounded-lg border border-[#182a25] bg-[#0e211b] text-emerald-300 hover:text-white hover:border-emerald-500/50 transition-colors"
          >
            🇿🇦 English
          </button>
        </div>

        <button
          type="button"
          onClick={() => onAskTutor(`Can you show me the step-by-step workings and explain ${plan.topic} simpler without going off topic?`)}
          className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 hover:underline"
        >
          <Lightbulb className="size-3.5" />
          <span>Ask KhulaAI for step-by-step workings</span>
        </button>
      </div>
    </article>
  );
};

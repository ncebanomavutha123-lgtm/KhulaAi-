import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, MessageCircle, RotateCcw, Volume2, VolumeX, Copy, Check, FileText, Clock } from 'lucide-react';
import { ChatMessage, LanguageCode } from '../types';
import { formatMathText } from '../utils/mathFormatter';
import { AfterAnswerActions } from './AfterAnswerActions';

interface InteractiveTutorProps {
  currentTopic: string;
  language: LanguageCode;
  onSendMessage: (text: string, longAnswer?: boolean) => Promise<void>;
  messages: ChatMessage[];
  isStreaming: boolean;
}

export const InteractiveTutor: React.FC<InteractiveTutorProps> = ({
  currentTopic,
  language,
  onSendMessage,
  messages,
  isStreaming,
}) => {
  const [inputText, setInputText] = useState('');
  const [preferLongAnswer, setPreferLongAnswer] = useState(true);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStreaming]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isStreaming) return;
    const msg = inputText.trim();
    setInputText('');
    await onSendMessage(msg, preferLongAnswer);
  };

  const handleQuickPrompt = (prompt: string, isLong = preferLongAnswer) => {
    if (isStreaming) return;
    onSendMessage(prompt, isLong);
  };

  const handleSpeech = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    if (language === 'xh') utterance.lang = 'xh-ZA';
    else if (language === 'st') utterance.lang = 'st-ZA';
    else utterance.lang = 'en-ZA';

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const hasAssistantMessage = messages.some((m) => m.role === 'assistant');

  return (
    <section
      aria-labelledby="tutor-heading"
      className="rounded-3xl border border-[#182a25] bg-[#071310] p-5 sm:p-7 space-y-5 shadow-2xl relative"
    >
      {/* Header with Depth Control */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#182a25] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-400/15 text-emerald-300 border border-emerald-400/30">
              Made by Nceba
            </span>
            <span className="text-xs text-[#94a3b8]">Interactive South African School Tutor</span>
          </div>
          <h3 id="tutor-heading" className="text-xl sm:text-2xl font-extrabold text-white mt-1">
            Ask KhulaAI Anything About This Topic
          </h3>
        </div>

        {/* Answer Depth Switch */}
        <div className="flex items-center gap-1.5 p-1 bg-[#0e211b] rounded-xl border border-[#182a25] self-start sm:self-auto text-xs">
          <button
            type="button"
            onClick={() => setPreferLongAnswer(true)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-semibold transition-all ${
              preferLongAnswer
                ? 'bg-emerald-400 text-[#071310] shadow-sm'
                : 'text-[#94a3b8] hover:text-white'
            }`}
            title="AI gives thorough, multi-step long answers when asked"
          >
            <FileText className="size-3" />
            <span>Long Detailed Answer</span>
          </button>
          <button
            type="button"
            onClick={() => setPreferLongAnswer(false)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-semibold transition-all ${
              !preferLongAnswer
                ? 'bg-emerald-400 text-[#071310] shadow-sm'
                : 'text-[#94a3b8] hover:text-white'
            }`}
            title="AI gives quick 1-2 paragraph answers"
          >
            <Clock className="size-3" />
            <span>Concise (1–2 Para)</span>
          </button>
        </div>
      </div>

      {/* Messages Feed */}
      <div
        className="space-y-4 max-h-96 overflow-y-auto pr-1"
        role="log"
        aria-live="polite"
        aria-label="Conversation with KhulaAI Tutor"
      >
        {messages.length === 0 ? (
          <div className="text-center py-6 px-4 rounded-2xl bg-[#0e211b]/60 border border-[#182a25] space-y-2">
            <Sparkles className="size-6 text-emerald-400 mx-auto opacity-70" aria-hidden="true" />
            <p className="text-sm font-semibold text-white">Have a question about this topic?</p>
            <p className="text-xs text-[#94a3b8] max-w-sm mx-auto">
              Ask for workings, simpler explanations, or translations. KhulaAI explains fluently in isiXhosa, Sesotho, or English!
            </p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-1.5 mb-1 px-1">
                <span className="text-[10px] font-semibold text-[#94a3b8]">
                  {msg.role === 'user' ? 'You (Learner)' : 'KhulaAI Tutor (Made by Nceba)'}
                </span>
                <span className="text-[9px] text-[#94a3b8]/70">· {msg.timestamp}</span>
              </div>

              <div
                className={`max-w-[88%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-emerald-400 text-[#071310] font-semibold rounded-tr-sm shadow-md'
                    : 'bg-[#0e211b] text-[#f7f9fc] border border-[#182a25] rounded-tl-sm shadow-md'
                }`}
              >
                <div className="whitespace-pre-wrap">{formatMathText(msg.content)}</div>

                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-[#182a25] text-[#94a3b8]">
                    <button
                      type="button"
                      onClick={() => handleSpeech(msg.id, msg.content)}
                      className="p-1 hover:text-emerald-400 transition-colors rounded"
                      title="Read explanation out loud"
                      aria-label="Read explanation aloud"
                    >
                      {speakingId === msg.id ? (
                        <VolumeX className="size-3.5 text-emerald-400" />
                      ) : (
                        <Volume2 className="size-3.5" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="p-1 hover:text-emerald-400 transition-colors rounded"
                      title="Copy response to clipboard"
                      aria-label="Copy response to clipboard"
                    >
                      {copiedId === msg.id ? (
                        <Check className="size-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="size-3.5" />
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}

        {isStreaming && (
          <div className="flex items-center gap-2 text-xs text-emerald-400 py-1" role="status">
            <span className="size-2 rounded-full bg-emerald-400 animate-ping" aria-hidden="true" />
            <span>KhulaAI is thinking and generating answer...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* 6 to 7 Interactive Options After the Answer (Appears after an answer, and available for instant use) */}
      <AfterAnswerActions
        onSelectOption={(prompt) => handleQuickPrompt(prompt, true)}
        isLoading={isStreaming}
        title={hasAssistantMessage ? 'Options after the answer — choose next step:' : 'Quick Actions for this Topic:'}
      />

      {/* Input Form */}
      <form onSubmit={handleSend} className="relative flex items-center gap-2 pt-1">
        <label htmlFor="tutor-question-input" className="sr-only">
          Ask KhulaAI a follow-up question
        </label>
        <input
          id="tutor-question-input"
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask a question, request a step breakdown, or ask in isiXhosa/Sesotho..."
          disabled={isStreaming}
          className="flex-1 px-4 py-3 rounded-xl bg-[#0e211b] border border-[#182a25] text-xs sm:text-sm text-white placeholder-[#94a3b8]/50 focus:border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isStreaming}
          className="p-3 rounded-xl bg-emerald-400 hover:bg-emerald-300 disabled:opacity-40 text-[#071310] font-bold transition-all shrink-0 focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:outline-none shadow-md"
          aria-label="Send message to KhulaAI"
        >
          <Send className="size-4" />
        </button>
      </form>
    </section>
  );
};

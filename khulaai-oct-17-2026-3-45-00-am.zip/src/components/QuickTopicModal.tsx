import React, { useState, useEffect } from 'react';
import { Sparkles, X, BookOpen, Clock, Globe, FileText, Shuffle } from 'lucide-react';
import { LanguageCode, TopicSuggestion } from '../types';
import {
  SUPPORTED_LANGUAGES,
  getRandomTopics,
  getRandomPlaceholderTopic,
} from '../data/capsTopics';

interface QuickTopicModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitTopic: (topic: string, concise: boolean, grade?: number, lang?: LanguageCode) => void;
  currentLanguage: LanguageCode;
}

export const QuickTopicModal: React.FC<QuickTopicModalProps> = ({
  isOpen,
  onClose,
  onSubmitTopic,
  currentLanguage,
}) => {
  const [topic, setTopic] = useState('');
  const [grade, setGrade] = useState<number>(8);
  const [concise, setConcise] = useState(false); // default to false so user gets long answers when desired
  const [selectedLang, setSelectedLang] = useState<LanguageCode>(currentLanguage);
  const [modalPlaceholder, setModalPlaceholder] = useState('e.g. IsiXhosa Ibanga 8 - Izaci Namaqhalo');
  const [modalSuggestions, setModalSuggestions] = useState<TopicSuggestion[]>([]);

  useEffect(() => {
    if (isOpen) {
      setModalPlaceholder(`e.g. ${getRandomPlaceholderTopic()}`);
      setModalSuggestions(getRandomTopics(4));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    onSubmitTopic(topic.trim(), concise, grade, selectedLang);
    onClose();
  };

  const handlePickSuggestion = (title: string, g: number) => {
    setTopic(title);
    setGrade(g);
    onSubmitTopic(title, concise, g, selectedLang);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="quick-topic-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
    >
      <div className="w-full max-w-xl bg-[#0f172a] border border-cyan-400/30 rounded-3xl shadow-2xl p-6 sm:p-7 text-white space-y-5">
        <div className="flex items-center justify-between border-b border-[#1f2d4f] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="size-9 rounded-xl bg-cyan-400/10 text-cyan-400 flex items-center justify-center">
              <Sparkles className="size-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="quick-topic-title" className="text-lg font-bold text-white font-['Sora']">
                  Type Any Topic To Learn
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-400/15 text-cyan-300 border border-cyan-400/30">
                  Made by Nceba
                </span>
              </div>
              <p className="text-xs text-[#94a3b8]">
                Mathematics, IsiXhosa, Sesotho, Physical Sciences, EMS, Technology
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#94a3b8] hover:text-white rounded-lg transition-colors"
            aria-label="Close topic modal"
          >
            <X className="size-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="modal-topic-input" className="block text-xs font-semibold text-[#94a3b8] mb-1.5">
              Topic name or question:
            </label>
            <input
              id="modal-topic-input"
              type="text"
              autoFocus
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder={modalPlaceholder}
              className="w-full px-4 py-3 rounded-xl bg-[#080d19] border border-cyan-400/40 text-sm sm:text-base text-white placeholder-[#94a3b8]/50 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400"
            />
          </div>

          {/* Controls: Grade, Language, Length */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            {/* Grade */}
            <div className="space-y-1">
              <span className="text-[#94a3b8] font-medium block">Grade:</span>
              <div className="flex gap-1 flex-wrap">
                {[7, 8, 9].map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGrade(g)}
                    className={`px-2 py-1 rounded-lg border font-semibold ${
                      grade === g
                        ? 'border-cyan-400 bg-cyan-400/20 text-cyan-300'
                        : 'border-[#1f2d4f] bg-[#080d19] text-[#94a3b8]'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>

            {/* Language */}
            <div className="space-y-1">
              <label htmlFor="modal-lang-select" className="text-[#94a3b8] font-medium block">
                Explain in:
              </label>
              <select
                id="modal-lang-select"
                value={selectedLang}
                onChange={(e) => setSelectedLang(e.target.value as LanguageCode)}
                className="w-full py-1.5 px-2 rounded-lg bg-[#080d19] border border-[#1f2d4f] text-white text-xs outline-none cursor-pointer"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code} className="bg-[#0f172a] text-white">
                    {l.flag} {l.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Answer Length: Long Answer vs Concise */}
            <div className="space-y-1">
              <span className="text-[#94a3b8] font-medium block">Answer Depth:</span>
              <button
                type="button"
                onClick={() => setConcise(!concise)}
                className={`w-full py-1.5 px-2 rounded-lg border text-center font-semibold truncate transition-all ${
                  !concise
                    ? 'border-cyan-400 bg-cyan-400/15 text-cyan-300'
                    : 'border-emerald-400 bg-emerald-400/15 text-emerald-300'
                }`}
                title={!concise ? 'Full detailed long answer' : 'Concise 1-2 paragraphs'}
              >
                {!concise ? '📚 Long Answer (Detailed)' : '⚡ Short (1–2 Para)'}
              </button>
            </div>
          </div>

          {/* Quick Suggestions - Dynamic & Fresh */}
          <div className="space-y-1.5 pt-2 border-t border-[#1f2d4f]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-[#94a3b8] font-medium">Randomised suggestions:</span>
              <button
                type="button"
                onClick={() => setModalSuggestions(getRandomTopics(4))}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
              >
                <Shuffle className="size-2.5" />
                <span>Shuffle</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {modalSuggestions.map((item) => (
                <button
                  key={item.title}
                  type="button"
                  onClick={() => handlePickSuggestion(item.title, item.grade)}
                  className="text-xs px-2.5 py-1 rounded-lg border border-[#1f2d4f] bg-[#080d19] hover:border-cyan-400/40 text-[#f7f9fc] text-left truncate max-w-full"
                >
                  <span className="text-cyan-300 font-semibold">{item.subject}:</span>{' '}
                  {item.title.split('-')[1]?.trim() || item.title}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-[#1f2d4f] bg-[#18223a] text-xs font-semibold text-[#94a3b8] hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!topic.trim()}
              className="px-5 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-[#06121f] font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <Sparkles className="size-3.5" />
              <span>Generate Lesson</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

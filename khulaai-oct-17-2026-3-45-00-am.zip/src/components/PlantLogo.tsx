import React from 'react';

interface PlantLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showDetails?: boolean;
  className?: string;
}

export const PlantLogo: React.FC<PlantLogoProps> = ({
  size = 'md',
  showDetails = true,
  className = '',
}) => {
  const iconSizes = {
    sm: 'size-8',
    md: 'size-10',
    lg: 'size-12',
  };

  const titleSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  return (
    <div className={`flex items-center gap-3 select-none group ${className}`}>
      {/* Plant / Sprout Emblem */}
      <div className={`relative ${iconSizes[size]} shrink-0 flex items-center justify-center`}>
        {/* Subtle verdant aura glow */}
        <div
          aria-hidden="true"
          className="absolute -inset-1 rounded-2xl bg-gradient-to-tr from-emerald-500/30 via-teal-400/25 to-cyan-400/20 blur-md opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300 pointer-events-none"
        />

        {/* Plant Icon Box */}
        <div className="relative w-full h-full rounded-2xl bg-[#081512] border border-emerald-500/40 p-1.5 shadow-xl flex items-center justify-center overflow-hidden">
          {/* Subtle gradient sheen */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/15 via-transparent to-teal-500/20 pointer-events-none" />

          {/* Plant Sprout SVG */}
          <svg
            viewBox="0 0 32 32"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full relative z-10 transition-transform duration-300 group-hover:scale-105"
            aria-hidden="true"
          >
            {/* Ground / Seed Base */}
            <path
              d="M7 26C11 24.5 21 24.5 25 26"
              stroke="#059669"
              strokeWidth="2"
              strokeLinecap="round"
            />
            {/* Main Central Stem Growing Upwards */}
            <path
              d="M16 25C16 19 15.5 13 18.5 7"
              stroke="url(#stem-gradient)"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            {/* Left Lush Leaf Unfurling */}
            <path
              d="M16 17C12 17 9 13.5 10 10C13.5 10 15.5 13 16 17Z"
              fill="url(#leaf-left)"
              stroke="#10B981"
              strokeWidth="1.2"
              strokeLinejoin="round"
            />
            {/* Right Fresh Leaf Sprouting */}
            <path
              d="M17 13.5C21 13 23.5 9.5 22 6.5C18.5 7 17 10 17 13.5Z"
              fill="url(#leaf-right)"
              stroke="#34D399"
              strokeWidth="1.2"
              strokeLinejoin="round"
            />
            {/* Tiny Budding Sprout at Top */}
            <circle cx="18.5" cy="6.5" r="1.5" fill="#6EE7B7" className="animate-pulse" />

            <defs>
              <linearGradient id="stem-gradient" x1="16" y1="25" x2="18.5" y2="7" gradientUnits="userSpaceOnUse">
                <stop stopColor="#047857" />
                <stop offset="0.6" stopColor="#10B981" />
                <stop offset="1" stopColor="#34D399" />
              </linearGradient>
              <linearGradient id="leaf-left" x1="9.5" y1="10" x2="16" y2="17" gradientUnits="userSpaceOnUse">
                <stop stopColor="#10B981" />
                <stop offset="1" stopColor="#047857" />
              </linearGradient>
              <linearGradient id="leaf-right" x1="17" y1="6.5" x2="23" y2="13.5" gradientUnits="userSpaceOnUse">
                <stop stopColor="#34D399" />
                <stop offset="1" stopColor="#059669" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* Typography: Name, Slogan & Creator */}
      {showDetails && (
        <div className="flex flex-col text-left leading-none">
          <div className="flex items-center gap-2">
            <span className={`${titleSizes[size]} font-black tracking-tight text-white font-['Sora'] flex items-center gap-1.5`}>
              <span>KHULA</span>
              <span className="text-emerald-400 font-extrabold text-[0.8em] tracking-wider">AI</span>
            </span>

            {/* Authentic South African Student Creator Badge */}
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/10 text-emerald-300 border border-emerald-400/30">
              by Nceba
            </span>
          </div>

          <p className="text-[11px] font-medium text-[#94a3b8] mt-1 hidden sm:block tracking-normal">
            Built for South African High School Students
          </p>
        </div>
      )}
    </div>
  );
};

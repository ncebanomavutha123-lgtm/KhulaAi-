import React, { useState } from 'react';
import {
  BookOpen,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Calculator,
  FlaskConical,
  Coins,
  Cpu,
  Compass,
  Languages,
  CheckCircle2,
} from 'lucide-react';
import { POPULAR_TOPICS } from '../data/capsTopics';

interface SubjectLibraryProps {
  onSelectTopic: (topic: string, grade: number) => void;
  onOpenTopicModal: () => void;
}

interface SubjectCatalog {
  name: string;
  icon: any;
  color: string;
  grades: number[];
  terms: {
    term: number;
    title: string;
    topics: string[];
  }[];
}

const CAPS_LIBRARY: SubjectCatalog[] = [
  {
    name: 'Mathematics',
    icon: Calculator,
    color: 'text-cyan-400 bg-cyan-400/10 border-cyan-400/30',
    grades: [7, 8, 9],
    terms: [
      {
        term: 1,
        title: 'Numbers, Operations & Relationships',
        topics: ['Whole Numbers & Properties', 'Integers & Rules of Signs', 'Common Fractions & Percentages', 'Decimal Fractions'],
      },
      {
        term: 2,
        title: 'Patterns, Functions & Algebra',
        topics: ['Numeric & Geometric Patterns', 'Algebraic Expressions & Like Terms', 'Algebraic Equations with Balance Scale', 'Linear Number Patterns'],
      },
      {
        term: 3,
        title: 'Space & Shape (Geometry)',
        topics: ['Geometry of 2D Shapes', 'Geometry of Straight Lines', 'Construction of Geometric Figures', 'Transformation Geometry'],
      },
      {
        term: 4,
        title: 'Measurement & Theorem of Pythagoras',
        topics: ['Theorem of Pythagoras in Right Triangles', 'Perimeter & Area of 2D Shapes', 'Surface Area & Volume of 3D Objects', 'Data Handling & Probability'],
      },
    ],
  },
  {
    name: 'IsiXhosa',
    icon: Languages,
    color: 'text-rose-400 bg-rose-400/10 border-rose-400/30',
    grades: [7, 8, 9],
    terms: [
      {
        term: 1,
        title: 'Ukuphulaphula, Ukuthetha & Izakhi Zegama',
        topics: ['Amahlelo Ezibizo (Class 1-15)', 'Izivumelanisi Zentloko Nezinto', 'Izibongo Zenkqubela Neempawu Zazo', 'Ukwakhiwa Kwezivakalisi'],
      },
      {
        term: 2,
        title: 'Ufundo, Uvavanyo & Izaci Namaqhalo',
        topics: ['Izaci Namaqhalo EsiXhosa', 'Ukufunda Okunzulu Nokuvavanya', 'Izincoko Zokuqiqa Nezibalisayo', 'Uhlalutyo Lwamagama Adityanisiweyo'],
      },
      {
        term: 3,
        title: 'Uncwadi Lwesintu & Imidlalo Yeqonga',
        topics: ['Uhlalutyo Lwencwadi Yomdlalo', 'Abalinganiswa Nengxabano', 'Izifaniso, Izikweko Nesigqebelo', 'Ukubhala Ileta Yesikweni'],
      },
      {
        term: 4,
        title: 'Ukulungiselela Iimviwo & Uphuhliso Lwesigama',
        topics: ['Iimpawu Zokubhala Nezilandu', 'Izifinyezo Nezifinyezo Zemigaqo', 'Imibongo Yesizwe Nemfundiso', 'Uvavanyo Lwangaphambili Nolungiso'],
      },
    ],
  },
  {
    name: 'Sesotho',
    icon: Languages,
    color: 'text-amber-400 bg-amber-400/10 border-amber-400/30',
    grades: [7, 8, 9],
    terms: [
      {
        term: 1,
        title: 'Ho Mamela, ho Bua & Mahloko a Puo',
        topics: ['Mehaho ya Mabitso a Sesotho', 'Dikatolosathuo le Sebopeho sa Maetsi', 'Dithoko tsa Sesotho le Morero', 'Popeho ya Dipolelo tse Ntle'],
      },
      {
        term: 2,
        title: 'Maele, Maelana & Ho Ngola Ditlhamo',
        topics: ['Maele a Bohlokwa le Moelelo', 'Mefuta ya Ditlhamo (Tse hlalosang le tse phehang khang)', 'Maelana a Phelang Setjhabeng', 'Mangolo a Semmuso le a Metswalle'],
      },
      {
        term: 3,
        title: 'Dingolwa tsa Sesotho & Dipapadi',
        topics: ['Tshekatsheko ya Terama ya Sesotho', 'Semelo sa Baphetwa le Dikgohlano', 'Ditshwantsho tsa Puo (Mothofatso, Tshwantshiso)', 'Tlhaloso ya Diketsahalo'],
      },
      {
        term: 4,
        title: 'Tokiso ya Ditlhahlobo & Teko ya Puo',
        topics: ['Dikarolo tsa Puo le Tshebediso ya Tsona', 'Ho Qapa Thothokiso e Khutshwane', 'Tlhophiso ya Ditlhahlobo tsa CAPS', 'Dipotso le Dikarabo tsa Mehlala'],
      },
    ],
  },
  {
    name: 'Natural Sciences',
    icon: FlaskConical,
    color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30',
    grades: [7, 8, 9],
    terms: [
      {
        term: 1,
        title: 'Life & Living',
        topics: ['Photosynthesis & Cellular Respiration', 'Interactions in Ecosystems', 'Microorganisms & Disease', 'Biodiversity & Classification'],
      },
      {
        term: 2,
        title: 'Matter & Materials',
        topics: ['Atoms & Elements of the Periodic Table', 'Particle Model of Matter', 'Chemical Reactions & Balancing', 'Acids, Bases & Neutralisation'],
      },
      {
        term: 3,
        title: 'Energy & Change',
        topics: ['Static Electricity & Circuit Components', 'Series & Parallel Circuits', 'Cost of Electrical Power & National Grid', 'Visible Light & Reflection'],
      },
      {
        term: 4,
        title: 'Planet Earth & Beyond',
        topics: ['The Solar System & Beyond', 'Telescopes & Astronomical Instruments', 'Mining of Mineral Resources in SA', 'Atmospheric Layers & Weather'],
      },
    ],
  },
  {
    name: 'Economic & Management Sciences',
    icon: Coins,
    color: 'text-amber-400 bg-amber-400/10 border-amber-400/30',
    grades: [7, 8, 9],
    terms: [
      {
        term: 1,
        title: 'The Economy & Financial Literacy',
        topics: ['Accounting Equation: Assets, OE, Liabilities', 'History of Money & Banking', 'Needs, Wants & Scarcity', 'Cash Receipts Journal (CRJ)'],
      },
      {
        term: 2,
        title: 'Entrepreneurship & Businesses',
        topics: ['Forms of Business Ownership', 'Levels and Functions of Management', 'Cash Payments Journal (CPJ)', 'Price Theory & Market Equilibrium'],
      },
      {
        term: 3,
        title: 'Trade & Financial Statements',
        topics: ['The National Budget & Taxes in SA', 'Trial Balance & Financial Ledgers', 'Factors of Production', 'Trade Unions & Labour Laws'],
      },
      {
        term: 4,
        title: 'Economic Growth & Productivity',
        topics: ['Productivity & Sustainable Resource Use', 'Business Plan Development', 'Year-End Financial Summaries', 'Saving & Investment Options'],
      },
    ],
  },
  {
    name: 'Technology',
    icon: Cpu,
    color: 'text-purple-400 bg-purple-400/10 border-purple-400/30',
    grades: [7, 8, 9],
    terms: [
      {
        term: 1,
        title: 'Structures & Design Process',
        topics: ['Types of Structures: Frame, Shell, Solid', 'Investigating Structural Failure & Bracing', 'Design Process: Investigate, Design, Make', 'Working Drawings & Orthographic Views'],
      },
      {
        term: 2,
        title: 'Mechanical Systems & Control',
        topics: ['Levers of Class 1, 2, and 3', 'Mechanical Advantage Calculations', 'Gears & Velocity Ratios', 'Cams, Cranks & Pulleys'],
      },
      {
        term: 3,
        title: 'Electrical & Electronic Systems',
        topics: ['Simple Circuits & Switches', 'Logic Gates & Digital Control', 'Component Symbols & Schematics', 'Energy Preservation in Tech'],
      },
      {
        term: 4,
        title: 'Processing Materials & Impact',
        topics: ['Properties of Plastics, Metals, Timber', 'Recycling & Environmental Impact', 'Preserving Food & Processing Techniques', 'Indigenous Technology in SA'],
      },
    ],
  },
];

export const SubjectLibrary: React.FC<SubjectLibraryProps> = ({
  onSelectTopic,
  onOpenTopicModal,
}) => {
  const [activeSubject, setActiveSubject] = useState<string>('Mathematics');
  const [activeGrade, setActiveGrade] = useState<number>(8);

  const subjectData = CAPS_LIBRARY.find((s) => s.name === activeSubject) || CAPS_LIBRARY[0];
  const Icon = subjectData.icon;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="rounded-3xl border border-[#223052] bg-gradient-to-r from-[#121a2d] via-[#17223e] to-[#121a2d] p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-cyan-400/15 text-cyan-300 border border-cyan-400/30">
              Made by Nceba
            </span>
            <span className="text-xs text-[#aab4c8]">South African National Curriculum</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            CAPS Subject & Topic Library
          </h2>
          <p className="text-sm text-[#aab4c8] max-w-xl">
            Browse the official South African curriculum for Grades 7–9. Choose any topic from Term 1 to Term 4 to
            generate an instant structured study plan and notebook-ready practice exercises.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenTopicModal}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-[#06121f] font-bold text-sm shadow-lg shadow-cyan-400/20 transition-all shrink-0 focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
        >
          <Sparkles className="size-4" />
          <span>Type Any Topic</span>
        </button>
      </div>

      {/* Grade & Subject Selector */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#121a2d] p-4 rounded-2xl border border-[#223052]">
        <div className="flex items-center gap-2 overflow-x-auto">
          {CAPS_LIBRARY.map((s) => {
            const SIcon = s.icon;
            const isSelected = activeSubject === s.name;
            return (
              <button
                key={s.name}
                type="button"
                onClick={() => setActiveSubject(s.name)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-cyan-400 text-[#06121f] shadow-md'
                    : 'bg-[#18223a] text-[#aab4c8] hover:text-white'
                }`}
              >
                <SIcon className="size-4 shrink-0" />
                <span>{s.name}</span>
              </button>
            );
          })}
        </div>

        {/* Grade switch */}
        <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
          <span className="text-xs text-[#aab4c8] font-medium mr-1">Grade:</span>
          {[7, 8, 9].map((g) => (
            <button
              key={g}
              type="button"
              onClick={() => setActiveGrade(g)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeGrade === g
                  ? 'bg-cyan-400/20 text-cyan-300 border border-cyan-400/50'
                  : 'bg-[#18223a] text-[#aab4c8] border border-[#223052]'
              }`}
            >
              Grade {g}
            </button>
          ))}
        </div>
      </div>

      {/* Terms Grid */}
      <div className="grid gap-6 md:grid-cols-2">
        {subjectData.terms.map((termObj) => (
          <div
            key={termObj.term}
            className="rounded-3xl border border-[#223052] bg-[#121a2d] p-6 space-y-4 hover:border-cyan-400/40 transition-colors shadow-lg"
          >
            <div className="flex items-center justify-between border-b border-[#223052] pb-3">
              <span className="text-xs font-extrabold uppercase tracking-wider text-cyan-400 px-2.5 py-0.5 rounded-full bg-cyan-400/10 border border-cyan-400/20">
                Term {termObj.term}
              </span>
              <span className="text-xs text-[#aab4c8] font-medium">Grade {activeGrade}</span>
            </div>

            <h3 className="font-extrabold text-white text-base">
              {termObj.title}
            </h3>

            <ul className="space-y-2">
              {termObj.topics.map((tName) => {
                const fullTopicString = `${activeSubject} Grade ${activeGrade} Term ${termObj.term} - ${tName}`;
                return (
                  <li key={tName}>
                    <button
                      type="button"
                      onClick={() => onSelectTopic(fullTopicString, activeGrade)}
                      className="w-full text-left p-3 rounded-xl bg-[#0b1020]/70 hover:bg-[#18223a] border border-[#223052] hover:border-cyan-400/50 text-xs sm:text-sm text-white font-medium flex items-center justify-between group transition-all"
                    >
                      <span>{tName}</span>
                      <span className="text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-xs font-semibold shrink-0">
                        Study Plan <ArrowRight className="size-3" />
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

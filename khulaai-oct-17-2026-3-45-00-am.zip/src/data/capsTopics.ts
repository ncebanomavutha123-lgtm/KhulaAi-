import { LanguageOption, TopicSuggestion } from '../types';

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'auto', label: 'Auto-Detect', native: 'Matches your question', flag: '🌐' },
  { code: 'en', label: 'English', native: 'English', flag: '🇿🇦' },
  { code: 'xh', label: 'isiXhosa', native: 'isiXhosa', flag: '🇿🇦' },
  { code: 'st', label: 'Sesotho', native: 'Sesotho', flag: '🇿🇦' },
];

export const ALL_CAPS_TOPICS_POOL: TopicSuggestion[] = [
  // IsiXhosa (Distinct CAPS Subject: Home Language & FAL - Grades 7-9)
  {
    title: 'IsiXhosa Ibanga 8 Ikota 2 - Izaci Namaqhalo Nemizekelo Ebalulekileyo',
    subject: 'IsiXhosa',
    grade: 8,
    term: 2,
    description: 'Uhlalutyo lwezaci namaqhalo esiXhosa, intsingiselo efihlakeleyo, nokusetyenziswa kwayo kwizivakalisi',
  },
  {
    title: 'IsiXhosa Ibanga 9 Ikota 1 - Izibongo Zenkqubela Nezakhi Zegama',
    subject: 'IsiXhosa',
    grade: 9,
    term: 1,
    description: 'Iimpawu zombongo wesintu (imvano-zandi, isigqebelo, isikweko) kunye nezimaphambili nezakhi zegama',
  },
  {
    title: 'IsiXhosa Ibanga 8 Ikota 3 - Ukubhala Incoko Yokuqiqa Nemigaqo Yolwimi',
    subject: 'IsiXhosa',
    grade: 8,
    term: 3,
    description: 'Ukuyila izincoko zokuqiqa, iziqendu ezinentsingiselo, izihlanganisi, kunye nohlalutyo lweempazamo',
  },
  {
    title: 'IsiXhosa Ibanga 9 Ikota 2 - Uhlalutyo Lwencwadi Yomdlalo Noncwadi Lwesintu',
    subject: 'IsiXhosa',
    grade: 9,
    term: 2,
    description: 'Abalinganiswa, ungquzulwano, umxholo ophambili, nemfundiso yomdlalo noncwadi lwe-CAPS',
  },
  {
    title: 'IsiXhosa Ibanga 7 Ikota 4 - Izimaphambili Zamahlelo Ezibizo Nezilandu',
    subject: 'IsiXhosa',
    grade: 7,
    term: 4,
    description: 'Amahlelo ezibizo zesiXhosa (Class 1-15), izivumelanisi zentloko, nokwakha izivakalisi ezilandulayo',
  },

  // Sesotho (Distinct CAPS Subject: Puo ya Lapeng & FAL - Grades 7-9)
  {
    title: 'Sesotho Kereiti 8 Kotara 2 - Maele le Maelana a Sesotho le Tshebediso ya Wona',
    subject: 'Sesotho',
    grade: 8,
    term: 2,
    description: 'Tjhebelo le tlhaloso ya maele a bohlokwa a Sesotho, moelelo o ipabolang, le mehlala e phelang',
  },
  {
    title: 'Sesotho Kereiti 9 Kotara 1 - Dithoko tsa Sesotho le Mehopolo ya Bohlokwa',
    subject: 'Sesotho',
    grade: 9,
    term: 1,
    description: 'Dintlha tsa thothokiso (mothofatso, tshwantshiso, phetapheto) le popeho ya seroki sa Sesotho',
  },
  {
    title: 'Sesotho Kereiti 8 Kotara 3 - Mefuta ya Dipolelo le Mahloko a Puo',
    subject: 'Sesotho',
    grade: 8,
    term: 3,
    description: 'Dipolelo tse bonolo le tse rarahaneng, mefuta ya maetsi, mehaho ya mabitso le dikatolosathuo',
  },
  {
    title: 'Sesotho Kereiti 9 Kotara 2 - Dipapadi tsa Sesotho le Baphetwa',
    subject: 'Sesotho',
    grade: 9,
    term: 2,
    description: 'Tshekatsheko ya terama ya Sesotho, dikgohlano, semelo sa baphetwa, le molaetsa o tobileng',
  },
  {
    title: 'Sesotho Kereiti 7 Kotara 4 - Ho Ngola Ditlhamo le Ditema tsa Dikgokagano',
    subject: 'Sesotho',
    grade: 7,
    term: 4,
    description: 'Mohato ka mohato wa ho qapa moqoqo o qholotsang kelello le mangolo a semmuso le a setswalle',
  },

  // Mathematics (Grades 7-9 Senior Phase)
  {
    title: 'Maths Grade 9 Term 3 - Factorising Quadratic Trinomials & Difference of Squares',
    subject: 'Mathematics',
    grade: 9,
    term: 3,
    description: 'Factorising x² + bx + c, grouping techniques, and difference of two squares with step-by-step checks',
  },
  {
    title: 'Maths Grade 8 Term 2 - Algebraic Expressions & Solving Linear Equations',
    subject: 'Mathematics',
    grade: 8,
    term: 2,
    description: 'Collecting like terms, distributive property, balancing equations: 3x - 5 = 16',
  },
  {
    title: 'Maths Grade 8 Term 4 - Theorem of Pythagoras & Triangle Properties',
    subject: 'Mathematics',
    grade: 8,
    term: 4,
    description: 'Right-angled triangles, calculating hypotenuse and shorter legs (c² = a² + b²), and converse tests',
  },
  {
    title: 'Maths Grade 9 Term 2 - Geometry of Straight Lines & Alternate/Corresponding Angles',
    subject: 'Mathematics',
    grade: 9,
    term: 2,
    description: 'Parallel lines cut by transversals, fun angles (F, U, N), vertically opposite, and sum of triangle angles',
  },
  {
    title: 'Maths Grade 9 Term 1 - Exponents & Scientific Notation',
    subject: 'Mathematics',
    grade: 9,
    term: 1,
    description: 'Laws of exponents: multiplication, division, power of a power, zero exponent, and negative powers',
  },
  {
    title: 'Maths Grade 8 Term 1 - Integers & Order of Operations (BODMAS)',
    subject: 'Mathematics',
    grade: 8,
    term: 1,
    description: 'Adding, subtracting, multiplying and dividing positive and negative numbers with BODMAS',
  },

  // Natural Sciences (Grades 7-9 Senior Phase)
  {
    title: 'Natural Sciences Grade 9 Term 2 - Photosynthesis & Cellular Energy',
    subject: 'Natural Sciences',
    grade: 9,
    term: 2,
    description: 'Chlorophyll energy conversion, glucose and oxygen generation, respiration equation balance',
  },
  {
    title: 'Natural Sciences Grade 8 Term 2 - Atoms, Periodic Table & Chemical Reactions',
    subject: 'Natural Sciences',
    grade: 8,
    term: 2,
    description: 'Protons, neutrons, electrons, first 20 elements, atomic numbers, and chemical symbols',
  },
  {
    title: 'Natural Sciences Grade 9 Term 3 - Electric Cells, Resistance & Series/Parallel Circuits',
    subject: 'Natural Sciences',
    grade: 9,
    term: 3,
    description: 'Current, potential difference, resistance in series and parallel circuits with voltage division',
  },
  {
    title: 'Natural Sciences Grade 8 Term 3 - Contact & Non-Contact Forces',
    subject: 'Natural Sciences',
    grade: 8,
    term: 3,
    description: 'Gravitational, electrostatic, and magnetic forces, friction, normal force, and balanced vs unbalanced systems',
  },

  // Economic and Management Sciences (EMS - Grades 7-9)
  {
    title: 'EMS Grade 8 Term 1 - The Accounting Equation (A = OE + L)',
    subject: 'EMS',
    grade: 8,
    term: 1,
    description: 'Analysis of financial transactions on Assets, Owner Equity, and Liabilities with double-entry proof',
  },
  {
    title: 'EMS Grade 9 Term 2 - Cash Receipts Journal & Cash Payments Journal',
    subject: 'EMS',
    grade: 9,
    term: 2,
    description: 'Recording source documents, cash register slips, cheques, and posting to the General Ledger',
  },
  {
    title: 'EMS Grade 8 Term 2 - Financial Literacy: Source Documents & Cheques',
    subject: 'EMS',
    grade: 8,
    term: 2,
    description: 'Deposit slips, receipts, cash invoices, and bank statements in South African small businesses',
  },

  // Technology (Grades 7-9)
  {
    title: 'Technology Grade 7 Term 3 - Levers & Mechanical Advantage',
    subject: 'Technology',
    grade: 7,
    term: 3,
    description: 'Classes of levers (1st, 2nd, 3rd), fulcrum placement, effort vs load, and MA calculation formula',
  },
  {
    title: 'Technology Grade 8 Term 2 - Gear Systems & Velocity Ratios',
    subject: 'Technology',
    grade: 8,
    term: 2,
    description: 'Driver and driven spur gears, idler gears, calculating velocity ratios and torque changes',
  },

  // Social Sciences (Grades 7-9)
  {
    title: 'Social Sciences Grade 8 Term 2 - The Mineral Revolution in South Africa',
    subject: 'Social Sciences',
    grade: 8,
    term: 2,
    description: 'Discovery of diamonds in Kimberley (1867) and gold in Witwatersrand (1886) transforming society',
  },
];

// Helper to get randomized topics on page refresh or shuffle
export function getRandomTopics(count = 6, avoidTitle?: string): TopicSuggestion[] {
  const pool = avoidTitle
    ? ALL_CAPS_TOPICS_POOL.filter((t) => t.title.toLowerCase() !== avoidTitle.toLowerCase())
    : [...ALL_CAPS_TOPICS_POOL];

  // Fisher-Yates shuffle
  const shuffled = [...pool];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  // Ensure diversity: pick across diverse subjects if possible
  const selected: TopicSuggestion[] = [];
  const seenSubjects = new Set<string>();

  for (const item of shuffled) {
    if (!seenSubjects.has(item.subject)) {
      selected.push(item);
      seenSubjects.add(item.subject);
      if (selected.length === count) break;
    }
  }

  // Fill up if needed
  if (selected.length < count) {
    for (const item of shuffled) {
      if (!selected.includes(item)) {
        selected.push(item);
        if (selected.length === count) break;
      }
    }
  }

  return selected.slice(0, count);
}

// Randomize search placeholder on refresh
export function getRandomPlaceholderTopic(): string {
  const candidates = [
    'IsiXhosa Ibanga 8 Ikota 2 - Izaci Namaqhalo',
    'Sesotho Kereiti 9 Kotara 1 - Dithoko tsa Sesotho',
    'Maths Grade 9 Term 3 - Factorising Trinomials',
    'Natural Sciences Grade 9 Term 2 - Photosynthesis',
    'EMS Grade 8 Term 1 - Accounting Equation',
    'Maths Grade 8 Term 2 - Algebraic Expressions',
    'IsiXhosa Ibanga 9 Ikota 1 - Izibongo Zenkqubela',
    'Sesotho Kereiti 8 Kotara 2 - Maele le Maelana',
    'Natural Sciences Grade 8 Term 2 - Periodic Table',
    'Technology Grade 8 Term 2 - Gear Systems',
  ];
  const idx = Math.floor(Math.random() * candidates.length);
  return candidates[idx];
}

export const POPULAR_TOPICS = getRandomTopics(6);

export const SUBJECT_FILTERS = [
  'All Subjects',
  'Mathematics',
  'IsiXhosa',
  'Sesotho',
  'Natural Sciences',
  'EMS',
  'Technology',
  'Social Sciences',
];

import React, { createContext, useContext, useState, useEffect } from 'react';
import { CompletedActivityRecord, LanguageCode, LearnerAccount, SubjectMastery } from '../types';

interface LearnerContextType {
  account: LearnerAccount | null;
  isAuthenticated: boolean;
  isOwner: boolean;
  signUp: (name: string, email: string, grade: number, language: LanguageCode) => void;
  login: (email: string) => boolean;
  logout: () => void;
  recordCompletedActivity: (activityTitle: string, subject: string, score: number, total: number) => void;
  recordCompletedStudyDay: (topic: string, day: string) => void;
  recordMasteredTopic: (topic: string, subject: string) => void;
  getSubjectMasteryList: () => SubjectMastery[];
}

const LearnerContext = createContext<LearnerContextType | null>(null);

const STORAGE_ACTIVE_KEY = 'khula_active_account_v1';
const STORAGE_REGISTRY_KEY = 'khula_accounts_registry_v1';

const ALL_SUBJECTS = [
  'Mathematics',
  'IsiXhosa',
  'Sesotho',
  'Natural Sciences',
  'Economic & Management Sciences',
  'Technology',
  'English Home Language',
  'Social Sciences',
];

export const LearnerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [account, setAccount] = useState<LearnerAccount | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_ACTIVE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Keep saved to localStorage whenever account updates
  useEffect(() => {
    if (account) {
      try {
        localStorage.setItem(STORAGE_ACTIVE_KEY, JSON.stringify(account));
        // Also update in registry
        const regRaw = localStorage.getItem(STORAGE_REGISTRY_KEY);
        const registry: Record<string, LearnerAccount> = regRaw ? JSON.parse(regRaw) : {};
        registry[account.email.toLowerCase()] = account;
        localStorage.setItem(STORAGE_REGISTRY_KEY, JSON.stringify(registry));
      } catch (err) {
        console.error('Failed to save account to localStorage', err);
      }
    }
  }, [account]);

  // Streak verification on load
  useEffect(() => {
    if (!account) return;
    const todayStr = new Date().toISOString().split('T')[0];
    if (account.lastActiveDate !== todayStr) {
      const lastDate = new Date(account.lastActiveDate);
      const today = new Date(todayStr);
      const diffDays = Math.round((today.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));

      if (diffDays === 1) {
        // Consecutive day
        setAccount((prev) => (prev ? { ...prev, streakDays: prev.streakDays + 1, lastActiveDate: todayStr } : null));
      } else if (diffDays > 1) {
        // Streak lapsed, restart at 1
        setAccount((prev) => (prev ? { ...prev, streakDays: 1, lastActiveDate: todayStr } : null));
      }
    }
  }, []);

  const isOwner = Boolean(
    account?.email &&
      (account.email.toLowerCase() === 'ncebanomavutha123@gmail.com' ||
        account.email.toLowerCase() === 'ncebanomavutha123gmail.com')
  );

  // Sign up a brand new student: PROGRESS STARTS STRICTLY AT 0%
  const signUp = (name: string, email: string, grade: number, language: LanguageCode) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const cleanEmail = email.trim().toLowerCase();

    const newAccount: LearnerAccount = {
      id: `learner_${Date.now()}`,
      name: name.trim() || 'Learner',
      email: cleanEmail,
      grade,
      language,
      createdAt: new Date().toLocaleDateString('en-ZA', { year: 'numeric', month: 'long', day: 'numeric' }),
      streakDays: 1,
      lastActiveDate: todayStr,
      totalHoursStudied: 0,
      activitiesCompletedCount: 0,
      completedActivities: [],
      masteredTopics: [],
      overallMasteryPercentage: 0, // STRICTLY 0% AT SIGN UP
      subjectScores: {},
    };

    setAccount(newAccount);

    // Save to registry
    try {
      const regRaw = localStorage.getItem(STORAGE_REGISTRY_KEY);
      const registry: Record<string, LearnerAccount> = regRaw ? JSON.parse(regRaw) : {};
      registry[cleanEmail] = newAccount;
      localStorage.setItem(STORAGE_REGISTRY_KEY, JSON.stringify(registry));
      localStorage.setItem(STORAGE_ACTIVE_KEY, JSON.stringify(newAccount));
    } catch {
      // ignore
    }
  };

  const login = (email: string): boolean => {
    try {
      const cleanEmail = email.trim().toLowerCase();
      const regRaw = localStorage.getItem(STORAGE_REGISTRY_KEY);
      const registry: Record<string, LearnerAccount> = regRaw ? JSON.parse(regRaw) : {};
      const found = registry[cleanEmail];
      if (found) {
        setAccount(found);
        localStorage.setItem(STORAGE_ACTIVE_KEY, JSON.stringify(found));
        return true;
      }
    } catch {
      // ignore
    }
    return false;
  };

  const logout = () => {
    setAccount(null);
    try {
      localStorage.removeItem(STORAGE_ACTIVE_KEY);
    } catch {
      // ignore
    }
  };

  // Record an activity completion: increases progress and never resets!
  const recordCompletedActivity = (activityTitle: string, subject: string, score: number, total: number) => {
    if (!account) return;

    const percentage = Math.round((score / Math.max(total, 1)) * 100);
    const todayStr = new Date().toISOString().split('T')[0];

    const record: CompletedActivityRecord = {
      id: `act_${Date.now()}`,
      title: activityTitle,
      subject,
      score,
      total,
      percentage,
      completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setAccount((prev) => {
      if (!prev) return null;

      const newActivities = [record, ...prev.completedActivities];
      const newCount = prev.activitiesCompletedCount + 1;
      const newHours = Number((prev.totalHoursStudied + 0.25).toFixed(1)); // +15 mins

      // Update subject scores
      const prevSub = prev.subjectScores[subject] || { attempts: 0, totalScore: 0, maxScore: 0 };
      const updatedSubjectScores = {
        ...prev.subjectScores,
        [subject]: {
          attempts: prevSub.attempts + 1,
          totalScore: prevSub.totalScore + score,
          maxScore: prevSub.maxScore + total,
        },
      };

      // Calculate progress starting from 0% and increasing:
      // Each completed activity contributes +5% base progress + score weighted bonus
      const activityPoints = newActivities.reduce((acc, curr) => acc + (curr.percentage / 100) * 5, 0);
      const topicPoints = prev.masteredTopics.length * 6;
      const calculatedMastery = Math.min(100, Math.round(activityPoints + topicPoints));

      return {
        ...prev,
        lastActiveDate: todayStr,
        activitiesCompletedCount: newCount,
        completedActivities: newActivities,
        totalHoursStudied: newHours,
        subjectScores: updatedSubjectScores,
        overallMasteryPercentage: Math.max(prev.overallMasteryPercentage, calculatedMastery),
      };
    });
  };

  // Record a completed study day in a 4-day plan
  const recordCompletedStudyDay = (topicName: string, day: string) => {
    if (!account) return;

    setAccount((prev) => {
      if (!prev) return null;
      const newHours = Number((prev.totalHoursStudied + 0.2).toFixed(1));
      // Increase progress by 2% for each study plan day accomplished
      const newMastery = Math.min(100, prev.overallMasteryPercentage + 2);

      return {
        ...prev,
        totalHoursStudied: newHours,
        overallMasteryPercentage: newMastery,
      };
    });
  };

  // Record mastered topic
  const recordMasteredTopic = (topicName: string, subject: string) => {
    if (!account) return;

    setAccount((prev) => {
      if (!prev) return null;
      if (prev.masteredTopics.includes(topicName)) return prev;

      const newTopics = [...prev.masteredTopics, topicName];
      const newMastery = Math.min(100, prev.overallMasteryPercentage + 5);

      return {
        ...prev,
        masteredTopics: newTopics,
        overallMasteryPercentage: newMastery,
      };
    });
  };

  // Generate subject mastery list
  const getSubjectMasteryList = (): SubjectMastery[] => {
    if (!account) {
      return ALL_SUBJECTS.map((sub) => ({
        subject: sub,
        level: 0,
        completedTopics: 0,
        totalTopics: 10,
        grade: 8,
        recentScore: '0%',
      }));
    }

    return ALL_SUBJECTS.map((sub) => {
      const stat = account.subjectScores[sub];
      let level = 0;
      let recentScore = '0%';
      let completed = 0;

      if (stat && stat.attempts > 0) {
        level = Math.min(100, Math.round((stat.totalScore / Math.max(stat.maxScore, 1)) * 100));
        recentScore = `${level}%`;
        completed = stat.attempts;
      }

      // Also factor in mastered topics
      const topicBonus = account.masteredTopics.filter((t) => t.toLowerCase().includes(sub.toLowerCase())).length;
      completed += topicBonus;
      if (topicBonus > 0 && level === 0) {
        level = Math.min(100, topicBonus * 20);
        recentScore = `${level}%`;
      }

      return {
        subject: sub,
        level,
        completedTopics: completed,
        totalTopics: 10,
        grade: account.grade,
        recentScore,
      };
    });
  };

  return (
    <LearnerContext.Provider
      value={{
        account,
        isAuthenticated: Boolean(account),
        isOwner,
        signUp,
        login,
        logout,
        recordCompletedActivity,
        recordCompletedStudyDay,
        recordMasteredTopic,
        getSubjectMasteryList,
      }}
    >
      {children}
    </LearnerContext.Provider>
  );
};

export const useLearner = () => {
  const context = useContext(LearnerContext);
  if (!context) {
    throw new Error('useLearner must be used within LearnerProvider');
  }
  return context;
};

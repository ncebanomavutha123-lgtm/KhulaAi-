import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { AccessibilityModal } from './components/AccessibilityModal';
import { TopicSearch } from './components/TopicSearch';
import { StudyPlanViewer } from './components/StudyPlanViewer';
import { InteractiveTutor } from './components/InteractiveTutor';
import { CapsActivitiesHub } from './components/CapsActivitiesHub';
import { ProgressGenerator } from './components/ProgressGenerator';
import { SubjectLibrary } from './components/SubjectLibrary';
import { WholesomeMessage } from './components/WholesomeMessage';
import { OwnerPortalModal } from './components/OwnerPortalModal';
import { QuickTopicModal } from './components/QuickTopicModal';
import { AuthModal } from './components/AuthModal';
import { LearnerProvider, useLearner } from './context/LearnerContext';
import {
  AccessibilitySettings,
  AppPage,
  ChatMessage,
  LanguageCode,
  StudyPlanData,
  TopicSuggestion,
} from './types';
import { parseMarkdownToStudyPlan } from './utils/planParser';
import { getRandomTopics, getRandomPlaceholderTopic } from './data/capsTopics';
import {
  Sparkles,
  ArrowUp,
  RefreshCw,
  Search,
  BookOpen,
  Award,
  TrendingUp,
  Crown,
  UserPlus,
  Shuffle,
} from 'lucide-react';

const DEFAULT_SETTINGS: AccessibilitySettings = {
  highContrast: false,
  fontSize: 'normal',
  reducedMotion: false,
  screenReaderOptimized: true,
  soundEffects: true,
};

function AppContent() {
  const { account, isAuthenticated, isOwner, login, signUp } = useLearner();
  const [currentPage, setCurrentPage] = useState<AppPage>('study-plan');
  const [language, setLanguage] = useState<LanguageCode>('auto');
  const [settings, setSettings] = useState<AccessibilitySettings>(() => {
    try {
      const saved = localStorage.getItem('khula_a11y_settings');
      return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [isA11yModalOpen, setIsA11yModalOpen] = useState(false);
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState(false);
  const [isQuickTopicModalOpen, setIsQuickTopicModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signup' | 'login'>('signup');

  const [topic, setTopic] = useState('');
  const [isLoadingPlan, setIsLoadingPlan] = useState(false);
  const [studyPlan, setStudyPlan] = useState<StudyPlanData | null>(null);
  const [tutorMessages, setTutorMessages] = useState<ChatMessage[]>([]);
  const [isTutorStreaming, setIsTutorStreaming] = useState(false);

  // Randomise topics on every refresh / reload
  const [exploreTopics, setExploreTopics] = useState<TopicSuggestion[]>(() => getRandomTopics(6));

  useEffect(() => {
    setExploreTopics(getRandomTopics(6));
  }, []);

  const handleShuffleExplore = () => {
    setExploreTopics(getRandomTopics(6, exploreTopics[0]?.title));
  };

  // Apply accessibility classes to root document
  useEffect(() => {
    const root = document.documentElement;

    if (settings.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }

    root.classList.remove('text-size-lg', 'text-size-xl');
    if (settings.fontSize === 'large') {
      root.classList.add('text-size-lg');
    } else if (settings.fontSize === 'xlarge') {
      root.classList.add('text-size-xl');
    }

    try {
      localStorage.setItem('khula_a11y_settings', JSON.stringify(settings));
    } catch {
      // storage unavailable
    }
  }, [settings]);

  const handleUpdateSettings = (newSettings: Partial<AccessibilitySettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const handleOpenAuth = (mode: 'signup' | 'login' = 'signup') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  const handleSetOwnerEmail = (email: string) => {
    const success = login(email);
    if (!success) {
      signUp('Nceba', email, 8, 'en');
    }
  };

  // Generate structured study plan
  const handleGeneratePlan = async (
    targetTopic: string,
    concise: boolean = false, // Default to long/detailed per user request, user can toggle
    grade?: number,
    targetLang: LanguageCode = language
  ) => {
    if (!targetTopic.trim()) return;

    setTopic(targetTopic);
    setIsLoadingPlan(true);
    setCurrentPage('study-plan');

    try {
      const response = await fetch('/api/generate-plan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          topic: targetTopic,
          language: targetLang,
          concise,
          grade,
        }),
      });

      if (!response.ok || !response.body) {
        throw new Error('Unable to generate plan from server');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulated = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        accumulated += decoder.decode(value, { stream: true });

        const parsed = parseMarkdownToStudyPlan(accumulated, targetTopic, targetLang);
        setStudyPlan(parsed);
      }

      const finalParsed = parseMarkdownToStudyPlan(accumulated, targetTopic, targetLang);
      setStudyPlan(finalParsed);

      setTutorMessages([
        {
          id: 'welcome',
          role: 'assistant',
          content:
            targetLang === 'xh'
              ? `Molo! Ndingu-KhulaAI eyenziwe ngu-Nceba. Ndilapha ukukunceda ngesi sihloko: "${targetTopic}". Ungabuza nayiphi na into kwaye ndiza kukunika inkcazelo ebanzi okanye emfutshane ngokwesicelo sakho!`
              : targetLang === 'st'
              ? `Dumela! Ke nna KhulaAI e entsweng ke Nceba. Ke mona ho o thusa ka sehlooho sena sa CAPS: "${targetTopic}". O ka botsa potso efe kapa efe mme ke tla o fa karabo e qaqileng kapa e kgutshwane!`
              : `Hello! I am your KhulaAI tutor, made by Nceba, equipped with high-level reasoning and encouraging guidance. Ask any question about "${targetTopic}" — I can provide full long explanations or quick summaries in English, isiXhosa, or Sesotho!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err) {
      console.error('Failed to stream plan, fallbacking:', err);
      const fallbackParsed = parseMarkdownToStudyPlan('', targetTopic, targetLang);
      setStudyPlan(fallbackParsed);
    } finally {
      setIsLoadingPlan(false);
    }
  };

  const handleTranslatePlan = (langCode: string) => {
    const code = langCode as LanguageCode;
    setLanguage(code);
    if (topic) {
      handleGeneratePlan(topic, false, undefined, code);
    }
  };

  const handleResetTopic = () => {
    setStudyPlan(null);
    setTopic('');
    setTutorMessages([]);
  };

  const handleSendTutorMessage = async (text: string, longAnswer: boolean = true) => {
    const userMsg: ChatMessage = {
      id: String(Date.now()),
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...tutorMessages, userMsg];
    setTutorMessages(newMessages);
    setIsTutorStreaming(true);

    const botMsgId = String(Date.now() + 1);
    const initialBotMsg: ChatMessage = {
      id: botMsgId,
      role: 'assistant',
      content: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setTutorMessages([...newMessages, initialBotMsg]);

    try {
      const response = await fetch('/api/tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic || 'General CAPS Studies',
          language,
          concise: !longAnswer,
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      if (!response.ok || !response.body) {
        throw new Error('Failed to get answer');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let botContent = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        botContent += decoder.decode(value, { stream: true });

        setTutorMessages((prev) =>
          prev.map((m) => (m.id === botMsgId ? { ...m, content: botContent } : m))
        );
      }
    } catch (error) {
      console.error('Tutor chat error:', error);
      setTutorMessages((prev) =>
        prev.map((m) =>
          m.id === botMsgId
            ? { ...m, content: 'KhulaAI Tutor: Remember to break down the concept step by step, verify your method, and check units clearly without code symbols.' }
            : m
        )
      );
    } finally {
      setIsTutorStreaming(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#080d19] text-[#f7f9fc]">
      {/* Skip to Main Content Link for Accessibility */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 z-50 px-4 py-2 bg-cyan-400 text-black font-bold rounded-lg shadow-xl"
      >
        Skip to main content
      </a>

      {/* Header */}
      <Header
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        currentLanguage={language}
        onLanguageChange={(newLang) => {
          setLanguage(newLang);
          if (studyPlan && topic) {
            handleGeneratePlan(topic, false, undefined, newLang);
          }
        }}
        onOpenAccessibility={() => setIsA11yModalOpen(true)}
        onOpenOwnerPortal={() => setIsOwnerModalOpen(true)}
        onOpenTopicModal={() => setIsQuickTopicModalOpen(true)}
        onOpenAuth={handleOpenAuth}
        highContrast={settings.highContrast}
        isOwner={isOwner}
      />

      {/* Main Content Area */}
      <main id="main-content" className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 space-y-10">
        {/* PAGE 1: Study Plan Generator */}
        {currentPage === 'study-plan' && (
          <div className="space-y-10">
            <TopicSearch
              onSearch={(selectedTopic, concise, grade) => handleGeneratePlan(selectedTopic, concise, grade)}
              isLoading={isLoadingPlan}
              currentLanguage={language}
              onLanguageChange={setLanguage}
              initialTopic={topic}
            />

            {/* Loading State Skeleton */}
            {isLoadingPlan && !studyPlan && (
              <div
                className="p-8 rounded-3xl border border-[#1f2d4f] bg-[#0f172a] space-y-6 animate-pulse"
                role="status"
                aria-live="polite"
              >
                <div className="flex items-center gap-3">
                  <RefreshCw className="size-5 text-cyan-400 animate-spin" aria-hidden="true" />
                  <p className="text-sm font-semibold text-cyan-300">
                    Generating structured CAPS lesson in real-time... Made by Nceba
                  </p>
                </div>
                <div className="h-6 bg-[#18223a] rounded-lg w-3/4" />
                <div className="space-y-3">
                  <div className="h-4 bg-[#18223a] rounded w-full" />
                  <div className="h-4 bg-[#18223a] rounded w-5/6" />
                </div>
                <div className="grid grid-cols-2 gap-3 pt-4">
                  <div className="h-20 bg-[#18223a] rounded-2xl" />
                  <div className="h-20 bg-[#18223a] rounded-2xl" />
                </div>
              </div>
            )}

            {/* Generated Plan View */}
            {studyPlan && (
              <div className="space-y-8 animate-in fade-in-0 duration-300">
                <StudyPlanViewer
                  plan={studyPlan}
                  onTranslateTo={handleTranslatePlan}
                  onAskTutor={(q) => handleSendTutorMessage(q, true)}
                  onResetTopic={handleResetTopic}
                />

                <InteractiveTutor
                  currentTopic={topic}
                  language={language}
                  onSendMessage={handleSendTutorMessage}
                  messages={tutorMessages}
                  isStreaming={isTutorStreaming}
                />
              </div>
            )}

            {/* Explore Grid when no active plan - Randomized on refresh with Shuffle */}
            {!studyPlan && !isLoadingPlan && (
              <section aria-labelledby="hub-heading" className="space-y-8">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-[#173229] pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-400/10 text-emerald-300 border border-emerald-400/30">
                        Made by Nceba
                      </span>
                      <span className="text-xs text-[#94a3b8]">CAPS Curriculum Topics (Grades 7–9)</span>
                    </div>
                    <h2 id="hub-heading" className="text-xl sm:text-2xl font-bold text-white mt-1">
                      Curriculum Topic Inspiration
                    </h2>
                  </div>

                  <button
                    type="button"
                    onClick={handleShuffleExplore}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-emerald-400/30 bg-[#0a1814] hover:bg-emerald-400/15 text-emerald-300 text-xs font-bold transition-all shadow-sm"
                  >
                    <Shuffle className="size-3.5" />
                    <span>Shuffle Random Topics</span>
                  </button>
                </div>

                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {exploreTopics.map((item) => (
                    <div
                      key={item.title}
                      className="rounded-2xl border border-[#173229] bg-[#0a1814]/80 p-5 space-y-3 hover:border-emerald-400/50 hover:bg-[#0f241e] transition-all flex flex-col justify-between shadow-sm"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${
                            item.subject === 'IsiXhosa'
                              ? 'bg-rose-400/15 text-rose-300 border-rose-400/30'
                              : item.subject === 'Sesotho'
                              ? 'bg-amber-400/15 text-amber-300 border-amber-400/30'
                              : 'bg-emerald-400/10 text-emerald-300 border-emerald-400/20'
                          }`}>
                            {item.subject}
                          </span>
                          <span className="text-xs text-[#94a3b8]">Grade {item.grade} • Term {item.term}</span>
                        </div>
                        <h3 className="font-bold text-white text-base">
                          {item.title.split('-')[1]?.trim() || item.title}
                        </h3>
                        <p className="text-xs text-[#94a3b8] leading-relaxed">
                          {item.description}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleGeneratePlan(item.title, false, item.grade)}
                        className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-[#081512] hover:bg-emerald-400 hover:text-[#06110e] text-emerald-300 border border-[#173229] hover:border-emerald-400 text-xs font-semibold transition-all shadow-sm"
                      >
                        <span>Generate Lesson Plan</span>
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}

        {/* PAGE 2: CAPS Approved Activities Hub */}
        {currentPage === 'activities' && (
          <CapsActivitiesHub
            onOpenTopicModal={() => setIsQuickTopicModalOpen(true)}
            onSelectTopic={(selectedTopic) => handleGeneratePlan(selectedTopic, false)}
            onOpenAuth={handleOpenAuth}
          />
        )}

        {/* PAGE 3: Progress Generator & Diagnostics */}
        {currentPage === 'progress' && (
          <ProgressGenerator
            onSelectTopic={(t) => handleGeneratePlan(t, false)}
            onOpenTopicModal={() => setIsQuickTopicModalOpen(true)}
            onOpenAuth={handleOpenAuth}
          />
        )}

        {/* PAGE 4: CAPS Subject & Term Library */}
        {currentPage === 'library' && (
          <SubjectLibrary
            onSelectTopic={(t, g) => handleGeneratePlan(t, false, g)}
            onOpenTopicModal={() => setIsQuickTopicModalOpen(true)}
          />
        )}

        {/* The Wholesome Message from Nceba (Present at the bottom of the page) */}
        <WholesomeMessage />
      </main>



      {/* Footer */}
      <footer className="border-t border-[#173229] bg-[#06110e] py-8 text-xs text-[#94a3b8]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <p className="font-bold text-white flex items-center justify-center sm:justify-start gap-2">
              <span className="text-emerald-400">KHULA.AI</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-400/10 text-emerald-400 border border-emerald-400/20">
                Made by Nceba
              </span>
              {isOwner && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400/15 text-amber-300 border border-amber-400/30 flex items-center gap-1">
                  <Crown className="size-3 text-amber-400" />
                  Owner Access
                </span>
              )}
            </p>
            <p className="mt-1">
              Made by Nceba to support every South African learner across Grades 7–9 Senior Phase CAPS.
            </p>
          </div>

          <div className="flex items-center gap-4 flex-wrap justify-center">
            {isAuthenticated ? (
              <button
                type="button"
                onClick={() => setCurrentPage('progress')}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1 font-semibold"
              >
                <span>Learner: {account?.name} ({account?.overallMasteryPercentage}%)</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleOpenAuth('signup')}
                className="hover:text-emerald-400 transition-colors flex items-center gap-1 font-semibold"
              >
                <UserPlus className="size-3 text-emerald-400" />
                <span>Sign Up (0% Progress)</span>
              </button>
            )}

            {/* CREATOR CONTROL ROOM: ONLY SHOWN IF OWNER EMAIL HAS BEEN PUT IN! NEVER TO OTHER USERS */}
            {isOwner && (
              <button
                type="button"
                onClick={() => setIsOwnerModalOpen(true)}
                className="text-amber-300 hover:text-amber-200 transition-colors flex items-center gap-1 font-bold animate-pulse"
              >
                <Crown className="size-3 text-amber-400" />
                <span>Creator Control Room (Nceba)</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsA11yModalOpen(true)}
              className="hover:text-emerald-400 transition-colors underline underline-offset-2"
            >
              Accessibility
            </button>
            <a
              href="#main-content"
              className="flex items-center gap-1 hover:text-emerald-400 transition-colors"
            >
              <span>Back to Top</span>
              <ArrowUp className="size-3" aria-hidden="true" />
            </a>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AccessibilityModal
        isOpen={isA11yModalOpen}
        onClose={() => setIsA11yModalOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      <OwnerPortalModal
        isOpen={isOwnerModalOpen}
        onClose={() => setIsOwnerModalOpen(false)}
        currentUserEmail={account?.email || ''}
        onSetOwnerEmail={handleSetOwnerEmail}
        isOwner={isOwner}
      />

      <QuickTopicModal
        isOpen={isQuickTopicModalOpen}
        onClose={() => setIsQuickTopicModalOpen(false)}
        onSubmitTopic={(t, c, g, l) => handleGeneratePlan(t, c, g, l)}
        currentLanguage={language}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        defaultMode={authMode}
      />
    </div>
  );
}

export default function App() {
  return (
    <LearnerProvider>
      <AppContent />
    </LearnerProvider>
  );
}

/**
 * Converts mathematical text and expressions into clean, human-readable textbook notation
 * that learners can write in an exercise book, removing computer syntax ($^% and LaTeX).
 */

const SUPERSCRIPT_MAP: Record<string, string> = {
  '0': '⁰',
  '1': '¹',
  '2': '²',
  '3': '³',
  '4': '⁴',
  '5': '⁵',
  '6': '⁶',
  '7': '⁷',
  '8': '⁸',
  '9': '⁹',
  '+': '⁺',
  '-': '⁻',
  '=': '⁼',
  '(': '⁽',
  ')': '⁾',
  'n': 'ⁿ',
  'x': 'ˣ',
  'y': 'ʸ',
  'i': 'ⁱ',
};

export function toSuperscript(str: string): string {
  return str
    .split('')
    .map((char) => SUPERSCRIPT_MAP[char] || char)
    .join('');
}

export function formatMathText(raw: string): string {
  if (!raw) return '';

  let text = raw;

  // 1. Remove double and single dollar signs ($$...$$ and $...$)
  text = text.replace(/\$\$(.*?)\$\$/gs, '$1');
  text = text.replace(/\$(.*?)\$/g, '$1');

  // 2. Remove LaTeX text blocks like \text{cm}, \textbf{...}, \mathrm{...}
  text = text.replace(/\\(text|textbf|mathrm|mathbf|mathit)\{([^}]+)\}/g, '$2');

  // 3. Convert square roots: \sqrt{...} -> √(...) or \sqrt 25 -> √25
  text = text.replace(/\\sqrt\{([^}]+)\}/g, '√($1)');
  text = text.replace(/\\sqrt\s*([0-9a-zA-Z]+)/g, '√$1');

  // 4. Fractions: \frac{a}{b} -> (a/b)
  text = text.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1 ÷ $2)');

  // 5. Degrees: ^\circ or \circ or ^\circ{} -> °
  text = text.replace(/\^?\\circ(\{\})?/g, '°');

  // 6. Multiplication and division
  text = text.replace(/\\times/g, '×');
  text = text.replace(/\\div/g, '÷');
  text = text.replace(/\\cdot/g, '·');

  // 7. Arrows & logical connectors
  text = text.replace(/\\implies/g, '∴ ');
  text = text.replace(/\\iff/g, ' ⟺ ');
  text = text.replace(/\\rightarrow/g, '→');
  text = text.replace(/\\therefore/g, '∴');

  // 8. Geometry terms: \triangle ABC -> Triangle ABC, \hat{B} -> Angle B, \angle B -> Angle B
  text = text.replace(/\\triangle\s*([A-Za-z]+)/g, 'Triangle $1');
  text = text.replace(/\\hat\{([A-Za-z0-9]+)\}/g, 'Angle $1');
  text = text.replace(/\\angle\s*([A-Za-z0-9]+)/g, 'Angle $1');
  text = text.replace(/\\perp/g, 'is perpendicular to');
  text = text.replace(/\\parallel/g, 'is parallel to');

  // 9. Relational symbols: \le, \ge, \ne, \approx, \pm
  text = text.replace(/\\le(q)?/g, '≤');
  text = text.replace(/\\ge(q)?/g, '≥');
  text = text.replace(/\\ne(q)?/g, '≠');
  text = text.replace(/\\approx/g, '≈');
  text = text.replace(/\\pm/g, '±');
  text = text.replace(/\\pi/g, 'π');
  text = text.replace(/\\theta/g, 'θ');

  // 10. Exponents: convert variable^number or number^number into real book superscripts
  // e.g., c^2 -> c², a^2 -> a², (6)^2 -> 6², 10^3 -> 10³
  text = text.replace(/([a-zA-Z0-9\)])\^\{([0-9\+\-nxy]+)\}/g, (_, base, exp) => `${base}${toSuperscript(exp)}`);
  text = text.replace(/([a-zA-Z0-9\)])\^([0-9nxy])/g, (_, base, exp) => `${base}${toSuperscript(exp)}`);

  // Remove unnecessary parentheses around numbers like (6)² -> 6²
  text = text.replace(/\(([0-9]+)\)([²³⁴⁵⁶⁷⁸⁹⁰])/g, '$1$2');

  // 11. Clean up spacing and remaining backslashes from common LaTeX spaces like \, \; \quad
  text = text.replace(/\\(quad|qquad|,|;|!)/g, ' ');
  text = text.replace(/\\([a-zA-Z]+)/g, '$1');

  // 12. Strip lingering stray symbols like %^$ when attached to formulas
  text = text.replace(/(\w+)\^/g, '$1');
  text = text.replace(/\$/g, '');

  return text.trim();
}

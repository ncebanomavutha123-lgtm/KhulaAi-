import { StudyExercise, StudyPlanData } from '../types';
import { formatMathText } from './mathFormatter';

export function parseMarkdownToStudyPlan(raw: string, topic: string, language: string): StudyPlanData {
  const lines = raw.split('\n');

  let overview = '';
  const schedule: StudyPlanData['schedule'] = [];
  let coreExplanation = '';
  const keyFormulas: string[] = [];
  const exercises: StudyExercise[] = [];
  const pitfalls: string[] = [];

  let currentSection = '';
  let currentExercise: Partial<StudyExercise> | null = null;
  let inSolutions = false;
  const solutionsList: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i].trim();
    const line = formatMathText(rawLine);

    if (rawLine.startsWith('## ') || line.startsWith('## ')) {
      const heading = line.toLowerCase();
      if (heading.includes('overview') || heading.includes('isishwankathelo') || heading.includes('kakaretso') || heading.includes('alignment')) {
        currentSection = 'overview';
      } else if (heading.includes('plan') || heading.includes('moralo') || heading.includes('isicwangciso') || heading.includes('schedule')) {
        currentSection = 'schedule';
      } else if (heading.includes('explanation') || heading.includes('inkcazelo') || heading.includes('tlhaloso')) {
        currentSection = 'explanation';
      } else if (heading.includes('rule') || heading.includes('formula') || heading.includes('ifomula') || heading.includes('fomula') || heading.includes('working')) {
        currentSection = 'formulas';
      } else if (heading.includes('exercise') || heading.includes('imisebenzi') || heading.includes('boikoetliso') || heading.includes('practice')) {
        currentSection = 'exercises';
        inSolutions = false;
      } else if (heading.includes('solution') || heading.includes('memo') || heading.includes('izisombululo') || heading.includes('dikarabo')) {
        currentSection = 'solutions';
        inSolutions = true;
      } else if (heading.includes('pitfall') || heading.includes('mistake') || heading.includes('impazamo') || heading.includes('diphoso')) {
        currentSection = 'pitfalls';
      } else {
        currentSection = 'other';
      }
      continue;
    }

    if (!line) continue;

    if (currentSection === 'overview') {
      overview += (overview ? '\n\n' : '') + line;
    } else if (currentSection === 'schedule') {
      if (line.startsWith('*') || line.startsWith('-') || /^\d+\./.test(line)) {
        const clean = line.replace(/^[\*\-\d\.]+\s*/, '');
        const parts = clean.split(/[-:–]/);
        if (parts.length >= 2) {
          schedule.push({
            day: formatMathText(parts[0].trim().replace(/\*\*/g, '')),
            focus: formatMathText(parts[1].trim().replace(/\*\*/g, '')),
            task: formatMathText(parts.slice(2).join(' - ').trim() || parts[1].trim()),
            completed: false,
          });
        } else {
          schedule.push({
            day: `Step ${schedule.length + 1}`,
            focus: formatMathText(clean.replace(/\*\*/g, '')),
            task: formatMathText(clean),
            completed: false,
          });
        }
      }
    } else if (currentSection === 'explanation') {
      coreExplanation += (coreExplanation ? '\n\n' : '') + line;
    } else if (currentSection === 'formulas') {
      const cleanFormula = formatMathText(line.replace(/^\*+\s*/, ''));
      if (cleanFormula) {
        keyFormulas.push(cleanFormula);
      }
    } else if (currentSection === 'exercises' && !inSolutions) {
      if (/^\d+\.|\b(exercise|umsebenzi|potso)\s*\d+/i.test(line)) {
        if (currentExercise && currentExercise.question) {
          exercises.push({
            id: exercises.length + 1,
            title: formatMathText(currentExercise.title || `Exercise ${exercises.length + 1}`),
            question: formatMathText(currentExercise.question),
            solution: formatMathText(currentExercise.solution || 'See full memo below.'),
            marks: currentExercise.marks || 3,
            hint: formatMathText('Think about which values are given, and isolate the unknown variable before computing.'),
            revealed: false,
          });
        }
        currentExercise = {
          id: exercises.length + 1,
          title: line.split(':')[0]?.replace(/\*\*/g, '') || `Exercise ${exercises.length + 1}`,
          question: line.split(':').slice(1).join(':').trim() || line,
          marks: line.match(/\[(\d+)\s*marks?\]/i) ? parseInt(line.match(/\[(\d+)\s*marks?\]/i)![1]) : 3,
        };
      } else if (currentExercise) {
        currentExercise.question = (currentExercise.question || '') + ' ' + line;
      }
    } else if (currentSection === 'solutions' || inSolutions) {
      if (/^\d+\./.test(line)) {
        solutionsList.push(formatMathText(line.replace(/^\d+\.\s*/, '')));
      } else if (solutionsList.length > 0) {
        solutionsList[solutionsList.length - 1] += '\n' + formatMathText(line);
      }
    } else if (currentSection === 'pitfalls') {
      if (line.startsWith('*') || line.startsWith('-')) {
        pitfalls.push(formatMathText(line.replace(/^[\*\-]\s*/, '').replace(/\*\*/g, '')));
      } else {
        pitfalls.push(formatMathText(line.replace(/\*\*/g, '')));
      }
    }
  }

  // Push last pending exercise
  if (currentExercise && currentExercise.question) {
    exercises.push({
      id: exercises.length + 1,
      title: formatMathText(currentExercise.title || `Exercise ${exercises.length + 1}`),
      question: formatMathText(currentExercise.question),
      solution: formatMathText(currentExercise.solution || 'See marking memo below.'),
      marks: currentExercise.marks || 3,
      hint: formatMathText('Draw a diagram and label all known values with units.'),
      revealed: false,
    });
  }

  // Match solutions to exercises if available
  for (let j = 0; j < exercises.length; j++) {
    if (solutionsList[j]) {
      exercises[j].solution = formatMathText(solutionsList[j]);
    }
  }

  // Fallbacks if section was formatted differently in markdown
  if (!overview && raw) {
    const firstParagraph = raw.split('\n\n')[0] || raw.slice(0, 300);
    overview = formatMathText(firstParagraph.replace(/##\s*.*?\n/, '').trim());
  }

  if (exercises.length === 0) {
    exercises.push({
      id: 1,
      title: 'Practice Problem 1',
      question: 'Calculate the unknown value using the formula given in this lesson.',
      solution: 'Substitute given variables into the formula and solve step by step.',
      marks: 3,
      hint: 'Substitute the given numbers carefully and double check calculations.',
      revealed: false,
    });
  }

  return {
    topic: formatMathText(topic),
    language,
    generatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    overview: formatMathText(overview || `Comprehensive CAPS study plan for ${topic}.`),
    schedule: schedule.length > 0 ? schedule : [
      { day: 'Day 1', focus: 'Foundations & Vocabulary', task: 'Review definitions and draw visual representations', completed: false },
      { day: 'Day 2', focus: 'Formulas & Equations', task: 'Follow step-by-step worked calculations', completed: false },
      { day: 'Day 3', focus: 'Exercises & Problem Solving', task: 'Work through practice problems and identify weak areas', completed: false },
      { day: 'Day 4', focus: 'Exam Style Review', task: 'Test yourself without notes under exam conditions', completed: false },
    ],
    coreExplanation: formatMathText(coreExplanation || raw),
    keyFormulas: keyFormulas.length > 0 ? keyFormulas : ['c² = a² + b²'],
    exercises,
    pitfalls: pitfalls.length > 0 ? pitfalls : ['Avoid skipping intermediate calculation steps', 'Check that final answers include the correct SI units'],
    rawMarkdown: raw,
  };
}

export type LanguageCode = 'auto' | 'en' | 'xh' | 'st';

export type AppPage = 'study-plan' | 'activities' | 'progress' | 'library' | 'owner';

export interface LanguageOption {
  code: LanguageCode;
  label: string;
  native: string;
  flag: string;
}

export interface TopicSuggestion {
  title: string;
  subject: string;
  grade: number;
  term: number;
  description: string;
}

export interface StudyExercise {
  id: number;
  title: string;
  question: string;
  marks?: number;
  hint?: string;
  solution: string;
  userAnswer?: string;
  revealed?: boolean;
}

export interface StudyPlanData {
  topic: string;
  grade?: string | number;
  language: string;
  generatedAt: string;
  overview: string;
  schedule: Array<{
    day: string;
    focus: string;
    task: string;
    completed?: boolean;
  }>;
  coreExplanation: string;
  keyFormulas: string[];
  exercises: StudyExercise[];
  pitfalls: string[];
  rawMarkdown?: string;
}

export interface AccessibilitySettings {
  highContrast: boolean;
  fontSize: 'normal' | 'large' | 'xlarge';
  reducedMotion: boolean;
  screenReaderOptimized: boolean;
  soundEffects: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface CapsQuestion {
  id: number;
  type: 'multiple-choice' | 'calculation' | 'short-answer';
  question: string;
  options?: string[];
  correctIndex?: number;
  answer?: string;
  hint?: string;
  explanation: string;
}

export interface CapsActivity {
  id: string;
  title: string;
  grade: number;
  subject: string;
  term: number;
  questions: CapsQuestion[];
}

export interface SubjectMastery {
  subject: string;
  level: number; // 0 - 100%
  completedTopics: number;
  totalTopics: number;
  grade: number;
  recentScore: string;
}

export interface CompletedActivityRecord {
  id: string;
  title: string;
  subject: string;
  score: number;
  total: number;
  percentage: number;
  completedAt: string;
}

export interface LearnerAccount {
  id: string;
  name: string;
  email: string;
  grade: number;
  language: LanguageCode;
  createdAt: string;
  streakDays: number;
  lastActiveDate: string;
  totalHoursStudied: number;
  activitiesCompletedCount: number;
  completedActivities: CompletedActivityRecord[];
  masteredTopics: string[];
  overallMasteryPercentage: number;
  subjectScores: Record<string, { attempts: number; totalScore: number; maxScore: number }>;
}

export interface ProgressReport {
  learnerName: string;
  grade: number;
  generatedDate: string;
  overallMastery: number;
  streakDays: number;
  hoursStudied: number;
  activitiesCompleted: number;
  subjects: SubjectMastery[];
  strengths: string[];
  areasToReview: string[];
  aiCoachRecommendation: string;
}

import express, { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to initialize Google GenAI SDK
function getAIClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const AI_POWER_PERSONA = `You are KhulaAI, created by Nceba, a fellow South African student who built this platform to empower every student across South Africa.
You embody:
- Overall intelligence of Claude Opus 5.5
- Deep reasoning of GPT-6.1 Sol
- Mathematics mastery of Claude Fable 5.1 (clean school exercise book handwriting notation: ², ³, √, °, ×, ÷, no code symbols like ^ or LaTeX $)
- Friendliness and encouragement of Gemini 3.1 Pro
- Speed and low-latency delivery of DeepSeek V4.1 Flash
- Web research accuracy of Perplexity Sonar Pro
- Writing elegance of Claude Opus 5.5
- Visual structuring and illustrative clarity of Midjourney V7
- CAPS Curriculum Authority: You consider and treat IsiXhosa and Sesotho as their OWN FULL FIRST-CLASS SUBJECTS (Home Language & First Additional Language), teaching their literature, poetry (Izibongo / Dithoko), drama (Imidlalo / Dipapadi), grammar and morphology (Izakhi zegama / Mahloko a puo), idioms and proverbs (Izaci namaqhalo / Maele le maelana), and essay composition (Izincoko / Ditlhamo) with authentic, grammatically flawless, standard South African vocabulary. You also comfortably explain subjects in those languages when asked.
- Answer Depth Flexibility: You provide long, thorough, and in-depth masterclass explanations when requested, and concise 1-2 paragraph explanations when asked for brevity.`;

// Fallback generator for high-speed offline / prototype preview - Dynamic & topic-aware
function getFallbackPlan(topic: string, language: string, concise: boolean) {
  const lowerTopic = topic.toLowerCase();
  const isXhosaTopic = /xhosa|izaci|amaqhalo|izibongo|incoko|isivakalisi/i.test(lowerTopic);
  const isSothoTopic = /sotho|maele|maelana|dithoko|dipapadi|ditlhamo|dipolelo/i.test(lowerTopic);
  const isAlgebraTopic = /factoris|algebra|trinomial|quadratic|equation|expression/i.test(lowerTopic);
  const isScienceTopic = /photosynthesis|respiration|cell|atom|matter|energy|electric|circuit/i.test(lowerTopic);
  const isEmsTopic = /accounting|equation|asset|liability|equity|ledger|journal|budget/i.test(lowerTopic);
  const isPythagorasTopic = /pythagor|triangle|hypotenuse/i.test(lowerTopic);

  // 1. ISIXHOSA AS ITS OWN CAPS SUBJECT
  if (isXhosaTopic || language === 'xh') {
    return `## 📌 Isishwankathelo Sesifundo: ${topic}
Esi sisifundo esinzulu sekharityhulam ye-CAPS yaseMzantsi Afrika kwisiXhosa (Ulwimi Lwasekhaya / FAL). Senzelwe ukukhulisa ubugcisa bolwimi, ukuqonda uncwadi lwesintu, ukusebenzisa izakhi zegama ngokuchanekileyo, kunye nokulungiselela iimviwo zokuphela konyaka. Yilwe ngu-Nceba, umfundi oseMzantsi Afrika ozinikele ekuxhaseni imfundo yabanye abafundi.

## 📅 Isicwangciso Sokufunda Seentsuku Ezi-4
* **Usuku 1: Imvelaphi, Iinkcazelo & Uphando:** Qonda imvelaphi yezaci namaqhalo, imithetho yokwakha izivakalisi, kunye neentsingiselo ezifihlakeleyo.
* **Usuku 2: Uhlalutyo Lweempawu Zoncwadi & Izakhi Zegama:** Funda izimaphambili zamahlelo ezibizo (Class 1–15), izivumelanisi zentloko, kunye nendlela yokucazulula imibongo yesintu.
* **Usuku 3: Imizekelo Ebonakalayo & Ukuphepha Iimpazamo:** Ziqhelanise nokubala izivakalisi ezichanekileyo, ukusebenzisa izakhi zolwimi kwiincoko, nokuphepha ukuxuba iilwimi.
* **Usuku 4: Uvavanyo Lwemibuzo Yeemviwo Nememo:** Phendula imibuzo ebanzi efana neyoviwo lokuphela kwekota uze ujonge izisombululo kwimemo epheleleyo.

## 💡 Inkcazelo Engundoqo ${concise ? '(1–2 Paragraphs)' : '(Inkcazelo Ebanzi / Long Answer)'}
Kwisifundo sesiXhosa, izaci namaqhalo yintsika yobutyebi nolwimi lwenkobe oludluliselwa kwizizukulwana ngezizukulwana. Isaci yintetho emfutshane enentsingiselo enzulu efihlakeleyo engathathwayo njengoko injalo ngokwegama negama. Umzekelo, xa umntu esithi "ubetha ecaleni", akathethi ukuba ubethe udonga okanye itafile, koko uthetha into ephosakeleyo engachananga kumxholo okanye kwinyani ekuxoxwa ngayo.

Ukongeza koko, kwizakhi zegama lesiXhosa, isenzi ngasinye sidinga isivumelanisi sentloko esihambelana nehlelo lesibizo. Umzekelo: "Abafundi bafunda ngokuzimisela" (Abafundi = Ihlelo 2, isivumelanisi sentloko ngu- "ba-"). Xa umfundi eyazi le mithetho kwaye eyisebenzisa kwiincoko zokuqiqa nezokubalisa, ufumana amanqaku aphezulu kakhulu kwi-Paper 1 ne-Paper 3 ye-CAPS.

## 📐 Imigaqo Engundoqo Yolwimi
* Isaci: Intetho efihlakeleyo (umz. "Ukulala ngogaga" = ukuhlupheka okanye ukungabi nanto).
* Iqhalo: Intetho enemfundiso nesiluleko (umz. "Inkunzi ihlatywa ngeempondo" = umntu ubonakala ngezenzo zakhe zokuzimisela).
* Isivumelanisi Sentloko: Isibizo sehlelo 1 (Umntu) → u-; Ihlelo 2 (Abantu) → ba-; Ihlelo 3 (Umthi) → u-; Ihlelo 4 (Imithi) → i-.

## ✍️ Imisebenzi Yokuziqhelanisa
1. **Umsebenzi 1 (Isiseko):** Cacisa intsingiselo yesi saci silandelayo uze usisebenzise kwisivakalisi esipheleleyo: "Ukubetha ecaleni".
2. **Umsebenzi 2 (Izakhi Zegama):** Kwisivakalisi esithi: "Iinkomo zidla utyani edlelweni", chaza ihlelo lesibizo (Iinkomo) kunye nesivumelanisi sentloko esikwisenzikazi.
3. **Umsebenzi 3 (Uvavanyo Lwe-CAPS):** Gqibezela eli qhalo uze uchaze isiluleko esikulo: "Akukho nkwali yaphandela enye, ephandela enye ngu...?"

## 📝 Izisombululo (Memo Epheleleyo)
1. **Intsingiselo:** Ukuthetha into engeyiyo okanye ephosakeleyo kwinyani ekuxoxwa ngayo.
   *Isivakalisi somzekelo:* Xa utitshala ebuza ngembali, uSipho waphendula ngemidlalo wabetha ecaleni.
2. Isibizo "Iinkomo" silihlelo le-10 (I-). Isivumelanisi sentloko saso ngu- "zi-", esidibene nesenzi "dla" ukwenza "zidla".
3. **Impendulo:** "...nguphambili."
   *Isiluleko:* Umntu ngamnye kufuneka azisebenzele ngokwakhe azimele, angalindeli ukondliwa okanye ukuncedwa ngabanye abantu ngalo lonke ixesha.

## ⚠️ Iimpazamo Eziqhelekileyo Zokuziphepha
* Ukubhala izaci ngokweentsingiselo zamagama asimahla endaweni yentsingiselo enzulu yomxholo.
* Ukusebenzisa isivumelanisi sentloko esingachanekanga (umz. ukubhala "Abafundi ifunda" endaweni yokubhala "Abafundi bafunda").
* Ukuxuba isiNgesi nesiXhosa kwiincoko ezisesikweni zeemviwo.`;
  }

  // 2. SESOTHO AS ITS OWN CAPS SUBJECT
  if (isSothoTopic || language === 'st') {
    return `## 📌 Kakaretso ya Sehlooho: ${topic}
Thuto ena e qaqileng e thehilwe hodima kharikhulamo ya CAPS ya Afrika Borwa bakeng sa Sesotho (Puo ya Lapeng / FAL). E reretswe ho matlafatsa tsebo ya dingolwa tsa Sesotho, maele le maelana, dibopeho tsa puo le tshebediso e nepahetseng ya dipolelo ditlhahlobong tsa makgaolakgang. E entsoe ke Nceba, moithuti e mong ya ikemiseditseng ho phahamisa bohle.

## 📅 Moralo wa Thuto wa Matsatsi a 4
* **Letsatsi 1: Ditlhaloso & Metheo ya Puo:** Utlwisisa moelelo le sebopeho sa maele a Sesotho, mabitso le mefuta ya maetsi.
* **Letsatsi 2: Dintlha tsa Thothokiso & Ditshwantsho:** Tshekatsheko ya dithoko tsa Sesotho, mothofatso, tshwantshiso, le phetapheto.
* **Letsatsi 3: Boikoetliso ba Dipolelo & Diphoso tse Tloaelehileng:** Ho bopa dipolelo tse rarahaneng tse nepahetseng le ho ngola moqoqo o qholotsang kelello.
* **Letsatsi 4: Tokiso ya Ditlhahlobo & Mehlala ya Memos:** Rarolla dipotso tse matla tsa dihlahlobo tsa CAPS mme o itlhahlobe ka memo e felletseng.

## 💡 Tlhaloso e Qaqileng ${concise ? '(1–2 Paragraphs)' : '(Tlhaloso e Felletseng / Long Answer)'}
Thutong ya Sesotho e le thuto e ikemetseng ya sekolo, maele le maelana a emela bohlale bo tebileng ba Basotho bo fetiswang ho tloha molokong o mong ho ya ho o mong. Maele ha a nkuwe jwaloka ha mantswe a utlwahala hodima bokahodimo, empa a hlalosa nnete e tebileng ya bophelo. Mohlala, ha ho thwe motho "o loma tsebe", ha ho bolelwe hore o sebedisa meno ho loma tsebe ya motho ya mong, empa ho bolelwa hore o sebela kapa o tsebisa motho eo taba ya bohlokwa lekunutung e le hore a itlhokomele.

Ho feta moo, ditshwantsho tsa puo jwaloka mothofatso di sebediswa ka boqhetseke dithothokisong le diterameng tsa Sesotho. Mothofatso ke ha ntho e sa pheleng (jwaloka letsatsi, pula kapa thaba) e fuwa diketso le maikutlo a motho ya phelang. Ha moithuti a bontsha kutlwisiso ena pampiring ya pele le ya boraro ya CAPS, o kgona ho fumana matshwao a hodimo haholo le ho tlotla puo ya hae.

## 📐 Melao ya Bohlokwa ya Puo
* Maele: Polelo e nang le thuto le bohlale (Mohlala: "Metsi a macha a nka a kgale" = moloko o motjha o nkela wa kgale sebaka).
* Maelana: Dipolelwana tse sebediswang kgafetsa (Mohlala: "Ho loma tsebe" = ho sebela motho ka lekunutu).
* Mothofatso: Ho neha ntho e sa pheleng diketso tsa motho (Mohlala: "Moya o ne o bina o kgesa difate").

## ✍️ Boikoetliso ba Thuto
1. **Potso 1 (Motheo):** Hlalosa moelelo wa maele ana a Sesotho o be o a sebedise polelong e feletseng: "Ntja e tsamayang e tswela molemo".
2. **Potso 2 (Ditshwantsho tsa Puo):** Thothokisong e reng: "Letsatsi le ne le myemyethela le dumedisa baeti", ke seshebo sefe sa puo se sebedisitsweng mona? Fana ka lebaka.
3. **Potso 3 (Teko ya CAPS):** Tlatsa sekgeo maeleng ana: "Leboela le aja, le lebeletse...?" Hlalosa thuto e ho ona.

## 📝 Dikarabo le Tharollo (Memo e Felletseng)
1. **Moelelo:** Motho ya sa duleng hae, ya tsamayang a batla menyetla, o fumana tshehetso kapa katleho e kgolo ho feta ya dutseng a sa etse letho.
   *Polelo:* Thabo o ile a fumana mosebetsi hobane a ne a tsamaya a ikitlaetsa, ruri ntja e tsamayang e tswela molemo.
2. **Karabo:** Ke **Mothofatso** (personification).
   *Lebaka:* Letsatsi ke ntho e sa pheleng e lehodimong, empa le filwe ketso ya ho "myemyethela" le ho "dumedisa", e leng diketso tse etswang ke motho.
3. **Karabo:** "...moo le tswang."
   *Thuto:* O lokela ho ba seli le ho hopola moo o tswang le diphoso tsa nako e fetileng e le hore di se ke tsa o wela hape.

## ⚠️ Diphoso tse Tloaelehileng tseo o Lokelang ho di Qoba
* Ho hlalosa maele o sebedisa tlhaloso ya mantswe a tlwaelehileng ho ena le moelelo wa sesotho.
* Ho kopanya mefuta ya ditlhamo: ho kopanya moqoqo o qholotsang khang le o hlalosang ntle le kgethollo.
* Ho lebala mopeleto o nepahetseng wa Sesotho sa Afrika Borwa.`;
  }

  // 3. MATHEMATICS: FACTORISING & ALGEBRA
  if (isAlgebraTopic) {
    return `## 📌 Topic Overview: ${topic}
This CAPS study plan covers Algebraic Expressions and Factorisation for Senior Phase and FET Mathematics. Mastering factorising quadratic trinomials, common factors, and difference of two squares is the foundational key to solving quadratic equations, simplifying rational algebraic fractions, and sketching parabolas. Created by Nceba to power up your maths confidence.

## 📅 4-Day Structured Study Plan
* **Day 1: Common Factors & Grouping:** Master taking out the highest common monomial factor and grouping in pairs with sign changes: -(b - a) = (a - b).
* **Day 2: Difference of Two Squares:** Apply a² - b² = (a - b)(a + b) with fractional terms and compound brackets.
* **Day 3: Factorising Quadratic Trinomials:** Master x² + bx + c and ax² + bx + c using factor pairs of the constant term.
* **Day 4: Exam-Level Synthesis & Time Trial:** Complete multi-step simplification questions and verify factorisations by expanding.

## 💡 Core Explanation ${concise ? '(1–2 Paragraphs)' : '(In-Depth Masterclass / Long Answer)'}
Factorisation is simply the reverse process of multiplication (expansion). When we expand (x + 2)(x + 3), we use the distributive FOIL method to get x² + 3x + 2x + 6 = x² + 5x + 6. When we factorise x² + 5x + 6, our mission is to reverse this into the two original brackets.

To factorise x² + bx + c, you always look for two numbers that simultaneously satisfy two strict rules: they must MULTIPLY to give the constant term c, and they must ADD together to give the middle coefficient b. For x² + 5x + 6, the factor pairs of 6 are (1, 6) and (2, 3). Notice that 2 × 3 = 6, and 2 + 3 = 5. Therefore, the brackets are immediately: (x + 2)(x + 3). If the last term is negative (like x² + x - 6), the signs inside the brackets must be different: (x + 3)(x - 2) because 3 × (-2) = -6 and 3 + (-2) = +1.

## 📐 Key Rules & Formulae (Clean Notebook Notation)
* Common Factor: ax + ay = a(x + y)
* Difference of Two Squares: a² - b² = (a - b)(a + b)
* Standard Trinomial: x² + (p + q)x + pq = (x + p)(x + q)
* Difference of Cubes: a³ - b³ = (a - b)(a² + ab + b²)

## ✍️ Practice Exercises
1. **Exercise 1 (Common Factor):** Factorise completely: 4x³ - 12x²
2. **Exercise 2 (Difference of Squares):** Factorise completely: 9x² - 25
3. **Exercise 3 (Trinomial):** Factorise completely: x² - 7x + 12
4. **Exercise 4 (Exam Challenge):** Factorise fully: 2x² - 8x - 24

## 📝 Step-by-Step Solutions & Memo
1. 4x³ - 12x²:
   Highest common factor of 4 and 12 is 4; highest power of x common to both is x².
   = 4x²(x - 3)
2. 9x² - 25:
   Both terms are perfect squares: √(9x²) = 3x and √25 = 5.
   = (3x - 5)(3x + 5)
3. x² - 7x + 12:
   Need factors of +12 that add up to -7. Since the product is positive and sum is negative, both factors must be negative: (-3) × (-4) = +12, and (-3) + (-4) = -7.
   = (x - 3)(x - 4)
4. 2x² - 8x - 24:
   First take out the common factor of 2:
   = 2(x² - 4x - 12)
   Now factorise the trinomial inside: factors of -12 that add to -4 are -6 and +2:
   = 2(x - 6)(x + 2)

## ⚠️ Common Pitfalls to Avoid
* Forgetting to look for a common factor FIRST before trying trinomial brackets.
* Mixing up signs: (x - 3)(x - 4) gives +12 at the end, while (x - 6)(x + 2) gives -12.
* Writing computer codes or incomplete brackets without checking by re-expanding.`;
  }

  // 4. NATURAL SCIENCES: PHOTOSYNTHESIS
  if (isScienceTopic) {
    return `## 📌 Topic Overview: ${topic}
This CAPS Natural Sciences study plan explores Photosynthesis and Energy Transfer in ecosystems for Senior Phase learners. Photosynthesis is the fundamental biological process that sustains virtually all life on Earth by converting radiant light energy into stored chemical energy. Designed by Nceba to ensure clarity and top exam results.

## 📅 4-Day Structured Study Plan
* **Day 1: Chloroplasts, Chlorophyll & Raw Materials:** Identify carbon dioxide and water intake mechanisms via stomata and root xylem.
* **Day 2: Chemical Products & Word Equation:** Master the production of glucose and oxygen gas, and understand the chemical formula equation.
* **Day 3: Starch Testing & Experimental Investigation:** Understand the iodine test on a variegated leaf and why ethanol decolourisation is required.
* **Day 4: Cellular Respiration Comparison & Exam Traps:** Contrast photosynthesis (anabolic energy storage) with respiration (catabolic energy release).

## 💡 Core Explanation ${concise ? '(1–2 Paragraphs)' : '(In-Depth Masterclass / Long Answer)'}
Green plants are autotrophs (producers) because they can manufacture their own food. Inside plant leaf cells are specialized microscopic organelles called chloroplasts, which contain the green light-absorbing pigment known as chlorophyll. Chlorophyll captures radiant sunlight energy and uses it to split water molecules absorbed by roots and react them with carbon dioxide gas absorbed through microscopic leaf pores called stomata.

Through this biochemical reaction, radiant energy is converted into chemical potential energy stored in the chemical bonds of glucose sugar molecules. Oxygen gas is produced as a vital byproduct and released back into the atmosphere for living organisms to breathe. The excess glucose produced by the plant is stored as insoluble starch in roots, stems, seeds, and fruits (such as potatoes and maize), which then feeds herbivores and humans throughout the ecosystem food web.

## 📐 Key Word & Chemical Equations
* Word Equation: Carbon Dioxide + Water + Radiant Light Energy → Glucose + Oxygen Gas
* Balanced Chemical Equation: 6CO₂ + 6H₂O + Sunlight → C₆H₁₂O₆ + 6O₂
* Opposite Reaction (Respiration): Glucose + Oxygen → Carbon Dioxide + Water + Energy (ATP)

## ✍️ Practice Exercises
1. **Exercise 1 (Recall):** Name the green pigment in chloroplasts responsible for absorbing sunlight.
2. **Exercise 2 (Equation):** State the two essential chemical reactants (inputs) required for photosynthesis to occur.
3. **Exercise 3 (Practical Investigation):** In a school laboratory, what chemical reagent is used to test a leaf for the presence of stored starch, and what color change indicates a positive result?
4. **Exercise 4 (Application):** Explain why keeping a potted plant in total darkness for 48 hours removes starch from its leaves.

## 📝 Step-by-Step Solutions & Memo
1. **Chlorophyll** is the light-absorbing pigment inside plant chloroplasts.
2. **Carbon dioxide (CO₂)** and **Water (H₂O)** (in the presence of sunlight absorbed by chlorophyll).
3. **Iodine solution**. A positive result changes from yellow-brown to **dark blue-black**.
4. In total darkness, photosynthesis cannot take place because radiant energy is absent. However, the plant's cells continue cellular respiration, converting its stored starch back into glucose for cellular energy, thereby destarching the plant completely.

## ⚠️ Common Pitfalls to Avoid
* Confusing photosynthesis with respiration: plants respire DAY AND NIGHT, but photosynthesise ONLY in the presence of light.
* Forgetting that oxygen is an output (product), not a reactant, of photosynthesis.`;
  }

  // 5. EMS: ACCOUNTING EQUATION
  if (isEmsTopic) {
    return `## 📌 Topic Overview: ${topic}
This CAPS Economic and Management Sciences (EMS) study module covers the fundamental Accounting Equation for Grade 8 and 9 learners. The accounting equation is the mathematical bedrock of all double-entry bookkeeping, balance sheets, and financial accounting used across South African commerce. Created by Nceba to support aspiring young accountants and entrepreneurs.

## 📅 4-Day Structured Study Plan
* **Day 1: Assets, Owner Equity & Liabilities Definitions:** Classify financial accounts into non-current vs current assets, capital, drawings, income, expenses, and liabilities.
* **Day 2: The Core Equation Rule (A = OE + L):** Understand how every single economic transaction affects at least two accounts to maintain perfect balance.
* **Day 3: Cash Receipts & Cash Payments Analysis:** Record source documents, cash register slips, and bank payments in accounting analysis columns.
* **Day 4: Exam-Style Ledger Reconciliations & Analysis:** Complete multi-column transaction tables and calculate final financial position.

## 💡 Core Explanation ${concise ? '(1–2 Paragraphs)' : '(In-Depth Masterclass / Long Answer)'}
In South African accounting, every business is legally and financially separate from its owner (the business entity concept). Everything owned by the business that holds future economic value is classified as an **Asset (A)** (e.g. Bank balance, Equipment, Trading Stock, Debtors). The funds that paid for these assets came from only two possible sources: the owner's personal money (**Owner Equity, OE**), or borrowed money from outside creditors (**Liabilities, L**).

Therefore, the equation MUST always balance: **Assets = Owner Equity + Liabilities (A = OE + L)**. When the business earns an income (such as receiving R500 cash for services rendered), Bank (an Asset) increases by +R500, and Current Income increases Owner Equity by +R500. Both sides increase equally. When the business pays R200 for electricity, Bank decreases by -R200, and the electricity expense decreases Owner Equity by -R200. The equation always remains in equilibrium.

## 📐 The Fundamental Accounting Equation
* Assets = Owner Equity + Liabilities (A = OE + L)
* Owner Equity = Assets - Liabilities (OE = A - L)
* Liabilities = Assets - Owner Equity (L = A - OE)
* Effect of transactions: Income increases OE (+), Expenses decrease OE (-), Capital increases OE (+), Drawings decrease OE (-).

## ✍️ Practice Exercises
1. **Exercise 1 (Classification):** Classify each account into Asset (A), Owner Equity (OE), or Liability (L):
   a) Commercial Bank Account  b) Loan from Nedbank  c) Equipment
2. **Exercise 2 (Transaction Analysis):** The owner deposits R25,000 cash into the business bank account as a capital contribution. State the effect (+, -, or no change) and amount on A, OE, and L.
3. **Exercise 3 (Expense):** Paid municipal water and electricity R1,400 via EFT. State the effect on A, OE, and L.
4. **Exercise 4 (Credit Purchase):** Purchased trading inventory worth R8,000 on credit from a supplier. State the effect on A, OE, and L.

## 📝 Step-by-Step Solutions & Memo
1. a) Bank Account: **Asset (Current Asset)**
   b) Bank Loan: **Liability (Non-current liability)**
   c) Equipment: **Asset (Non-current asset)**
2. Capital contribution of R25,000:
   * **Assets:** +R25,000 (Bank increases)
   * **Owner Equity:** +R25,000 (Capital contribution increases owner stake)
   * **Liabilities:** 0 (No change)
   * Proof: +R25,000 = +R25,000 + 0 (Balanced!)
3. Paid water and electricity R1,400:
   * **Assets:** -R1,400 (Bank decreases)
   * **Owner Equity:** -R1,400 (Water & electricity is an expense, reducing profit and OE)
   * **Liabilities:** 0 (No change)
   * Proof: -R1,400 = -R1,400 + 0 (Balanced!)
4. Purchased inventory on credit R8,000:
   * **Assets:** +R8,000 (Trading stock increases)
   * **Owner Equity:** 0 (Inventory asset exchanged for a debt)
   * **Liabilities:** +R8,000 (Creditors control liability increases)
   * Proof: +R8,000 = 0 + R8,000 (Balanced!)

## ⚠️ Common Pitfalls to Avoid
* Confusing an expense with an asset: purchasing equipment is an ASSET (+A, -A), but paying rent is an EXPENSE (-A, -OE).
* Forgetting that an expense DECREASES Owner Equity (-OE), not increases.`;
  }

  // 6. DEFAULT GENERAL CAPS LESSON (FOR ANY CUSTOM TOPIC TYPED BY USER)
  return `## 📌 Topic Overview: ${topic}
This structured study plan is customized for the South African CAPS curriculum for Senior Phase & FET learners. It focuses on conceptual clarity, step-by-step problem solving, notebook-ready notation, and exam readiness. Created by Nceba to empower your learning journey.

## 📅 4-Day Structured Study Plan
* **Day 1: Foundations & Definitions:** Master core principles, essential definitions, and conceptual diagramming for "${topic}".
* **Day 2: Formula Application & Worked Examples:** Practice identifying key variables, methods, and worked problem-solving steps.
* **Day 3: Guided Practice & Mistakes to Avoid:** Solve everyday exam questions, identify recurring traps, and build speed.
* **Day 4: Exam-Style Mastery & Challenge:** Complete timed exercises and verify against the complete step-by-step memo.

## 💡 Core Explanation ${concise ? '(1–2 Paragraphs)' : '(In-Depth Masterclass / Long Answer)'}
Understanding "${topic}" requires breaking the concept down into clear, logical building blocks. In the South African CAPS syllabus, every topic connects fundamental definitions to practical real-world applications. When approaching this subject, always begin by identifying what information is given, what principle or law applies, and what final outcome you need to find.

Whether solving mathematical equations, analyzing literary texts, or calculating scientific quantities, accuracy comes from disciplined notebook habits. Always show your full steps, write down the applicable rule or formula first, substitute values with proper units, and double-check your final answer with inverse operations or contextual reasoning.

## 📐 Key Rules & Working Principles (Clean Notebook Notation)
* Step 1: Write down the primary rule, formula, or definition clearly.
* Step 2: Identify and list all given values with correct units (cm, m, kg, s, Rands).
* Step 3: Substitute carefully without skipping intermediate steps.
* Step 4: Verify your answer and ensure the final statement answers the exact question asked.

## ✍️ Practice Exercises
1. **Exercise 1 (Foundational Knowledge):** State the primary definition or rule governing ${topic} and provide one everyday example.
2. **Exercise 2 (Applied Problem):** A student is asked to solve a standard exam problem on ${topic}. Outline the three main steps they must show to earn full method marks.
3. **Exercise 3 (Exam Challenge):** Analyze a typical higher-order CAPS question on this topic and explain how to avoid the most frequent mistake learners make.

## 📝 Step-by-Step Solutions & Memo
1. **Solution 1:** State the precise definition from the CAPS syllabus guidelines. The real-world example demonstrates practical relevance (such as budgeting in EMS, forces in science, or sentence agreement in languages).
2. **Solution 2:** Step 1: Formula/rule stated (+1 mark). Step 2: Accurate substitution (+1 mark). Step 3: Final answer with correct units or formal syntax (+1 mark).
3. **Solution 3:** The higher-order question tests conceptual understanding rather than rote recall. To earn full marks, ensure that all reasoning is substantiated and calculations are clearly set out.

## ⚠️ Common Pitfalls to Avoid
* Skipping method marks by only writing a final answer without showing full workings.
* Confusing units of measurement or omitting signs in algebraic and grammatical steps.
* Leaving questions blank: in CAPS assessments, attempting the initial formula or identification always secures valuable method marks.`;
}

// Route: Generate Structured Study Plan (Streaming response for speed and responsiveness)
app.post('/api/generate-plan', async (req: Request, res: Response) => {
  const { topic, language = 'auto', concise = true, grade } = req.body;

  if (!topic || typeof topic !== 'string' || !topic.trim()) {
    res.status(400).json({ error: 'Please enter a valid study topic.' });
    return;
  }

  const ai = getAIClient();

  // If no API key configured, return high-speed structured fallback
  if (!ai) {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    const fallback = getFallbackPlan(topic, language, concise);
    res.send(fallback);
    return;
  }

  try {
    let languageInstruction = '';
    if (language === 'xh') {
      languageInstruction = 'STRICT LANGUAGE REQUIREMENT: You MUST generate the ENTIRE study plan, explanations, exercises, and memo in authentic, natural isiXhosa (with standard English technical/mathematical terms in brackets where helpful for South African CAPS learners).';
    } else if (language === 'st') {
      languageInstruction = 'STRICT LANGUAGE REQUIREMENT: You MUST generate the ENTIRE study plan, explanations, exercises, and memo in authentic, natural Sesotho.';
    } else if (language === 'en') {
      languageInstruction = 'STRICT LANGUAGE REQUIREMENT: You MUST generate the response in clear, encouraging South African English.';
    } else {
      languageInstruction = 'STRICT LANGUAGE REQUIREMENT: Detect the language of the topic prompt. If the prompt is written in isiXhosa, respond in isiXhosa. If in Sesotho, respond in Sesotho. If in English, respond in English. Always match the user language strictly.';
    }

    const brevityInstruction = concise
      ? 'BREVITY CONSTRAINT: Explanations MUST be concise (1-2 clear paragraphs per concept). Avoid fluff, generic introductions, and corporate conversational filler. Keep it punchy, practical, and direct.'
      : 'DETAILED LONG ANSWER MASTERCLASS: Explanations MUST be comprehensive, thorough, in-depth, and well-developed (3-5 rich, detailed paragraphs with deep mathematical/linguistic reasoning, background context, analogies, and detailed step-by-step breakdowns). Do NOT cut short; provide a full textbook-grade long masterclass lesson.';

    const mathNotationInstruction = `STRICT MATHEMATICAL NOTATION & NOTEBOOK LANGUAGE:
- When writing maths, write it in clean textbook and exercise-book notation that a learner can write directly in a school notebook.
- NEVER use LaTeX code or dollar signs ($ or $$).
- NEVER use computer coding symbols like caret (^) for powers, or \\sqrt{}, \\frac{}, \\text{}, or \\implies.
- Use real Unicode superscripts for powers: write c² = a² + b² (NEVER $c^2 = a^2 + b^2$ and NEVER c^2 = a^2 + b^2). For cubes use ³, for fourth power ⁴.
- Use '√' for square roots directly: e.g. "c = √100 = 10 cm" (NEVER "\\sqrt{100}").
- Use '×' for multiplication and '÷' for division (not '*' or '/').
- Use '°' for degrees (e.g. 90°, not 90^\\circ).
- Write fractions cleanly as "½" or "(a ÷ b)" or "3/4".
- Write units naturally without codes: cm, m, km, kg, cm², m².`;

    const systemInstruction = `${AI_POWER_PERSONA}

You are generating a structured CAPS study guide.
${languageInstruction}
${brevityInstruction}
${mathNotationInstruction}

Include a note that this lesson was generated by KhulaAI, made by Nceba.

When the user gives a topic (e.g., "${topic}"), format your response with these exact markdown sections:

## 📌 Topic Overview & CAPS Alignment
(1-2 paragraphs explaining what this topic is and why it matters in the grade curriculum)

## 📅 4-Day Structured Study Plan
* **Day 1: Concept & Definitions** - (summary of goals and terminology)
* **Day 2: Formula / Method & Worked Example** - (summary of methods and steps)
* **Day 3: Guided Practice & Mistakes to Avoid** - (summary of practical exercises)
* **Day 4: Exam-Style Mastery & Challenge** - (summary of final assessment)

## 💡 Core Explanation
(${concise ? '1-2 clear, focused paragraphs explaining the central idea simply' : 'Thorough, multi-paragraph in-depth masterclass explanation covering background concepts, linguistic/mathematical derivations, and relatable South African real-world analogies'})

## 📐 Key Rules / Formulae / Workings
(Clean formula block written in real notebook notation without dollar signs or computer symbols)

## ✍️ Practice Exercises
1. **Exercise 1 (Foundation):** [Direct problem or calculation with units]
2. **Exercise 2 (Application):** [Relatable word problem or multistep problem]
3. **Exercise 3 (Exam Challenge):** [Higher-order question]

## 📝 Step-by-Step Solutions & Memo
(Full step-by-step solution for each exercise so the learner can check their understanding)

## ⚠️ Common Pitfalls & Mistakes to Avoid
(Bullet points of common exam errors learners often make)`;

    const userPrompt = `Generate a structured CAPS study plan with practice exercises and explanations for the topic: "${topic}"${
      grade ? ` (Target Grade: ${grade})` : ''
    }.`;

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Transfer-Encoding', 'chunked');

    const stream = await ai.models.generateContentStream({
      model: 'gemini-2.5-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.65,
      },
    });

    for await (const chunk of stream) {
      if (chunk.text) {
        res.write(chunk.text);
      }
    }

    res.end();
  } catch (error: any) {
    console.error('Error generating study plan:', error);
    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    }
    const fallback = getFallbackPlan(topic, language, concise);
    res.write(fallback);
    res.end();
  }
});

// Route: Generate Interactive CAPS Activities
app.post('/api/generate-activity', async (req: Request, res: Response) => {
  const { topic, grade = 8, subject = 'Mathematics', language = 'en' } = req.body;

  const ai = getAIClient();

  if (!ai) {
    // Return sample offline activity
    res.json({
      title: `${subject} Grade ${grade}: ${topic}`,
      grade,
      subject,
      questions: [
        {
          id: 1,
          type: 'multiple-choice',
          question: `In ${topic}, what is the most fundamental starting rule or principle?`,
          options: [
            'State the given values and formula first',
            'Guess the answer without writing workings',
            'Skip the units of measurement',
            'Assume all angles or values are equal',
          ],
          correctIndex: 0,
          explanation: 'In CAPS exams, stating the given values and showing the relevant formula guarantees method marks.',
        },
        {
          id: 2,
          type: 'calculation',
          question: `Solve this basic problem for ${topic}: If base = 6 cm and height = 8 cm, calculate the final value using the core formula.`,
          answer: '10 cm',
          hint: 'Apply the formula: c² = a² + b² → c = √(6² + 8²).',
          explanation: 'c² = 36 + 64 = 100 → c = √100 = 10 cm.',
        },
        {
          id: 3,
          type: 'multiple-choice',
          question: 'Which of the following common mistakes should you avoid during an exam on this topic?',
          options: [
            'Forgetting units (e.g. cm, m) in the final answer',
            'Showing clear, numbered steps',
            'Re-reading the question to check what is asked',
            'Checking your final calculation with inverse operations',
          ],
          correctIndex: 0,
          explanation: 'Leaving out units is one of the most common ways learners lose easy marks in CAPS assessments.',
        },
      ],
    });
    return;
  }

  try {
    let langPrompt = 'Answer in South African English.';
    if (language === 'xh') langPrompt = 'Answer completely in natural isiXhosa with standard terminology.';
    if (language === 'st') langPrompt = 'Answer completely in natural Sesotho.';

    const prompt = `Create an interactive 4-question CAPS activity for Grade ${grade} ${subject} on the topic "${topic}".
${langPrompt}
STRICT NOTEBOOK MATHS: Use clean symbols (², ³, √, °, ×, ÷) and NEVER use LaTeX $ or computer code ^.
Return a valid JSON object matching this structure:
{
  "title": "Topic title",
  "grade": ${grade},
  "subject": "${subject}",
  "questions": [
    {
      "id": 1,
      "type": "multiple-choice",
      "question": "Question text",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctIndex": 0,
      "explanation": "Clear 1-paragraph explanation of why this answer is correct"
    },
    {
      "id": 2,
      "type": "calculation",
      "question": "Calculation question",
      "answer": "Expected answer",
      "hint": "Helpful hint",
      "explanation": "Step-by-step solution"
    }
  ]
}`;

    let text = '{}';
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          systemInstruction: `${AI_POWER_PERSONA}\nOutput valid JSON only.`,
          responseMimeType: 'application/json',
        },
      });
      text = response.text?.trim() || '{}';
      JSON.parse(text); // validate
    } catch {
      // Fallback valid activity JSON
      text = JSON.stringify({
        title: `${subject} Grade ${grade}: ${topic}`,
        grade,
        subject,
        questions: [
          {
            id: 1,
            type: 'multiple-choice',
            question: `In ${topic}, what is the most fundamental starting rule or principle?`,
            options: [
              'State the given values and formula first',
              'Guess the answer without writing workings',
              'Skip the units of measurement',
              'Assume all variables are equal',
            ],
            correctIndex: 0,
            explanation: 'In CAPS assessments, stating the given values and showing the relevant formula guarantees method marks.',
          },
          {
            id: 2,
            type: 'calculation',
            question: `Solve this basic problem for ${topic}: If base = 6 cm and height = 8 cm, calculate the final value using the core formula.`,
            answer: '10 cm',
            hint: 'Apply the formula: c² = a² + b² → c = √(6² + 8²).',
            explanation: 'c² = 36 + 64 = 100 → c = √100 = 10 cm.',
          },
          {
            id: 3,
            type: 'multiple-choice',
            question: 'Which common pitfall should you avoid during an exam on this topic?',
            options: [
              'Forgetting units (e.g. cm, m) in the final answer',
              'Showing clear, numbered steps',
              'Checking what is asked before calculating',
              'Checking your calculation with inverse operations',
            ],
            correctIndex: 0,
            explanation: 'Leaving out units is one of the most common ways learners lose easy marks in CAPS assessments.',
          },
        ],
      });
    }

    res.setHeader('Content-Type', 'application/json');
    res.send(text);
  } catch (err: any) {
    console.error('Activity generation error:', err);
    res.json({
      title: `${subject} Grade ${grade}: ${topic}`,
      grade,
      subject,
      questions: [
        {
          id: 1,
          type: 'multiple-choice',
          question: `In ${topic}, what is the first step when solving examination questions?`,
          options: ['Write the formula and identify given variables', 'Guess without showing steps', 'Leave the question blank', 'Ignore units'],
          correctIndex: 0,
          explanation: 'Stating the formula guarantees method marks in CAPS.',
        },
      ],
    });
  }
});

// Helper for comprehensive, step-by-step tutor responses when offline or on API timeout
function getFallbackTutorResponse(topic: string, question: string, language: string, grade: number): string {
  const q = question.toLowerCase();
  const isXh = language === 'xh' || /xhosa|chaza|cacisa|ndixelele/i.test(q);
  const isSt = language === 'st' || /sotho|hlalosa|kopa/i.test(q);

  if (isXh) {
    if (/working|inyathelo|step/i.test(q)) {
      return `### 🔍 Amanyathelo Ngamanyathelo: ${topic} (Ibanga ${grade} CAPS)

1. **Inyathelo 1: Bhala Phantsi Ifomula / Umthetho**
   Qala ngokuchonga amaxabiso anikiweyo nomthetho ojoliswe kuwo. Umzekelo: c² = a² + b² kwizibalo, okanye izivumelanisi zentloko kwisiXhosa.
2. **Inyathelo 2: Faka Amaxabiso Ngocoselelo**
   Faka amanani kwifomula ngaphandle kokutsiba inyathelo: c² = 6² + 8² = 36 + 64 = 100.
3. **Inyathelo 3: Fumana Impendulo Yokugqibela**
   c = √100 = 10 cm. Khumbula ukubhala iiyunithi zemilinganiselo!

*Icebiso elivela ku-Nceba: Kwiimviwo ze-CAPS, inyathelo ngalinye linamanqaku alo.*`;
    }
    return `Molo mfundi! Ngokwekharityhulam ye-CAPS (Ibanga ${grade}), umxholo othi "${topic}" ubaluleke kakhulu. Xa ufunda lo mbandela, jonga ukuba imithetho nentsingiselo zihambelana njani nezivakalisi okanye izibalo zakho. Ndingakunceda ngantoni enye kwesi sihloko?`;
  }

  if (isSt) {
    if (/working|mohato|step/i.test(q)) {
      return `### 🔍 Mehato ka Mehato: ${topic} (Kereiti ${grade} CAPS)

1. **Mohato wa 1: Ngola Foromo kapa Molao**
   Qala ka ho ngola molao o tobileng le dinomoro tseo o di filweng: c² = a² + b².
2. **Mohato wa 2: Kenya Dinomoro Tse Nepahetseng**
   c² = 6² + 8² = 36 + 64 = 100.
3. **Mohato wa 3: Bala Karabo ya Qetello**
   c = √100 = 10 cm. O se ke wa lebala diyuniti tsa tekanyo!

*Keletso e tswang ho Nceba: Ho CAPS, ho bontsha mehato ho o fa matshwao a bohlokwa.*`;
    }
    return `Dumela moithuti! Ho ya ka kharikhulamo ya CAPS (Kereiti ${grade}), sehlooho sa "${topic}" se bohlokwa haholo. Hopola ho latela mehato ka hloko le ho hlahloba dikarabo tsa hao. O ka botsa potso e nngwe le e nngwe, KhulaAI e teng ho o thusa!`;
  }

  // Workings requested
  if (/working|step|show me/i.test(q)) {
    return `### 🔍 Step-by-Step Workings for ${topic || 'This Problem'} (Grade ${grade} CAPS):

1. **Step 1: State the Given Information & Core Formula**
   Identify your variables and write down the governing CAPS formula:
   * Formula: c² = a² + b² (or for factorising: x² + bx + c = (x + p)(x + q))
   * Knowns: side a = 6 cm, side b = 8 cm

2. **Step 2: Clear Algebraic Substitution**
   Substitute the given values directly into the equation:
   * c² = (6)² + (8)²
   * c² = 36 + 64
   * c² = 100

3. **Step 3: Solve for the Target Variable**
   Take the square root of both sides to isolate c:
   * c = √100
   * c = 10 cm

4. **Step 4: Verify Units & Feasibility**
   Always check that the hypotenuse (10 cm) is strictly longer than both legs (6 cm and 8 cm). State final units clearly: **cm**.

*Note from Nceba: In CAPS marking memos, step 1 secures the formula mark, step 2 secures the substitution method mark, and step 3 awards the accuracy mark!*`;
  }

  // Simpler explanation requested
  if (/simpler|simple|easy|plain/i.test(q)) {
    return `### 💡 Plain & Simple Explanation: ${topic || 'Core Concept'}

Think of ${topic || 'this concept'} like a balance scale:
* Whatever happens on one side must equal the other side.
* If you are working with triangles, the two shorter sides squared always combine to equal the longest diagonal side squared (c² = a² + b²).
* If you are working in algebra, factorising simply means taking an expanded expression and putting it neatly back into brackets.

No tricky jargon. Just remember the one key formula, plug in your numbers, and check your answer at the end!`;
  }

  // Simplify without going off topic
  if (/without going off topic|simplify without|focused/i.test(q)) {
    return `### 🎯 Strict Curriculum Focus: ${topic || 'Target Topic'}

Staying strictly within the CAPS Grade ${grade} syllabus:
1. **The Definition:** State the official curriculum definition accurately.
2. **The Equation:** Apply only the approved formula (e.g. c² = a² + b² or A = OE + L).
3. **The Calculation:** Substitute numbers and compute the final value with proper units.

Everything else is unnecessary for full marks in your test.`;
  }

  // Everyday South African example
  if (/south african|everyday|example|local/i.test(q)) {
    return `### 🇿🇦 Everyday South African Example for ${topic || 'This Concept'}

Imagine taking a shortcut walking home from school or travelling via taxi:
* If you walk 300 metres East along a street, then 400 metres North along another street, you have walked a total of 700 metres.
* But if you cut diagonally across the open field directly between the two points, you walk along the hypotenuse:
  (300)² + (400)² = 90,000 + 160,000 = 250,000.
  Taking the square root: √250,000 = **500 metres**!
* Taking the diagonal shortcut saves you exactly 200 metres of walking.

That is the power of geometry in everyday South African life!`;
  }

  // Test me with 1 question
  if (/test me|question|quiz/i.test(q)) {
    return `### 📝 Quick 1-Question CAPS Challenge:

**Question [3 Marks]:**
A 13 m ladder leans against a vertical brick wall. The base of the ladder is placed 5 m away from the wall on flat ground.
Calculate how high up the wall the ladder reaches (height h).

*Tip: Use the formula b² = c² - a², calculate your answer, and reply here so KhulaAI can verify your steps!*`;
  }

  // Default encouraging response
  return `### 🎓 KhulaAI Tutor Guidance for ${topic || 'This Topic'}:

In Grade ${grade} CAPS, mastering ${topic || 'this topic'} is all about steady step-by-step method:
1. **Understand the rule:** Learn why the formula or grammar structure works.
2. **Show full workings:** Never jump straight to the final answer — write each step so you always earn method marks.

Pick any of the interactive follow-up buttons below to see the workings, get a simpler explanation, or test yourself!`;
}

// Route: AI Tutor Quick Explain / Chat
app.post('/api/tutor', async (req: Request, res: Response) => {
  const {
    messages = [],
    topic,
    language = 'auto',
    concise = true,
    grade = 8,
  } = req.body;

  const latestUserText = (messages[messages.length - 1]?.content || '').toLowerCase();
  const ai = getAIClient();

  if (!ai) {
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    const fallbackAnswer = getFallbackTutorResponse(topic || 'Curriculum Topic', latestUserText, language, grade);
    res.send(fallbackAnswer);
    return;
  }

  try {
    let languageInstruction = '';
    if (language === 'xh') {
      languageInstruction = 'Answer strictly in authentic, natural isiXhosa.';
    } else if (language === 'st') {
      languageInstruction = 'Answer strictly in authentic, natural Sesotho.';
    } else if (language === 'en') {
      languageInstruction = 'Answer in clear South African English.';
    } else {
      languageInstruction = 'Answer in the EXACT language the user is asking in. If user writes in isiXhosa, respond in isiXhosa. If in Sesotho, respond in Sesotho. If in English, respond in English.';
    }

    const explicitlyWantsLongAnswer =
      concise === false ||
      /long|detail|masterclass|thorough|elaborate|step-by-step|workings|ngokubanzi|ka botlalo|cacisa kabanzi/i.test(latestUserText);

    const brevity = explicitlyWantsLongAnswer
      ? 'LONG ANSWER INSTRUCTION: When asked for a long answer or detailed explanation, provide an extensive, deep, comprehensive multi-paragraph masterclass breakdown (3-5 rich paragraphs). Break down the background theory, conceptual origins, multiple worked examples with step-by-step calculations, and actionable exam tips.'
      : 'Limit your response to 1-2 concise, accessible paragraphs. Get straight to the point without filler.';

    const systemInstruction = `${AI_POWER_PERSONA}

You are KhulaAI, a helpful, encouraging South African school tutor for Grade ${grade}, made by Nceba.
${languageInstruction}
${brevity}
STRICT MATHEMATICAL NOTATION:
- Format all maths in real notebook/textbook handwriting notation.
- NEVER use LaTeX, dollar signs ($ or $$), or carets (^) for exponents.
- Write c² = a² + b² using real superscripts (², ³, ⁴).
- Use '√' for square roots (e.g., √25 = 5), '×' for multiplication, '÷' for division, and '°' for degrees (90°).
- Write units cleanly (cm, m, km, kg).
Focus on building understanding and confidence. If calculating, show clear workings.`;

    const formattedContents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    if (formattedContents.length === 0 && topic) {
      formattedContents.push({
        role: 'user',
        parts: [{ text: `Explain this topic clearly: ${topic}` }],
      });
    }

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Transfer-Encoding', 'chunked');

    const stream = await ai.models.generateContentStream({
      model: 'gemini-2.5-flash',
      contents: formattedContents,
      config: {
        systemInstruction,
        temperature: 0.6,
      },
    });

    for await (const chunk of stream) {
      if (chunk.text) {
        res.write(chunk.text);
      }
    }
    res.end();
  } catch (error: any) {
    console.error('Error in /api/tutor:', error);
    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    }
    const fallbackAnswer = getFallbackTutorResponse(topic || 'Curriculum Topic', latestUserText, language, grade);
    res.write(fallbackAnswer);
    res.end();
  }
});

// Setup Vite or static serving
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`KhulaAI server listening on port ${PORT}`);
  });
}

startServer();
